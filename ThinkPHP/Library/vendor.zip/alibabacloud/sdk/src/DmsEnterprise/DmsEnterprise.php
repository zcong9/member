<?php

namespace AlibabaCloud\DmsEnterprise;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20181101\DmsEnterpriseApiResolver v20181101()
 */
class DmsEnterprise extends VersionResolver
{
}
