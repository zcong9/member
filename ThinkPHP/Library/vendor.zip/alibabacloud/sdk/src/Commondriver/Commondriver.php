<?php

namespace AlibabaCloud\Commondriver;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20151229\CommondriverApiResolver v20151229()
 */
class Commondriver extends VersionResolver
{
}
