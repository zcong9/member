<?php

namespace AlibabaCloud\Dbs;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20190306\DbsApiResolver v20190306()
 */
class Dbs extends VersionResolver
{
}
