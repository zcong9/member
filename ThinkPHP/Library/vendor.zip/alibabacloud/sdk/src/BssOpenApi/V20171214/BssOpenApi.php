<?php

namespace AlibabaCloud\BssOpenApi\V20171214;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class BssOpenApi extends ApiResolver
{
}
