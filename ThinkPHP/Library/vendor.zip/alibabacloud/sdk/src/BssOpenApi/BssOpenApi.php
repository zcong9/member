<?php

namespace AlibabaCloud\BssOpenApi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20171214\BssOpenApiApiResolver v20171214()
 */
class BssOpenApi extends VersionResolver
{
}
