<?php

namespace AlibabaCloud\BssOpenApi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class BssOpenApiVersion extends VersionResolver
{
}
