<?php

namespace AlibabaCloud\Cloudwf;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170328\CloudwfApiResolver v20170328()
 */
class Cloudwf extends VersionResolver
{
}
