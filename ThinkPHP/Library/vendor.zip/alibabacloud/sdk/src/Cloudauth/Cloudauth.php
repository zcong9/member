<?php

namespace AlibabaCloud\Cloudauth;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180916\CloudauthApiResolver v20180916()
 * @method static V20190307\CloudauthApiResolver v20190307()
 */
class Cloudauth extends VersionResolver
{
}
