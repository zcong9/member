<?php

namespace AlibabaCloud\Dcdn;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DcdnVersion extends VersionResolver
{
}
