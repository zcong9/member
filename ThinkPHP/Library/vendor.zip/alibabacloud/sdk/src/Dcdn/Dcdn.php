<?php

namespace AlibabaCloud\Dcdn;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180115\DcdnApiResolver v20180115()
 */
class Dcdn extends VersionResolver
{
}
