<?php

namespace AlibabaCloud\Dcdn\V20180115;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Dcdn extends ApiResolver
{
}
