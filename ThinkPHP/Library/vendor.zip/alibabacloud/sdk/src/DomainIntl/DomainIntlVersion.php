<?php

namespace AlibabaCloud\DomainIntl;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DomainIntlVersion extends VersionResolver
{
}
