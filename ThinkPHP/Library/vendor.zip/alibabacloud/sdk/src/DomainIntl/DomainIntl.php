<?php

namespace AlibabaCloud\DomainIntl;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20171218\DomainIntlApiResolver v20171218()
 */
class DomainIntl extends VersionResolver
{
}
