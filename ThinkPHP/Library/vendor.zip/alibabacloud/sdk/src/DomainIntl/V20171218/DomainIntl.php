<?php

namespace AlibabaCloud\DomainIntl\V20171218;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class DomainIntl extends ApiResolver
{
}
