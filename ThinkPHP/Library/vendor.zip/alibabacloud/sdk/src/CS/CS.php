<?php

namespace AlibabaCloud\CS;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20151215\CSApiResolver v20151215()
 * @method static V20180418\CSApiResolver v20180418()
 */
class CS extends VersionResolver
{
}
