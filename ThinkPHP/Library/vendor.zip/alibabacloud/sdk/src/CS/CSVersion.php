<?php

namespace AlibabaCloud\CS;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class CSVersion extends VersionResolver
{
}
