<?php

namespace AlibabaCloud\Eci\V20180808;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Eci extends ApiResolver
{
}
