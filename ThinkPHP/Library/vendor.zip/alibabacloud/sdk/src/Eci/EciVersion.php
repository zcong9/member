<?php

namespace AlibabaCloud\Eci;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class EciVersion extends VersionResolver
{
}
