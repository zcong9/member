<?php

namespace AlibabaCloud\Eci;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180808\EciApiResolver v20180808()
 */
class Eci extends VersionResolver
{
}
