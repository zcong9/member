<?php

namespace AlibabaCloud\Aas;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20150701\AasApiResolver v20150701()
 */
class Aas extends VersionResolver
{
}
