<?php

namespace AlibabaCloud\CusanalyticScOnline;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20190524\CusanalyticScOnlineApiResolver v20190524()
 */
class CusanalyticScOnline extends VersionResolver
{
}
