<?php

namespace AlibabaCloud\DemoCenter;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20200121\DemoCenterApiResolver v20200121()
 */
class DemoCenter extends VersionResolver
{
}
