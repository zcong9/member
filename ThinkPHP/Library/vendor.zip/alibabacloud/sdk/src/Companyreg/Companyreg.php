<?php

namespace AlibabaCloud\Companyreg;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20190508\CompanyregApiResolver v20190508()
 */
class Companyreg extends VersionResolver
{
}
