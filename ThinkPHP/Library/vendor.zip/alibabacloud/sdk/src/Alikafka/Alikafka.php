<?php

namespace AlibabaCloud\Alikafka;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20181015\AlikafkaApiResolver v20181015()
 */
class Alikafka extends VersionResolver
{
}
