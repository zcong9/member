<?php

namespace AlibabaCloud\Bss;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20140714\BssApiResolver v20140714()
 */
class Bss extends VersionResolver
{
}
