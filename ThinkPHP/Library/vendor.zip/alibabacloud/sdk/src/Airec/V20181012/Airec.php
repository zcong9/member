<?php

namespace AlibabaCloud\Airec\V20181012;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Airec extends ApiResolver
{
}
