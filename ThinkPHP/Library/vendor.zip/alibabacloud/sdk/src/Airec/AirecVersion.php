<?php

namespace AlibabaCloud\Airec;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class AirecVersion extends VersionResolver
{
}
