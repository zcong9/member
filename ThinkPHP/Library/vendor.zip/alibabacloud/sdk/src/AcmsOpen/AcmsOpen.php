<?php

namespace AlibabaCloud\AcmsOpen;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20200206\AcmsOpenApiResolver v20200206()
 */
class AcmsOpen extends VersionResolver
{
}
