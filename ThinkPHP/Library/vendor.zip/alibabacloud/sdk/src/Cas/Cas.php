<?php

namespace AlibabaCloud\Cas;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180713\CasApiResolver v20180713()
 * @method static V20180813\CasApiResolver v20180813()
 */
class Cas extends VersionResolver
{
}
