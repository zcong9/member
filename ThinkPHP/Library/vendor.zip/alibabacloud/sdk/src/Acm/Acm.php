<?php

namespace AlibabaCloud\Acm;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20200206\AcmApiResolver v20200206()
 */
class Acm extends VersionResolver
{
}
