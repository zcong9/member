<?php

namespace AlibabaCloud\Cr;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20160607\CrApiResolver v20160607()
 */
class Cr extends VersionResolver
{
}
