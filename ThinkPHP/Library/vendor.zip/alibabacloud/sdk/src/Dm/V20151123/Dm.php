<?php

namespace AlibabaCloud\Dm\V20151123;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Dm extends ApiResolver
{
}
