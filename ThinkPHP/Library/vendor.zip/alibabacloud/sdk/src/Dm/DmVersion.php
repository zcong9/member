<?php

namespace AlibabaCloud\Dm;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DmVersion extends VersionResolver
{
}
