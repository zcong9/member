<?php

namespace AlibabaCloud\Dm;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20151123\DmApiResolver v20151123()
 */
class Dm extends VersionResolver
{
}
