<?php

namespace AlibabaCloud\Alidns;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20150109\AlidnsApiResolver v20150109()
 */
class Alidns extends VersionResolver
{
}
