<?php

namespace AlibabaCloud\Ecs;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20140526\EcsApiResolver v20140526()
 */
class Ecs extends VersionResolver
{
}
