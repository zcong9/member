<?php

namespace AlibabaCloud\Chatbot;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20171011\ChatbotApiResolver v20171011()
 */
class Chatbot extends VersionResolver
{
}
