<?php

namespace AlibabaCloud\Chatbot\V20171011;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Chatbot extends ApiResolver
{
}
