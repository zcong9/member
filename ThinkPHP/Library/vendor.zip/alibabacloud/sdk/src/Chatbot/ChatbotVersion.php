<?php

namespace AlibabaCloud\Chatbot;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class ChatbotVersion extends VersionResolver
{
}
