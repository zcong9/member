<?php

namespace AlibabaCloud\Dysmsapi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170525\DysmsapiApiResolver v20170525()
 */
class Dysmsapi extends VersionResolver
{
}
