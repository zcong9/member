<?php

namespace AlibabaCloud\Dysmsapi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DysmsapiVersion extends VersionResolver
{
}
