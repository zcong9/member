<?php

namespace AlibabaCloud\Dysmsapi\V20170525;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Dysmsapi extends ApiResolver
{
}
