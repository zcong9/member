<?php

namespace AlibabaCloud\Aliyuncvc;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20191030\AliyuncvcApiResolver v20191030()
 */
class Aliyuncvc extends VersionResolver
{
}
