<?php

namespace AlibabaCloud\Cms;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20190101\CmsApiResolver v20190101()
 */
class Cms extends VersionResolver
{
}
