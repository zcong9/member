<?php

namespace AlibabaCloud\CCC;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class CCCVersion extends VersionResolver
{
}
