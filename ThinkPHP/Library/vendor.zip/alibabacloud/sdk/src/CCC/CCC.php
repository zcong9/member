<?php

namespace AlibabaCloud\CCC;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170705\CCCApiResolver v20170705()
 */
class CCC extends VersionResolver
{
}
