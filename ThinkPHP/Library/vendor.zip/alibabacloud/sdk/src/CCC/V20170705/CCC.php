<?php

namespace AlibabaCloud\CCC\V20170705;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class CCC extends ApiResolver
{
}
