<?php

namespace AlibabaCloud\Dyplsapi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170525\DyplsapiApiResolver v20170525()
 */
class Dyplsapi extends VersionResolver
{
}
