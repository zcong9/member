<?php

namespace AlibabaCloud\Cds;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170925\CdsApiResolver v20170925()
 */
class Cds extends VersionResolver
{
}
