<?php

namespace AlibabaCloud\CSB\V20171118;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class CSB extends ApiResolver
{
}
