<?php

namespace AlibabaCloud\CSB;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class CSBVersion extends VersionResolver
{
}
