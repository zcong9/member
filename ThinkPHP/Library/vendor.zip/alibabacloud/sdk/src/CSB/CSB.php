<?php

namespace AlibabaCloud\CSB;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20171118\CSBApiResolver v20171118()
 */
class CSB extends VersionResolver
{
}
