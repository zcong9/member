<?php

namespace AlibabaCloud\Ccs\V20171001;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Ccs extends ApiResolver
{
}
