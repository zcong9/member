<?php

namespace AlibabaCloud\Ccs;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class CcsVersion extends VersionResolver
{
}
