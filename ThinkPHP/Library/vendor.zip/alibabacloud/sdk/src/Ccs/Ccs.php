<?php

namespace AlibabaCloud\Ccs;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20171001\CcsApiResolver v20171001()
 */
class Ccs extends VersionResolver
{
}
