<?php

namespace AlibabaCloud\Dds;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20151201\DdsApiResolver v20151201()
 */
class Dds extends VersionResolver
{
}
