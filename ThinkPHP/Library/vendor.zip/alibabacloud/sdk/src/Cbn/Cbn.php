<?php

namespace AlibabaCloud\Cbn;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170912\CbnApiResolver v20170912()
 */
class Cbn extends VersionResolver
{
}
