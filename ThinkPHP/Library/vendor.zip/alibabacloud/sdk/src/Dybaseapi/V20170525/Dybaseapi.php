<?php

namespace AlibabaCloud\Dybaseapi\V20170525;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Dybaseapi extends ApiResolver
{
}
