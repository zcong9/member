<?php

namespace AlibabaCloud\Dybaseapi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DybaseapiVersion extends VersionResolver
{
}
