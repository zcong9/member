<?php

namespace AlibabaCloud\Dybaseapi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170525\DybaseapiApiResolver v20170525()
 */
class Dybaseapi extends VersionResolver
{
}
