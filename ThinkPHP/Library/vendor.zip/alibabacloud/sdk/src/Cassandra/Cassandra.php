<?php

namespace AlibabaCloud\Cassandra;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20190101\CassandraApiResolver v20190101()
 */
class Cassandra extends VersionResolver
{
}
