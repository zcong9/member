<?php

namespace AlibabaCloud\Cloudesl;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class CloudeslVersion extends VersionResolver
{
}
