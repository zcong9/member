<?php

namespace AlibabaCloud\Cloudesl\V20180801;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Cloudesl extends ApiResolver
{
}
