<?php

namespace AlibabaCloud\CF;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20151127\CFApiResolver v20151127()
 */
class CF extends VersionResolver
{
}
