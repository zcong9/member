<?php

namespace AlibabaCloud\Aegis;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class AegisVersion extends VersionResolver
{
}
