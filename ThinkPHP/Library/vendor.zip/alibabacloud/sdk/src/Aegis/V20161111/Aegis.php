<?php

namespace AlibabaCloud\Aegis\V20161111;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Aegis extends ApiResolver
{
}
