<?php

namespace AlibabaCloud\Aegis;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20161111\AegisApiResolver v20161111()
 */
class Aegis extends VersionResolver
{
}
