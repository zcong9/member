<?php

namespace AlibabaCloud\Afs;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180112\AfsApiResolver v20180112()
 */
class Afs extends VersionResolver
{
}
