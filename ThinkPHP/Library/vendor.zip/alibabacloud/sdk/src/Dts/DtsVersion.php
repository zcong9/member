<?php

namespace AlibabaCloud\Dts;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DtsVersion extends VersionResolver
{
}
