<?php

namespace AlibabaCloud\Dts\V20160801;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Dts extends ApiResolver
{
}
