<?php

namespace AlibabaCloud\Dts;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20160801\DtsApiResolver v20160801()
 */
class Dts extends VersionResolver
{
}
