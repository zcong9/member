<?php

namespace AlibabaCloud\Alimt;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20181012\AlimtApiResolver v20181012()
 */
class Alimt extends VersionResolver
{
}
