<?php

namespace AlibabaCloud\AppMallsService;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180224\AppMallsServiceApiResolver v20180224()
 */
class AppMallsService extends VersionResolver
{
}
