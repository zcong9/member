<?php

namespace AlibabaCloud\Drds\V20171016;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Drds extends ApiResolver
{
}
