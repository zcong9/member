<?php

namespace AlibabaCloud\Drds;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20171016\DrdsApiResolver v20171016()
 */
class Drds extends VersionResolver
{
}
