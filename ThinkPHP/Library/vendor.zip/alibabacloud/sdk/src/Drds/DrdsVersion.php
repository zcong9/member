<?php

namespace AlibabaCloud\Drds;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DrdsVersion extends VersionResolver
{
}
