<?php

namespace AlibabaCloud\Cloudmarketing;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180910\CloudmarketingApiResolver v20180910()
 */
class Cloudmarketing extends VersionResolver
{
}
