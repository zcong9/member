<?php

namespace AlibabaCloud\Baas;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class BaasVersion extends VersionResolver
{
}
