<?php

namespace AlibabaCloud\Baas\V20180731;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Baas extends ApiResolver
{
}
