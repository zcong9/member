<?php

namespace AlibabaCloud\Baas;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180731\BaasApiResolver v20180731()
 */
class Baas extends VersionResolver
{
}
