<?php

namespace AlibabaCloud\CloudPhoto;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class CloudPhotoVersion extends VersionResolver
{
}
