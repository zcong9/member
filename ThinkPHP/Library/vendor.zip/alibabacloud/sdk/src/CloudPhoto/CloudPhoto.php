<?php

namespace AlibabaCloud\CloudPhoto;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170711\CloudPhotoApiResolver v20170711()
 */
class CloudPhoto extends VersionResolver
{
}
