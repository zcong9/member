<?php

namespace AlibabaCloud\CloudPhoto\V20170711;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class CloudPhoto extends ApiResolver
{
}
