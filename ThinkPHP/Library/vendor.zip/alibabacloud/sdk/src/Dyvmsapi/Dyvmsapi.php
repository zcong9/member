<?php

namespace AlibabaCloud\Dyvmsapi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20170525\DyvmsapiApiResolver v20170525()
 */
class Dyvmsapi extends VersionResolver
{
}
