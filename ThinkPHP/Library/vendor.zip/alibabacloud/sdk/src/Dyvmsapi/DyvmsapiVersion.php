<?php

namespace AlibabaCloud\Dyvmsapi;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DyvmsapiVersion extends VersionResolver
{
}
