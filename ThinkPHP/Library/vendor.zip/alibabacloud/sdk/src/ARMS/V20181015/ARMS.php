<?php

namespace AlibabaCloud\ARMS\V20181015;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class ARMS extends ApiResolver
{
}
