<?php

namespace AlibabaCloud\ARMS;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20181015\ARMSApiResolver v20181015()
 * @method static V20190808\ARMSApiResolver v20190808()
 */
class ARMS extends VersionResolver
{
}
