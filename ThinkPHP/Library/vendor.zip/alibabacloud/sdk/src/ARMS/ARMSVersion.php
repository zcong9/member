<?php

namespace AlibabaCloud\ARMS;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class ARMSVersion extends VersionResolver
{
}
