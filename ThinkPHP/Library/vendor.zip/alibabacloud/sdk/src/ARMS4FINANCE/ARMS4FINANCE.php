<?php

namespace AlibabaCloud\ARMS4FINANCE;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20171130\ARMS4FINANCEApiResolver v20171130()
 */
class ARMS4FINANCE extends VersionResolver
{
}
