<?php

namespace AlibabaCloud\ARMS4FINANCE;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class ARMS4FINANCEVersion extends VersionResolver
{
}
