<?php

namespace AlibabaCloud\ARMS4FINANCE\V20171130;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class ARMS4FINANCE extends ApiResolver
{
}
