<?php

namespace AlibabaCloud\Actiontrail;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20171204\ActiontrailApiResolver v20171204()
 */
class Actiontrail extends VersionResolver
{
}
