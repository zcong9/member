<?php

namespace AlibabaCloud\Adb;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20190315\AdbApiResolver v20190315()
 */
class Adb extends VersionResolver
{
}
