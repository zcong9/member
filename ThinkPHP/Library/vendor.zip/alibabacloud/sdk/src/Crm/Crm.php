<?php

namespace AlibabaCloud\Crm;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20150408\CrmApiResolver v20150408()
 */
class Crm extends VersionResolver
{
}
