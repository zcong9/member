<?php

namespace AlibabaCloud\Crm\V20150408;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Crm extends ApiResolver
{
}
