<?php

namespace AlibabaCloud\Crm;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class CrmVersion extends VersionResolver
{
}
