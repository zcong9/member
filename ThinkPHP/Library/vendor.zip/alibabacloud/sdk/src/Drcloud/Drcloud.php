<?php

namespace AlibabaCloud\Drcloud;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20190213\DrcloudApiResolver v20190213()
 */
class Drcloud extends VersionResolver
{
}
