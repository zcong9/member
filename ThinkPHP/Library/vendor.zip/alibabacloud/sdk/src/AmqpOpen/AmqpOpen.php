<?php

namespace AlibabaCloud\AmqpOpen;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20191212\AmqpOpenApiResolver v20191212()
 */
class AmqpOpen extends VersionResolver
{
}
