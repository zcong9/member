<?php

namespace AlibabaCloud\BatchCompute;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class BatchComputeVersion extends VersionResolver
{
}
