<?php

namespace AlibabaCloud\BatchCompute\V20130111;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class BatchCompute extends ApiResolver
{
}
