<?php

namespace AlibabaCloud\CloudAPI;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class CloudAPIVersion extends VersionResolver
{
}
