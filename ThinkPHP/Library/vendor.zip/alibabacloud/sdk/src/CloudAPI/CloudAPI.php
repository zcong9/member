<?php

namespace AlibabaCloud\CloudAPI;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20160714\CloudAPIApiResolver v20160714()
 */
class CloudAPI extends VersionResolver
{
}
