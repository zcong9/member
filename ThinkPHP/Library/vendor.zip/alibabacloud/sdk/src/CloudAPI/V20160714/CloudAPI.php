<?php

namespace AlibabaCloud\CloudAPI\V20160714;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class CloudAPI extends ApiResolver
{
}
