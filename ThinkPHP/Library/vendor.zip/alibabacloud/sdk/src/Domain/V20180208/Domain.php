<?php

namespace AlibabaCloud\Domain\V20180208;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Domain extends ApiResolver
{
}
