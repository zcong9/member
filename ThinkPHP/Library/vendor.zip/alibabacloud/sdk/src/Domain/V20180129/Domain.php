<?php

namespace AlibabaCloud\Domain\V20180129;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Domain extends ApiResolver
{
}
