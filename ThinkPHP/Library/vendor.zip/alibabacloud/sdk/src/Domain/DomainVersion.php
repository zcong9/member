<?php

namespace AlibabaCloud\Domain;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class DomainVersion extends VersionResolver
{
}
