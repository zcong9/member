<?php

namespace AlibabaCloud\Domain;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20180129\DomainApiResolver v20180129()
 * @method static V20180208\DomainApiResolver v20180208()
 */
class Domain extends VersionResolver
{
}
