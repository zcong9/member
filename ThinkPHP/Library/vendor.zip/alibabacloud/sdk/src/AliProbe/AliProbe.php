<?php

namespace AlibabaCloud\AliProbe;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20161222\AliProbeApiResolver v20161222()
 */
class AliProbe extends VersionResolver
{
}
