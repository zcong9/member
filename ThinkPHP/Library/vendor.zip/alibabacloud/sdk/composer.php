<?php

namespace AlibabaCloud\composer;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 */
class composer extends VersionResolver
{
}
