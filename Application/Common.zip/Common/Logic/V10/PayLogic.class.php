<?php

namespace Common\Logic\V10;

use PayMethod\WxpayMicropay2\MicroPay_1;
use PayMethod\WxpayMicropay\MicroPay;
use data\service\SellOut as ServiceSellOut;
use Think\Log;
use Api\Controller\ShandeController;
use Api\Model\BusinessShandePayConfigModel;

class PayLogic extends \Common\Logic\BaseLogic
{
    const PAY_TYPE_ALI = 1;
    const PAY_TYPE_WX = 2;
    const PAY_TYPE_ALI_FACE = 3;
    const PAY_TYPE_WX_FACE = 4;
    const PAY_TYPE_MEMBER = 5;
    const PAY_MIXED = 11;

    const TRADE_STATUS_UNPAID = 0;//未支付
    const TRADE_STATUS_PARTIAL_PAY = 1;//部分付款
    const TRADE_STATUS_COMPLETE_PAY = 2;//完成付款

    private $orderObj = null;
    private $errMsg = '';

    private $paySelectModel;
    private $orderSn;
    private $orderInfo;
    private $payAmount;//剩余支付金额
    private $totalPayAmount;//订单支付总金额
    private $tbSuffix;
    private $payAmounts = array();//会员支付金额
    private $tradeStatus = self::TRADE_STATUS_UNPAID;

    public function __construct()
    {
        $this->paySelectModel = new \Common\Model\PaySelectModel();
    }

    public function setOrderObj(object $obj)
    {
        $this->orderObj = $obj;
        $this->tbSuffix = substr(strrchr($this->orderObj->getModelName(), "_"), 1);
        return $this;
    }

    public function getOrderObj()
    {
        return $this->orderObj;
    }

    private function setErrMsg($msg)
    {
        $this->errMsg = $msg;
    }

    public function getErrMsg()
    {
        return $this->errMsg;
    }

    public function setTradeStatus($tradeStatus)
    {
        $this->tradeStatus = $tradeStatus;
    }

    public function getTradeStatus()
    {
        return $this->tradeStatus;
    }

    public function setPayAmount($amount)
    {
        $this->payAmount = $amount;
    }

    public function getPayAmount()
    {
        return $this->payAmount;
    }

    /**
     * 支付统一入口
     * @param array $post
     * @return bool
     */
    public function pay(array $post)
    {
        $this->orderSn = $post['order_sn'];
        $restaurantId = $post['restaurant_id'];
        $payType = $post['pay_type'];//支付方式，如果是刷脸支付时必传4
        #查询订单状态
        $this->orderInfo = $orderInfo = $this->orderObj
            ->alias('o')
            ->join('LEFT JOIN restaurant AS r ON r.restaurant_id = o.restaurant_id')
            ->field('o.order_id,o.order_status,o.total_amount,o.add_time,o.restaurant_id,r.business_id')
            ->where(['o.restaurant_id' => $restaurantId, 'o.order_sn' => $this->orderSn])
            ->find();

        Log::write('支付订单信息：' . json_encode($orderInfo, JSON_UNESCAPED_UNICODE));

        if (empty($orderInfo)) {
            $this->setErrMsg('获取订单异常');
            return false;
        }

        $this->setBusinessId($orderInfo['business_id']);

        if ($orderInfo['order_status'] == '1') {
            $this->setErrMsg('订单已付款，请不要重复支付');
            return false;
        }

        //下单时间 离 当前时间 大于 5分钟 超时
        if ((time() - $orderInfo['add_time']) > 300) {
            $this->setErrMsg('订单已超时，请重新下单');
            return false;
        }

        #如果订单已支付或已关闭交易
        if ($orderInfo['order_status'] == '2') {
            $this->setErrMsg('订单已关闭交易');
            return false;
        }

        #根据条形码前缀决定使用支付宝交易还是微信交易
        $authCode = trim($post['qr_number']);
        $prefixNum = substr($authCode, 0, 2);

        if (!$authCode) {
            $this->setErrMsg('付款码错误');
            return false;
        }

        $this->totalPayAmount = $total_amount = $orderInfo['total_amount'];
        if (in_array($prefixNum, ['FK'])) {

            //相同订单上一次会员扫码 撤销
            if (false === $this->memberPayUnlocking($this->orderSn, $restaurantId)) {
                $this->setErrMsg('支付失败：解锁余额或优惠券失败');
                return false;
            }

            return $this->memberPay($this->orderSn, $authCode, $restaurantId, $total_amount);
        }

        //判断是否有会员支付记录
        $this->payAmounts = $this->getMemberPayAmount($this->orderSn, $restaurantId);
        $total_amount = bcsub($total_amount, ($this->payAmounts)['total_amount'], 2);

        $payModeModel = new \Common\Model\PayModeModel();
        $pay_mode = $payModeModel->where(['restaurant_id' => $orderInfo['restaurant_id']])->getField('mode');

        if ($pay_mode == $payModeModel::PAY_KUANYIPAY) {
            return $this->kuanyiPay($this->orderSn, $authCode, $restaurantId, $total_amount);
        }

        if ($pay_mode == $payModeModel::PAY_QWXPAY) {
            return $this->qwxPay($this->orderSn, $authCode, $restaurantId, $total_amount);
        }

        if (($pay_mode == $payModeModel::PAY_SHANDE) && (in_array($prefixNum, C('AL_PAY_PREFIX')) || in_array($prefixNum, C('WX_PAY_PREFIX')))) {
            return $this->shandePay($this->orderSn, $authCode, $restaurantId, $total_amount, $payType, $orderInfo['business_id']);
        }

        if (in_array($prefixNum, C('AL_PAY_PREFIX')) || (3 == $payType)) {
            $scene = (3 == $payType) ? 'security_code' : 'bar_code';
            return $this->aliPay($this->orderSn, $authCode, $restaurantId, $total_amount, $pay_mode, $scene);
        }

        if (in_array($prefixNum, C('WX_PAY_PREFIX'))) {
            return $this->wxPay($this->orderSn, $authCode, $restaurantId, $total_amount, $pay_mode);
        }

        //款易会员码
        if (strlen($authCode) > 15) {
            return $this->kuanyiPay($this->orderSn, $authCode, $restaurantId, $total_amount);
        }

        $this->setErrMsg('付款码无效');
        return false;
    }

    /**
     * 结账服务
     * @param $orderSn
     * @param $restaurantId
     * @return bool
     */
    public function billingService($orderSn, $restaurantId)
    {
        //判断是否有会员支付记录
        $payLog = new \Common\Model\PayLogModel();
        $count = $payLog->where(['restaurant_id' => $restaurantId, 'order_sn' => $orderSn, 'pay_type' => $payLog::PAY_TYPE_CANDAO, 'is_del' => $payLog::DEL_NO])->count();
        if ($count) {
            //订单结账
            $n = 10;
            $res = false;
            while ($n > 1) {
                $n--;
                $res = $this->memberPaySettleAccounts($orderSn, $restaurantId);
                if (false !== $res) {

                    //取消解锁优惠券队列
                    (new \Common\Queue\Candao())->removeUnlockingTask(["order_sn" => $orderSn, 'restaurant_id' => $restaurantId, 'tb_suffix' => $this->tbSuffix]);

                    return $res;
                }
                sleep(1);
            }
            if (false === $res) {
                //结账失败 写入队列
                (new \Common\Queue\Candao())->addMemberPaySettleAccountsTask(["order_sn" => $orderSn, 'restaurant_id' => $restaurantId, 'tb_suffix' => $this->tbSuffix]);
                Log::write('订单结账失败：' . $orderSn);
            }
            return $res;
        } else {
            return true;
        }
    }

    /**
     * 获取会员支付过的金额
     * @param $orderSn
     * @param $restaurantId
     * @return array
     */
    public function getMemberPayAmount($orderSn, $restaurantId)
    {
        $data = ['couponAmount' => 0, 'cardAmount' => 0, 'total_amount' => 0];
        //判断是否有会员支付记录
        $payLog = new \Common\Model\PayLogModel();
        $payRows = $payLog->where(['restaurant_id' => $restaurantId, 'order_sn' => $orderSn, 'pay_type' => $payLog::PAY_TYPE_CANDAO, 'is_del' => $payLog::DEL_NO])->order('id desc')->find();
        if (empty($payRows)) return $data;
        $log = json_decode($payRows['log'], true, 512, JSON_BIGINT_AS_STRING);
        $paymentDetail = $log['paymentDetail'];
        $data['total_amount'] = array_sum(array_column($paymentDetail, 'payAmount'));
        foreach ($paymentDetail as $vo) {
            if ((int)$vo['payType'] == 30) {
                $data['cardAmount'] = bcadd($data['cardAmount'], $vo['payAmount'], 2);
            } elseif ((int)$vo['payType'] == 33) {
                $data['couponAmount'] = bcadd($data['couponAmount'], $vo['payAmount'], 2);
            }
        }
        return $data;
    }

    /**
     * 判断是否开启支付方式
     * @param $restaurantId
     * @param $configName
     * @return mixed
     */
    private function checkPaySelectIsOpen($restaurantId, $configName)
    {
        $pCondition['restaurant_id'] = $restaurantId;
        $pCondition['config_name'] = $configName;
        $pCondition['value'] = "1";
        return $this->paySelectModel->where($pCondition)->find();
    }


    /**
     * 更新订单状态
     * @param array $condition
     * @param array $saveData
     * @return mixed
     */
    private function updateOrderStatus(array $condition, array $saveData)
    {
        !isset($saveData['order_status']) && $saveData['order_status'] = 1;
        $saveData['pay_time'] = $saveData['update_time'] = time();
        try {
            return $this->orderObj->where($condition)->save($saveData);
        } catch (\Exception $e) {
            Log::write('更新订单状态失败：' . $e->getMessage());
            return false;
        }
    }

    /**
     * 是否售罄处理
     * @param $orderSn
     */
    private function checkSellOut($orderSn)
    {
        try {
            $S_SellOut = new ServiceSellOut();
            $S_SellOut->sellOutDeal($orderSn);
            #删除第三方支付二维码
            delQrcode($orderSn, 2);
        } catch (\Exception $e) {
            Log::write('sellOutDeal：' . $e->getMessage());
        }
    }

    /**
     * 餐道会员支付
     * @param $orderSn
     * @param $authCode
     * @param $restaurantId
     * @param $total_amount
     * @return bool
     */
    private function memberPay($orderSn, $authCode, $restaurantId, $total_amount)
    {
        $postData = array("order_sn" => $orderSn, "qr_number" => $authCode, 'restaurant_id' => $restaurantId, 'tb_suffix' => $this->tbSuffix);
        $reqJson = http_post(domain() . '/api/Candao/autoConsumption', $postData);
        $reqArr = json_decode($reqJson, true);
        Log::write('餐道会员支付：' . $reqJson);
        if ($reqArr && 1 == $reqArr['code']) {

            //判断是否支付完成
            $paymentDetail = $reqArr['data']['paymentDetail'];
            $payAmount = array_sum(array_column($paymentDetail, 'payAmount'));//总支付金额
            Log::write('餐道会员支付-总支付金额：' . $payAmount);

            //记录支付日志
            $payLog = new \Common\Model\PayLogModel();
            $logData = array(
                'restaurant_id' => $restaurantId,
                'order_sn' => $orderSn,
                'pay_status' => 1,
                'pay_amount' => $payAmount,
                'pay_mode' => $payLog::PAY_MODE_CANDAO,
                'pay_type' => $payLog::PAY_TYPE_CANDAO,
                'trade_num' => $reqArr['data']['transNum'],
                'log' => json_encode($reqArr['data'])
            );
            $logId = $payLog->doAdd($logData);
            if (false === $logId) {
                $this->memberPayUnlocking($orderSn, $restaurantId);
                Log::write('餐道会员支付：写入支付日志失败');
                $this->setErrMsg('支付失败');
                return false;
            }

            //记录卡券使用
            $payAmounts = $this->writeCouponAndCard($orderSn, $restaurantId, $paymentDetail);

            //判断是否支付完成
            if (bcmul($payAmount, 100, 0) == bcmul($total_amount, 100, 0)) {

                //订单结账
                if (false === $this->memberPaySettleAccounts($orderSn, $restaurantId)) {
                    //结账失败 解锁余额 优惠券
                    $this->memberPayUnlocking($orderSn, $restaurantId);
                    $this->setErrMsg('支付失败：结账异常，请使用其他支付方式付款');
                    return false;
                }

                //成功修改订单状态
                $saveData = ['pay_type' => self::PAY_TYPE_MEMBER];
                $saveData['total_amount'] = bcsub($total_amount, $payAmounts['couponAmount'], 2);//实际支付金额 = 原来支付金额 - 优惠金额
                $saveData['coupon_pay'] = $payAmounts['couponAmount'];

                if (false === $this->updateOrderStatus(['order_sn' => $orderSn], $saveData)) {
                    Log::write('餐道会员支付：更新订单状态失败');

                    //撤销订单
                    $cancelStatus = $this->memberPayCancel($orderSn, $restaurantId);
                    if (false === $cancelStatus) {
                        $n = 2;
                        while ($n > 0) {
                            $n--;
                            if ($cancelStatus = $this->memberPayCancel($orderSn, $restaurantId)) {
                                break;
                            }
                            sleep(1);
                        }
                    }

                    $this->setErrMsg('支付失败：撤销消费' . $cancelStatus ? '成功' : '失败');
                    return false;
                }

                //是否售罄处理
                $this->checkSellOut($orderSn);
                $this->setTradeStatus(self::TRADE_STATUS_COMPLETE_PAY);

            } else {

                //加入队列
                (new \Common\Queue\Candao())->addUnlockingTask(($this->orderInfo)['add_time'], ["order_sn" => $orderSn, 'restaurant_id' => $restaurantId, 'tb_suffix' => $this->tbSuffix]);
                $this->setPayAmount(bcsub($total_amount, $payAmount, 2));
                $this->setTradeStatus(self::TRADE_STATUS_PARTIAL_PAY);
                $this->setErrMsg('订单已部分支付，请使用支付宝或微信继续扫码完成付款，剩余支付金额：' . $this->payAmount);

            }

            return true;
        }

        $this->setErrMsg($reqArr['msg']);
        return false;
    }

    /**
     * 会员支付-结账成功 后撤销订单
     * @param $orderSn
     * @param $restaurantId
     * @return bool
     */
    private function memberPayCancel($orderSn, $restaurantId)
    {
        try {
            $reqJson = http_post(domain() . '/api/Candao/consumeCancel', ["order_sn" => $orderSn, 'restaurant_id' => $restaurantId]);
            $reqArr = json_decode($reqJson, true);
            if (1 === $reqArr['code']) {
                return true;
            } else {
                $this->setErrMsg('支付失败');
                return false;
            }
            Log::write('餐道会员支付-撤销：' . $reqJson);
        } catch (\Exception $e) {
            $this->setErrMsg($e->getMessage());
            return false;
        }
    }

    /**
     * 会员支付解锁 余额、优惠券
     * 比如客户刷码了，使用了余额和优惠券，但是没支付完成，客户不想要了，不结账把钱和券给他退回去
     * @param $orderSn
     * @param $restaurantId
     * @return bool
     */
    public function memberPayUnlocking($orderSn, $restaurantId)
    {
        //判断是否有会员支付记录
        $payLog = new \Common\Model\PayLogModel();
        $payRows = $payLog->where(['restaurant_id' => $restaurantId, 'order_sn' => $orderSn, 'pay_type' => $payLog::PAY_TYPE_CANDAO, 'is_del' => $payLog::DEL_NO])->order('id desc')->find();
        if (empty($payRows)) return true;
        $log = json_decode($payRows['log'], true, 512, JSON_BIGINT_AS_STRING);
        $paymentDetail = $log['paymentDetail'];
        foreach ($paymentDetail as $k => $vo) {
            try {
                $act = (int)$vo['payType'] == 30 ? 'balanceUnlock' : 'couponsUnlock';
                $reqJson = http_post(domain() . '/api/Candao/' . $act, ["tradeNo" => $vo['tradeNo'], 'restaurant_id' => $restaurantId]);
                $reqArr = json_decode($reqJson, true);
                $msg = $reqArr['msg'];
                if (1 != $reqArr['code'] && false === strpos($msg, '订单已取消，请勿重复提交')) {
                    Log::write('餐道会员支付-解锁余额or优惠券失败-' . $act . '：' . $vo['tradeNo']);
                    return false;
                }
            } catch (\Exception $e) {
                Log::write('餐道会员支付-解锁余额or优惠券异常-' . $act . '：' . $e->getMessage());
                return false;
            }
        }
        try {
            M('order_coupon_' . $this->tbSuffix)->where(['restaurant_id' => $restaurantId, 'order_sn' => $orderSn])->save(['status' => 0, 'update_at' => time()]);
        } catch (\Exception $e) {
            Log::write('餐道会员支付-更新优惠券状态异常-' . $act . '：' . $e->getMessage());
        }
        $payLog->where(['id' => $payRows['id']])->setField('is_del', $payLog::DEL_YES);
        return true;
    }

    /**
     * 会员支付-结账
     * @param $orderSn
     * @param $restaurantId
     * @return bool
     */
    public function memberPaySettleAccounts($orderSn, $restaurantId)
    {
        try {
            $reqJson = http_post(domain() . '/api/Candao/consume', ["order_sn" => $orderSn, 'restaurant_id' => $restaurantId, 'tb_suffix' => $this->tbSuffix]);
            $reqArr = json_decode($reqJson, true);
            if (1 == $reqArr['code']) {
                return $reqArr['data'];
            } else {
                $this->setErrMsg($reqArr['msg']);
                return false;
            }
        } catch (\Exception $e) {
            $this->setErrMsg($e->getMessage());
            return false;
        }
    }

    /**
     * 记录卡券使用
     * @param $orderSn
     * @param $restaurantId
     * @param array $paymentDetail
     * @return array
     */
    private function writeCouponAndCard($orderSn, $restaurantId, array $paymentDetail)
    {

        $couponAmount = $cardAmount = 0;//总优惠金额
        $order_voucher = $order_coupon = [];
        //解冻余额、解冻优惠券
        foreach ($paymentDetail as $k => $vo) {

            if ((int)$vo['payType'] == 30) {

                $cardAmount = bcadd($cardAmount, $vo['payAmount'], 2);
                $order_voucher[] = array(
                    'restaurant_id' => $restaurantId,
                    'order_sn' => $orderSn,
                    'card_no' => $vo['cardNo'],
                    'voucher_no' => $vo['tradeNo'],
                    'revoke_no' => '',
                    'create_at' => time(),
                );

            }

            if ((int)$vo['payType'] == 33) {
                $couponAmount = bcadd($couponAmount, $vo['payAmount'], 2);
                foreach ($vo['coupons'] as $coupon) {
                    $order_coupon[] = array(
                        'restaurant_id' => $restaurantId,
                        'order_sn' => $orderSn,
                        'coupon_id' => (int)$coupon['id'],
                        'coupon_name' => $coupon['name'],
                        'type' => (int)$coupon['type'],
                        'amount' => (float)$coupon['discount'],
                        'total_amount' => (float)$coupon['cost'],
                        'max_amount' => 0,
                        'dish_no' => '',
                        'food_name' => '',
                        'status' => 1,
                        'create_at' => time(),
                    );
                }
            }
        }

        Log::write('餐道会员支付-卡付金额：' . $cardAmount);
        Log::write('餐道会员支付-优惠金额：' . $couponAmount);

        //保存会员卡支付使用 order_voucher
        try {
            $order_voucher && M('order_voucher_' . $this->tbSuffix)->addAll($order_voucher);
        } catch (\Exception $e) {
            Log::write('餐道会员支付-保存会员卡日志失败：' . $e->getMessage());
        }
        //保存优惠券使用数据 order_coupon
        try {
            $order_coupon && M('order_coupon_' . $this->tbSuffix)->addAll($order_coupon);
        } catch (\Exception $e) {
            Log::write('餐道会员支付-保优惠券日志失败：' . $e->getMessage());
        }

        return ['couponAmount' => $couponAmount, 'cardAmount' => $cardAmount];
    }

    /**
     * 微收银聚合支付
     * @param $orderSn
     * @param $authCode
     * @param $restaurantId
     * @param $total_amount
     * @return bool
     */
    private function qwxPay($orderSn, $authCode, $restaurantId, $total_amount)
    {
        //获取配置
        $payConfig = M('config')->where(['restaurant_id' => $restaurantId, 'config_type' => 'qwxpay'])->getField('config_name,config_value');
        $qwxpay = json_decode($payConfig['qwxpay'], true);
        if (empty($qwxpay)) {
            Log::write('微收银聚合支付：参数获取失败，请确认后台配置');
            $this->setErrMsg('支付配置异常');
            return false;
        }
        $prefixNum = substr($authCode, 0, 2);
        //判断是微信 还是支付 扫码支付
        if (in_array($prefixNum, C('AL_PAY_PREFIX'))) {
            //支付宝
            $payType = self::PAY_TYPE_ALI;

        } elseif (in_array($prefixNum, C('WX_PAY_PREFIX'))) {
            //微信
            $payType = self::PAY_TYPE_WX;
        } else {
            //支付宝刷脸
            $payType = self::PAY_TYPE_ALI_FACE;
            //Log::write('微收银聚合支付：目前紧支持微信、支付宝支付');
            //echo 0;exit;
        }

        try {
            $qwxPay = new \Lib\qwxpay\Wx();
            $postParams = array(
                'body' => D("restaurant")->where(['restaurant_id' => $restaurantId])->getField("restaurant_name") ?: 'qwxpay',
                'out_trade_no' => $orderSn,
                'total_fee' => $total_amount,
                'auth_code' => $authCode,
                'pass_type' => $payType == 1 || $payType == 3 ? $qwxPay::PASS_TYPE_ALI : $qwxPay::PASS_TYPE_WX,
            );
            $rep = $qwxPay->setPayParams($qwxpay['wx'])->setPostParams($postParams)->micropay();
            if (true === $rep) {
                //获取支付信息
                $result = $qwxPay->getResult();

                //记录支付日志
                $payLog = new \Common\Model\PayLogModel();
                $logData = array(
                    'restaurant_id' => $restaurantId,
                    'order_sn' => $orderSn,
                    'pay_status' => 1,
                    'pay_amount' => $total_amount,
                    'pay_mode' => $payLog::PAY_MODE_QWXPAY,
                    'pay_type' => (3 == $payType) ? 1 : $payType,
                    'trade_num' => $result['transaction_id'],
                    'log' => json_encode($result)
                );
                $payLog->doAdd($logData);

                $saveData['pay_type'] = $payType;
                //判断是否使用混合支付
                if ($this->totalPayAmount != $total_amount) {

                    $saveData['pay_type'] = self::PAY_MIXED;
                    //实际支付金额 = 原来支付金额 - 优惠金额
                    $saveData['total_amount'] = bcsub($this->totalPayAmount, ($this->payAmounts)['couponAmount'], 2);
                    $saveData['coupon_pay'] = ($this->payAmounts)['couponAmount'];
                }

                //订单结账
                $this->billingService($orderSn, $restaurantId);

                //成功修改订单状态
                if (false === $this->updateOrderStatus(['order_sn' => $orderSn], $saveData)) {

                    $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                    return false;
                }

                //售罄处理
                $this->checkSellOut($orderSn);
                $this->setTradeStatus(self::TRADE_STATUS_COMPLETE_PAY);
                return true;
            }
            Log::write('微收银聚合支付：' . $qwxPay->getError());
            $this->setErrMsg($qwxPay->getError());
        } catch (\Exception $e) {
            Log::write('微收银聚合支付：' . $e->getMessage());
            $this->setErrMsg($e->getMessage());
        }

        return false;
    }

    /**
     * 杉德支付聚合支付
     * @param $orderSn
     * @param $authCode
     * @param $restaurantId
     * @param $total_amount
     * @param $payType
     * @return bool
     */
    private function shandePay($orderSn, $authCode, $restaurantId, $total_amount, $payType, $business_id)
    {
        if (!$this->checkPaySelectIsOpen($restaurantId, ($this->paySelectModel)::PAY_SHANDE)) {
            $this->setErrMsg('杉德支付配置信息异常');
            return false;
        }

        #获取杉德支付配置
        $restaurant_info = M('config')->field('config_name,config_value')->where(['config_type' => 'shandepay', 'restaurant_id' => $restaurantId])->select();
        $restaurant_info = dealConfigKeyForValue($restaurant_info);
        Log::write('杉德支付配置信息：' . json_encode($restaurant_info, JSON_UNESCAPED_UNICODE));

        if (empty($restaurant_info)) {
            $this->setErrMsg('杉德支付配置信息异常');
            return false;
        }

        $prefixNum = substr($authCode, 0, 2);
        //判断支付码是微信还是支付宝
        if ($payType == 4) {//微信刷脸支付
            $payType = self::PAY_TYPE_WX_FACE;
        } elseif (in_array($prefixNum, C('AL_PAY_PREFIX'))) {
            $payChannelTypeNo = '0103';
            $payType = self::PAY_TYPE_ALI;
        } elseif (in_array($prefixNum, C('WX_PAY_PREFIX'))) {
            $payChannelTypeNo = '0203';
            $payType = self::PAY_TYPE_WX;
        } else {
            $payChannelTypeNo = '';
            $payType = 0;
        }

        //检测总代理是否设置了服务配置
        $BusinessShandePayConfigModel = new BusinessShandePayConfigModel();
        $agentShandePayConfig = $BusinessShandePayConfigModel->getShandePayConfig($business_id);

        $app_id = !empty($agentShandePayConfig['app_id']) ? $agentShandePayConfig['app_id'] : '552020042420160';//商户号
        //$app_id = !empty($agentShandePayConfig['app_id']) ? $agentShandePayConfig['app_id']: '663101000017582';//商户号
        $sub_app_id = !empty($agentShandePayConfig['sub_app_id']) ? $agentShandePayConfig['sub_app_id'] : $restaurant_info['shande_sub_mchno'];//子商户号
        $store_id = !empty($agentShandePayConfig['store_id']) ? $agentShandePayConfig['store_id'] : '100001';//门店号
        $privateKey = !empty($agentShandePayConfig['private_key']) ? $agentShandePayConfig['private_key'] : '';

        $method = "trade.pay";//接口方法
        $timestamp = date("Y-m-d h:i:s");
        $nonce = time();
        $createIp = $_SERVER['REMOTE_ADDR'];//IP地址
        $body = 'shandepay';

        $tradePrecreate = [//公共参数+方法需要传的参数
            'app_id' => $app_id,
            'sub_app_id' => $sub_app_id,
            'method' => $method,
            'timestamp' => $timestamp,
            'nonce' => $nonce,
            'auth_code' => $authCode,
            'create_ip' => $createIp,
            'total_amount' => $total_amount,
            'out_order_no' => $orderSn,
            'body' => $body,
            'store_id' => $store_id,
        ];

        $tradePrecreateRequest = json_encode($tradePrecreate, JSON_UNESCAPED_UNICODE);

        $tradeRequest = [//公共参数
            'app_id' => $app_id,
            'sub_app_id' => $sub_app_id,
            'method' => $method,
            'timestamp' => $timestamp,
            'nonce' => $nonce,
            'biz_content' => $tradePrecreateRequest,
        ];
        Log::write('调用杉德支付接口所传递的参数：' . json_encode($tradeRequest, JSON_UNESCAPED_UNICODE));
        $shande = new ShandeController();

        $result = $shande->execute($shande->request($tradeRequest, $privateKey));
        $data = json_decode($result['data'], true);

        if ($result['code'] == '200' && $data['sub_code'] == 'SUCCESS') {
            #成功修改订单状态
            $order_data['pay_type'] = $payType;
            $order_data['order_status'] = 3;
            if (false === $this->updateOrderStatus(['order_sn' => $orderSn], $order_data)) {
                $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                return false;
            }

            //售罄处理
            $this->checkSellOut($orderSn);
            $this->setTradeStatus(self::TRADE_STATUS_COMPLETE_PAY);
            return true;

        } else if ($result['code'] == '200' && $data['sub_code'] == 'WAITING_PAYMENT') {
            $tag = 2;
            while ($tag == 2) {
                $queryOrderData = [//公共参数+方法需要传的参数
                    'app_id' => $app_id,
                    'sub_app_id' => $sub_app_id,
                    'method' => 'trade.query',
                    'timestamp' => $timestamp,
                    'nonce' => $nonce,
                    'order_create_time' => date('YmdHis', time()),
                    'out_order_no' => $orderSn,

                ];

                $queryOrderDataRequest = json_encode($queryOrderData, JSON_UNESCAPED_UNICODE);

                $queryOrderDataTradeRequest = [//公共参数
                    'app_id' => $app_id,
                    'sub_app_id' => $sub_app_id,
                    'method' => 'trade.query',
                    'timestamp' => $timestamp,
                    'nonce' => $nonce,
                    'biz_content' => $queryOrderDataRequest,
                ];

                $queryOrderResult = $shande->execute($shande->request($queryOrderDataTradeRequest));
                $queryOrderResultArr = json_decode($queryOrderResult['data'], true);
                if ($queryOrderResultArr['sub_code'] == 'SUCCESS') {
                    $tag = 1;
                } else if ($queryOrderResultArr['sub_code'] == 'FAILED') {
                    $tag = 0;
                }
            }

            if ($tag == 1) {
                #成功修改订单状态
                $order_data['pay_type'] = $payType;
                $order_data['order_status'] = 3;
                if (false === $this->updateOrderStatus(['order_sn' => $orderSn], $order_data)) {
                    $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                    return false;
                }

                //售罄处理
                $this->checkSellOut($orderSn);
                $this->setTradeStatus(self::TRADE_STATUS_COMPLETE_PAY);
                return true;
            }

            $this->setErrMsg('支付失败');
            return false;

        } else {
            $this->setErrMsg('支付失败');
            return false;
        }
    }

    /**
     * 微信支付
     * @param $orderSn 订单号
     * @param $authCode 支付条码
     * @param $restaurantId 店铺ID
     * @param $total_amount 支付金额
     * @param $mode 支付通道
     * @return bool
     */
    private function wxPay($orderSn, $authCode, $restaurantId, $total_amount, $mode)
    {
        $store_id = M('chen_sen')->where(array('restaurant_id' => $restaurantId))->getField('alipay_store_id');
        $where['restaurant_id'] = $restaurantId;
        $restaurant_name = D("restaurant")->where($where)->getField("restaurant_name");

        #mode为2普通微信 mode为1服务商
        $configName = (2 == $mode) ? ($this->paySelectModel)::PAY_OY_WX : ($this->paySelectModel)::PAY_PRO_WX;
        if (!$this->checkPaySelectIsOpen($restaurantId, $configName)) {
            $this->setErrMsg('支付未开启');
            return false;
        }

        #将官方提供的订单号存在记录中
        $business_order = $orderSn;
        $this->orderObj->where(array('order_sn' => $orderSn))->save(array('saoma_out_trade_no' => $business_order));
        $price = $total_amount * 100;

        if (2 == $mode) {
            require getcwd() . "/Application/PayMethod/WxpayMicropay2/lib/WxPay.Data.php";
            try {
                $input = new \WxPayMicroPay();
                $input->SetAuth_code($authCode);
                $input->SetBody($restaurant_name);
                $input->SetTotal_fee($price);
                $input->setSceneInfo(json_encode(['store_info' => ['id' => $store_id]]));
                $input->SetOut_trade_no($business_order);
                $microPay = new MicroPay_1();
                //维修支付成功后查询支付对应的openid 开始 20200401
                try {
                    $openidInput = new \AuthCodetoOpenid();
                    $openidInput->SetAuthcode($authCode);
                    $WxPayApi = new \WxPayApi();
                    $queryOpenId = $WxPayApi->authcodetoopenid($openidInput);
                    $returnData = $openidInput->FromXml($queryOpenId);
                    \Think\Log::record(json_encode($returnData), 'ERR');
                    if ($returnData['return_code'] == 'SUCCESS' && $returnData["result_code"] == "SUCCESS") {
                        $data['openid'] = $returnData['openid'];
                    }
                } catch (Exception $e) {
                    Log::write('微信支付：' . $mode . $e->getMessage());
                }

                //维修支付成功后查询支付对应的openid 结束 20200401

                try {
                    $result = $microPay->pay($input);
                } catch (\Exception $e) {
                    Log::write('微信支付异常：' . $mode . $e->getMessage());
                    $num = 10;
                    while ($num > 0) {
                        --$num;
                        $succResult = 0;
                        $result = $microPay->query($business_order, $succResult);
                        if (is_array($result) || $succResult == 0) break;
                        sleep(1);
                    }
                }

            } catch (\Exception $e) {
                $this->setErrMsg('支付失败：' . $e->getMessage());
                return false;
            }
        } else {
            require getcwd() . "/Application/PayMethod/WxpayMicropay/lib/WxPay.Data.php";
            try {
                $input = new \WxPayMicroPay();
                $input->SetAuth_code($authCode);
                $input->SetBody($restaurant_name);
                $input->SetTotal_fee($price);
                #将官方提供的订单号存在记录中
                $input->SetOut_trade_no($business_order);
                $input->SetSub_mch_id(\WxPayConfig::$SUB_MCHID);
                $microPay = new MicroPay();

                try {
                    $result = $microPay->pay($input);
                } catch (\Exception $e) {
                    Log::write('微信支付异常：' . $mode . $e->getMessage());
                    $num = 10;
                    while ($num > 0) {
                        --$num;
                        $succResult = 0;
                        $result = $microPay->query($business_order, $succResult);
                        if (is_array($result) || $succResult == 0) break;
                        sleep(1);
                    }
                }

            } catch (\Exception $e) {
                $this->setErrMsg('支付失败：' . $e->getMessage());
                return false;
            }
        }

        if (empty($result) || (isset($result["trade_state"]) && $result["trade_state"] != 'SUCCESS')) {
            $msg = isset($result['err_code_des']) ? $result['err_code_des'] : '';
            $this->setErrMsg('支付失败' . $msg);
            return false;
        }

        if ($result["return_code"] == "SUCCESS" && $result["result_code"] == "SUCCESS") {

            //记录订单支付日志
            $logData = array(
                'restaurant_id' => $restaurantId,
                'order_sn' => $orderSn,
                'pay_status' => 1,
                'pay_amount' => bcdiv($result['total_fee'], 100, 2),
                'pay_mode' => $mode,
                'pay_type' => 2,
                'trade_num' => $result['transaction_id'],
                'log' => json_encode($result)
            );
            (new \Common\Model\PayLogModel())->doAdd($logData);

            #操作数据库处理订单信息；
            //$orderModel = order();
            $o_condition['order_sn'] = $orderSn;
            $data['order_status'] = 1;
            $data['pay_type'] = 2;
            $time = time();
            $data['pay_time'] = $time;

            //如果优惠金额大于0，即有使用优惠券，就把优惠信息存进表里
            if ($result['coupon_fee']) {
                $benefit_money = round($result["coupon_fee"] / 100, 2);
                $data["benefit_money"] = $benefit_money;
                $data["coupon_name"] = '微信' . $benefit_money . '元优惠券';
                $result['coupon_id_0'] && $data["coupon_id"] = $result['coupon_id_0'];
            }

            //判断是否使用混合支付
            if ($this->totalPayAmount != $total_amount) {

                $data['pay_type'] = self::PAY_MIXED;
                //实际支付金额 = 原来支付金额 - 优惠金额
                $data['total_amount'] = bcsub($this->totalPayAmount, ($this->payAmounts)['couponAmount'], 2);
                $data['coupon_pay'] = ($this->payAmounts)['couponAmount'];

            }

            //订单结账
            $this->billingService($orderSn, $restaurantId);

            //更新订单
            $rel = $this->updateOrderStatus($o_condition, $data);
            if ($rel !== false) {
                #是否售罄处理
                $this->checkSellOut($orderSn);
                $this->setTradeStatus(self::TRADE_STATUS_COMPLETE_PAY);
                return true;
            } else {
                $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                return false;
            }

        } else {
            $this->setErrMsg($result["return_msg"]);
            return false;
        }
    }

    /**
     * 支付宝
     * @param $orderSn 订单号
     * @param $authCode 支付条码
     * @param $restaurantId 店铺id
     * @param $total_amount 支付金额
     * @param $mode 通道模式
     * @param $scene 条码类型 security_code,bar_code
     * @return bool
     */
    private function aliPay($orderSn, $authCode, $restaurantId, $total_amount, $mode, $scene)
    {
        //判断 1=服务商,2=普通支付
        $configName = ($mode == 1) ? ($this->paySelectModel)::PAY_PRO_ALI : ($this->paySelectModel)::PAY_OY_ALI;
        if (!$this->checkPaySelectIsOpen($restaurantId, $configName)) {
            $this->setErrMsg('支付未开启');
            return false;
        }

        $restaurant_name = D("restaurant")->where(['restaurant_id' => $restaurantId])->getField("restaurant_name");
        $payConfig = array(
            'out_trade_no' => $orderSn,
            'total_amount' => $total_amount,
            'auth_code' => $authCode,
            'subject' => $restaurant_name ?: 'subject',
            'scene' => $scene,
        );

        try {

            $payConfig = array_merge($payConfig, $this->getAlipayParam($restaurantId, $mode));

            $pay = new \Common\Logic\Alipay\Alipay($payConfig);
            $result = ($mode == 1) ? $pay->serviceBarcodePay() : $pay->barcodePay();
            //获取支付接口响应参数
            $response = $result->getResponse();
            if ('SUCCESS' == $result->getTradeStatus()) {

                //记录订单支付日志
                $logData = array(
                    'restaurant_id' => $restaurantId,
                    'order_sn' => $orderSn,
                    'pay_status' => 1,
                    'pay_amount' => $response->total_amount,
                    'pay_mode' => $mode,
                    'pay_type' => 1,
                    'trade_num' => $response->trade_no,
                    'log' => json_encode($response, JSON_FORCE_OBJECT)
                );
                (new \Common\Model\PayLogModel())->doAdd($logData);

                //更新订单支付方式
                $o_condition['order_sn'] = $orderSn;
                $data['pay_type'] = ($scene == 'security_code') ? self::PAY_TYPE_ALI_FACE : self::PAY_TYPE_ALI; //支付宝

                //如果响应参数有voucher_detail_list字段，即有使用到优惠券，保存优惠券信息
                if (isset($response->voucher_detail_list)) {
                    $data['benefit_money'] = $response->voucher_detail_list[0]->amount;
                    $data['coupon_id'] = $response->voucher_detail_list[0]->id;
                    $data['coupon_name'] = $response->voucher_detail_list[0]->name;
                }

                //判断是否使用混合支付
                if ($this->totalPayAmount != $total_amount) {
                    $data['pay_type'] = self::PAY_MIXED;
                    //实际支付金额 = 原来支付金额 - 优惠金额
                    $data['total_amount'] = bcsub($this->totalPayAmount, ($this->payAmounts)['couponAmount'], 2);
                    $data['coupon_pay'] = ($this->payAmounts)['couponAmount'];
                }

                //订单结账
                $this->billingService($orderSn, $restaurantId);

                //更新订单
                $rel = $this->updateOrderStatus($o_condition, $data);
                if ($rel !== false) {
                    //是否售罄处理
                    $this->checkSellOut($orderSn);
                    $this->setTradeStatus(self::TRADE_STATUS_COMPLETE_PAY);
                    return true;
                } else {
                    $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                    return false;
                }

            } else {
                $this->setErrMsg(isset($response->msg) ? '支付失败:' . $response->msg : ('支付失败：' . isset($response->sub_msg) ? $response->sub_msg : ''));
                return false;
            }

        } catch (\Exception $e) {
            $this->setErrMsg($e->getMessage());
            return false;
        }

    }

    /**
     * 支付宝参数
     * @param $restaurantId
     * @param $mode
     * @return array
     * @throws \Exception
     */
    private function getAlipayParam($restaurantId, $mode)
    {
        $payConfig = [];
        //获取店铺支付参数
        if ($mode == 1) {

            //服务商参数
            $aat_rel = M("restaurant_other_info")->where(['restaurant_id' => $restaurantId])->find();
            if (empty($aat_rel) || empty($aat_rel['app_auth_token'])) {
                throw new \Exception('商户未授权系统服务商');
            }

            $payConfig['app_auth_token'] = $aat_rel['app_auth_token'];

            $business_provider_set_data = (new \Api\Model\BusinessProviderSetModel)->getAlipayProviderSetPaymentParams($this->businessId);
            if ($business_provider_set_data) {
                $payConfig['alipay_public_key'] = $business_provider_set_data['alipay_public_key'];
                $payConfig['merchant_private_key'] = $business_provider_set_data['merchant_private_key'];
                $payConfig['app_id'] = $business_provider_set_data['app_id'];
                $payConfig['sign_type'] = $business_provider_set_data['sign_type'];
            }

        } else {

            //普通当面付参数
            $rows = D('config')->where(['restaurant_id' => $restaurantId, 'config_type' => ($this->paySelectModel)::PAY_OY_ALI])->select();
            $configArr = dealConfigKeyForValue($rows);
            //支付宝公钥
            $payConfig['alipay_public_key'] = $configArr['oyalipay_public_key'];
            //商户私钥
            $payConfig['merchant_private_key'] = $configArr['oyalipay_private_key'];
            //应用ID
            $payConfig['app_id'] = $configArr['oyalipay_appid'];
            isset($configArr['store_id']) && !empty($configArr['store_id']) && $payConfig['store_id'] = $configArr['store_id'];
            isset($configArr['signType']) && !empty($configArr['signType']) && $payConfig['signType'] = $configArr['signType'];

        }
        return $payConfig;
    }

    /**
     * 款易支付
     * @param $orderSn
     * @param $authCode
     * @param $restaurantId
     * @param $total_amount
     * @return bool
     */
    private function kuanyiPay($orderSn, $authCode, $restaurantId, $total_amount)
    {
        $pNum = substr($authCode, 0, 2);
        $payType = in_array($pNum, C('AL_PAY_PREFIX')) ? 1 : (in_array($pNum, C('WX_PAY_PREFIX')) ? 2 : 0);
        if (!$payType) {
            /*$this->setErrMsg('请使用支付宝或微信支付');
            return false;*/
            return $this->kuanyiMemPay($orderSn, $authCode, $restaurantId, $total_amount);
        }

        $opcMod = new \Common\Model\OpenPlatformConfigModel();
        $oConfig = $opcMod->get(['restaurant_id' => $restaurantId, 'type' => $opcMod::TYPE_KUANYI, 'status' => $opcMod::STATUS_ENABLE]);
        if (empty($oConfig)) {
            $this->setErrMsg('款易支付服务配置异常');
            return false;
        }
        $configParam = unserialize($oConfig['config']);
        try {
            $pay = \Lib\kuanyipay\KuanYiPay::instance(is_array($configParam) ? $configParam : []);

            $isPay = false;
            //发起请求成功 并未确认付款结果
            if ($pay->barpay(['outOrderNo' => $orderSn, 'bar_code' => $authCode, 'price' => $total_amount])) {

                //获取订单支付结果
                $n = 20;
                while ($n > 0) {
                    --$n;
                    if ($pay->barquery(['outOrderNo' => $orderSn])) {
                        $res = $pay->getResult();
                        if (isset($res['data']['pay_status']) && $res['data']['pay_status'] == 2) {
                            $isPay = true;
                            break;
                        }

                        if (is_array($res) && !isset($res['data']['trade_no'])) {
                            break;
                        }

                        if (isset($res['data']['trade_no']) && !empty($res['data']['trade_no'])) {
                            if ($n < 5) $n = 20;
                            sleep(2);
                            continue;
                        }
                    }
                    sleep(1);
                }

                //支付成功
                if ($isPay) {
                    //记录订单支付日志
                    $payLog = new \Common\Model\PayLogModel();
                    $logData = array(
                        'restaurant_id' => $restaurantId,
                        'order_sn' => $orderSn,
                        'pay_status' => 1,
                        'pay_amount' => $total_amount,
                        'pay_mode' => $payLog::PAY_MODE_KUANYIPAY,
                        'pay_type' => in_array(substr($authCode, 0, 2), C('AL_PAY_PREFIX')) ? 1 : in_array(substr($authCode, 0, 2), C('WX_PAY_PREFIX')) ? 2 : 0,
                        'trade_num' => $res['data']['trade_no'],
                        'log' => json_encode($res['data'], JSON_FORCE_OBJECT)
                    );
                    $payLog->doAdd($logData);

                    //更新订单支付方式
                    $o_condition['order_sn'] = $orderSn;
                    $data['pay_type'] = $logData['pay_type'];

                    //判断是否使用混合支付
                    if ($this->totalPayAmount != $total_amount) {
                        $data['pay_type'] = self::PAY_MIXED;
                        //实际支付金额 = 原来支付金额 - 优惠金额
                        $data['total_amount'] = bcsub($this->totalPayAmount, ($this->payAmounts)['couponAmount'], 2);
                        $data['coupon_pay'] = ($this->payAmounts)['couponAmount'];
                    }

                    //更新订单
                    $rel = $this->updateOrderStatus($o_condition, $data);
                    if ($rel !== false) {
                        //是否售罄处理
                        $this->checkSellOut($orderSn);
                        $this->setTradeStatus(self::TRADE_STATUS_COMPLETE_PAY);
                        return true;
                    } else {
                        $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                        return false;
                    }

                }

                $this->setErrMsg('支付失败');
                return false;
            }

            $this->setErrMsg($pay->getError());
            Log::write('款易支付-失败' . $pay->getError());
            return false;

        } catch (\Exception $e) {
            Log::write('款易支付-异常' . $e->getMessage());
            $this->setErrMsg($e->getMessage());
            return false;
        }
    }

    /**
     * 款易会员支付
     * @param $orderSn
     * @param $authCode
     * @param $restaurantId
     * @param $total_amount
     * @return bool
     */
    private function kuanyiMemPay($orderSn, $authCode, $restaurantId, $total_amount)
    {

        $opcMod = new \Common\Model\OpenPlatformConfigModel();
        $oConfig = $opcMod->get(['restaurant_id' => $restaurantId, 'type' => $opcMod::TYPE_KUANYI, 'status' => $opcMod::STATUS_ENABLE]);
        if (empty($oConfig)) {
            $this->setErrMsg('款易支付服务配置异常');
            return false;
        }
        $configParam = unserialize($oConfig['config']);
        try {
            $pay = \Lib\kuanyipay\MemberPay::instance(is_array($configParam) ? $configParam : []);

            $isPay = false;

            //查询会员码ID
            if (!$pay->queryMemberInfo(['customer_code'=>$authCode])) {
                $this->setErrMsg('支付失败：'.$pay->getError());
                return false;
            }

            $memInfo = $pay->getResult();
            $customerId = isset($memInfo['data']['member_info']['customer_id']) ? $memInfo['data']['member_info']['customer_id'] : '';
            if (!$customerId) {
                $this->setErrMsg('支付失败：获取会员ID异常');
                return false;
            }

            $balance =  isset($memInfo['data']['accounts']['balance']) ? $memInfo['data']['accounts']['balance'] : 0;
            //判断余额是否够支付
            if ($balance < bcmul($total_amount, 100, 0)) {
                $this->setErrMsg('支付失败：余额不足');
                return false;
            }

            //发起请求成功 并未确认付款结果
            if ($pay->codepay(['outOrderNo' => $orderSn, 'customer_id' => $customerId, 'price' => $total_amount])) {
                $payResult = $pay->getResult();
                if (isset($payResult['data']['result']) && (true == $payResult['data']['result'])) $isPay = true;

                //支付成功
                if ($isPay) {
                    //记录订单支付日志
                    $payLog = new \Common\Model\PayLogModel();
                    $logData = array(
                        'restaurant_id' => $restaurantId,
                        'order_sn' => $orderSn,
                        'pay_status' => 1,
                        'pay_amount' => $total_amount,
                        'pay_mode' => $payLog::PAY_MODE_KUANYIPAY,
                        'pay_type' => self::PAY_TYPE_MEMBER,
                        'trade_num' => '',
                        'log' => json_encode(['customer_id'=>$customerId])
                    );
                    $payLog->doAdd($logData);

                    //更新订单支付方式
                    $o_condition['order_sn'] = $orderSn;
                    $data['pay_type'] = $logData['pay_type'];

                    //判断是否使用混合支付
                    if ($this->totalPayAmount != $total_amount) {
                        $data['pay_type'] = self::PAY_MIXED;
                        //实际支付金额 = 原来支付金额 - 优惠金额
                        $data['total_amount'] = bcsub($this->totalPayAmount, ($this->payAmounts)['couponAmount'], 2);
                        $data['coupon_pay'] = ($this->payAmounts)['couponAmount'];
                    }

                    //更新订单
                    $rel = $this->updateOrderStatus($o_condition, $data);
                    if ($rel !== false) {
                        //是否售罄处理
                        $this->checkSellOut($orderSn);
                        $this->setTradeStatus(self::TRADE_STATUS_COMPLETE_PAY);
                        return true;
                    } else {
                        $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                        return false;
                    }

                }

                $this->setErrMsg('支付失败');
                return false;
            }

            $this->setErrMsg($pay->getError());
            Log::write('款易支付-失败' . $pay->getError());
            return false;

        } catch (\Exception $e) {
            Log::write('款易支付-异常' . $e->getMessage());
            $this->setErrMsg($e->getMessage());
            return false;
        }
    }
}