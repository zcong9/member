<?php

namespace Common\Logic\Alipay;

class Alipay
{
    var $config = array(
        'app_id' => '2019112269370740',
        'charset' => 'UTF-8',
        'gatewayUrl' => 'https://openapi.alipay.com/gateway.do',
        'notify_url' => 'https://newpos.founpad.com/index.php/api/AlipayDirect/notify',
        'MaxQueryRetry' => '10',
        'QueryDuration' => '3',
        'sign_type' => 'RSA2',
        'alipay_public_key' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgTupmf95+jeZv5vj7mcN3Uwi9jwarfdjM0/MErdu/ofKAWRRSf77pqZwwLznLmEPPMeY6iDwtQM2HS8Z+5KGX0bInuVNfNw4Sdi8/3/NnC3b4V4y1V+sbZ+lR5BLzGNf2lFgkbblGB/a1UO6wok33Uvtx1ymzaFo+MsN1ECqo2pQAclVfcvirx9wxWAxd9Nkelr9QgOjkjXWgrghP8P/VfD7aex6Hniq8tz65wBYTcXCJI3ruOi09GbLkeqPf9H6lFhzoRsrjueAaxGdvtnGILWrx3He3NYEP42On/t3lawp333V+UoFUqpT+cGGTYt582Pywm8saV3a/wFMq3+UcwIDAQAB',
        'merchant_private_key' => 'MIIEpQIBAAKCAQEAw+fpq9Gbl+HAwi3/ScvgJw17QBUTe2Rey6t0x23lrCfioHUvKNaqxY6yY1gURzx9mRaZthsvJzoj7tnNGreb5K20w66fuNHyA/LxikceUNGyIMVNdCWOOgo42r5MfQqx7oFMmnSfUqWIa382uKkA286cyfw6C+C5Rw92vbfv+s/AK4Hp2My96yVbPKlR9WHllEVLErNyS2U5Tf9K4Lm0K/VMky2i0p7+KWi+PMzq4LyuNw5GUJxBfDtyAgK19sQhTwlxNnn6XoUhCv9OLXvQGmvymyO9N71rhzHd0YqEey+CFPkbv/JM9CiupfxbFQeiRPGAbskEBcIEq2c8Q/oKkwIDAQABAoIBAFN8jKdtX0p9qaDW61luqeraovCvSqsmHgPb4JtwqRURtlG9Psi/mu0wH7OYgKPPEpNf/0eNFC46Z7/NT8wX/TaaFFPkIisoRWQLb4YHQtMcWjX+/0AFFTSE0K/fs0cCfMtwjM2x74fQBXASOaa+VyBVT5oAhFg1f5/Z5jd5oKqYiZs8StRqVmIT/Zljg0+0za4Uni4Lp7CN8dObV6wB78fZa0Usx5VijROQ+i7q3OsQVuWSSi6EzH/eQQ4KO0sPX1DggCD/L8xYa4GGWBLQEghbk3ka1RiEbaKonTNA75er22hSAJwPrI63FTpQ3cM3O94G5d8SNzwaS8PMHQjs9EkCgYEA5CmpUMzp62OddF5pE5lUztC7Vd5Mx0l9OjvIMTurbgZYjBDCgENafMaowW+un8wVySJfT70kJYPkBrfGoadoUq4Y2WedK0yUHiY9uni/GiMegoR6iA1r055hp/1ZOioXUh2KmaukH66QyDHJvkPbA8rfE4tM1j4P8cpa+esBfN0CgYEA287BUxM5/mwMJzz7R9XXDRzsiW7KZch75aYEXP55gplslUIi3M3aPRQyLAHziPF/YVGlPX70o8TW5IutkihqONMnRMuYtOVfti7Y3NA5l1aRwRxQS2+LpBJxhpe0Rnh6IrXx/xhdBS9XY8Tng5UCD2Hpi6QjKf3VuyieL107ti8CgYEAmvDzyywsmi4+qdzHLIkOv5ed8DUTHK56PQaF73Ee/IuQrCVhgCq9E0jxJtNJ2biE/t65rPO7zUIgorNAT1zZCnSx6UlkwRey6jp75trCo+Q/ftCqSSQcGkxO8v6oDkixJ5FqIusdfGpWZazx3KRF4fBtxt7tIfxpZYBOgbMmgn0CgYEAkA1R+WXSTgD1fgmjDJMCGt/nzLHFByt6tyg0F9XWQFbYKIFtY5OtAPZpYxnsRsUuG9NsHX9ESMfJpYI8wFqoMpF/XMCpVXQ1Y6oUCbKU66+aWhp6LNXviBlmOTTWupBeSr0+2VVYMPuzo/j5WOygqwAaFJ//Q5fNKJkYAiZx6ZUCgYEA4CoEzde6piZZdpN6pjtsnKkhm+oWsTzhsYFlf9Vck/PaSJFUGAfBuT/ftI6f+j4pAe7Vu21ntcSlTAalmxipyIPjwzM5fb1DhD5AJQAGJcURpIy/5EJgxUyR5mrYQ5QFjCDopSW98swgtH53+NLZPxe1e6zOGyYBzvB9Iq92ros=',
        'out_trade_no' => '',
        'total_amount' => '',
        'auth_code' => '',
        'store_id' => '',
        'alipay_store_id' => '',
        'body' => '',
        'seller_id' => '',
        'app_auth_token' => '201911BB6dabf6b9e8a44a569026890e93475B21',
        'subject' => '',
        'cacert' => '',
        'timeout_express' => '5m',//支付超时，线下扫码交易定义为5分钟
        'sys_service_provider_id' => '2088621244519152',//系统商pid,作为系统商返佣数据提取的依据
        'undiscountable_amount' => '0.00',
        'scene' => 'bar_code',
        'goods_detail_list' => array(),
        'operator_id' => '',
    );

    public function __construct($config = array())
    {
        $this->config = array_merge($this->config, $config);
        //设置证书路径
        $this->cacert = $this->cacert ?: getcwd() . 'cacert.pem';
    }

    /**
     * 使用 $this->name=$value    配置参数
     * @param  string $name 配置名称
     * @param  string $value 配置值
     */
    public function __set($name, $value)
    {
        if (isset($this->config[$name])) {
            $this->config[$name] = $value;
        }
    }

    /**
     * 使用 $this->name 获取配置
     * @param  string $name 配置名称
     * @return multitype    配置值
     */
    public function __get($name)
    {
        return $this->config[$name];
    }

    public function __isset($name)
    {
        return isset($this->config[$name]);
    }


    /**
     * 服务商当面付
     * @return \AlipayF2FPayResult|mixed
     * @throws \Exception
     */
    public function serviceBarcodePay()
    {
        try {
            Vendor('alipayf2f.f2fpay.service.AlipayTradeService');
            Vendor('alipayf2f.f2fpay.model.builder.AlipayTradePayContentBuilder'); //条码支付请求bizContent结构体

            // 业务扩展参数，目前可添加由支付宝分配的系统商编号(通过setSysServiceProviderId方法)，详情请咨询支付宝技术支持
            //$providerId = "2088621244519152"; //系统商pid,作为系统商返佣数据提取的依据
            $extendParams = new \ExtendParams();
            $extendParams->setSysServiceProviderId($this->sys_service_provider_id);
            $extendParamsArr = $extendParams->getExtendParams();

            // 创建请求builder，设置请求参数
            $barPayRequestBuilder = new \AlipayTradePayContentBuilder();

            // (必填) 商户网站订单系统中唯一订单号，64个字符以内，只能包含字母、数字、下划线，
            // 需保证商户系统端不能重复，建议通过数据库sequence生成，
            $barPayRequestBuilder->setOutTradeNo($this->out_trade_no);

            // (必填) 订单总金额，单位为元，不能超过1亿元
            // 如果同时传入了【打折金额】,【不可打折金额】,【订单总金额】三者,则必须满足如下条件:【订单总金额】=【打折金额】+【不可打折金额】
            $barPayRequestBuilder->setTotalAmount($this->total_amount);

            // (必填) 付款条码，用户支付宝钱包手机app点击“付款”产生的付款条码
            $barPayRequestBuilder->setAuthCode($this->auth_code);

            // 支付超时，线下扫码交易定义为5分钟
            $barPayRequestBuilder->setTimeExpress($this->time_express);

            // (必填) 订单标题，粗略描述用户的支付目的。如“XX品牌XXX门店消费”
            //$subject = '方雅点餐系统';
            $barPayRequestBuilder->setSubject($this->subject);

            // 订单描述，可以对交易或商品进行一个详细地描述，比如填写"购买商品2件共15.00元"
            $barPayRequestBuilder->setBody($this->body);

            // (可选,根据需要使用) 订单可打折金额，可以配合商家平台配置折扣活动，如果订单部分商品参与打折，可以将部分商品总价填写至此字段，默认全部商品可打折
            // 如果该值未传入,但传入了【订单总金额】,【不可打折金额】 则该值默认为【订单总金额】- 【不可打折金额】
            $barPayRequestBuilder->setUndiscountableAmount($this->undiscountable_amount);

            $barPayRequestBuilder->setExtendParams($extendParamsArr);

            // 商品明细列表，需填写购买商品详细信息
            $barPayRequestBuilder->setGoodsDetailList($this->goods_detail_list);

            // (可选) 商户门店编号，通过门店号和商家后台可以配置精准到门店的折扣信息，详询支付宝技术支持
            $barPayRequestBuilder->setStoreId($this->store_id);

            //商户操作员编号，添加此参数可以为商户操作员做销售统计
            $barPayRequestBuilder->setOperatorId($this->operator_id);

            // 支付宝的店铺编号
            $barPayRequestBuilder->setAlipayStoreId($this->alipay_store_id);

            //第三方应用授权令牌,商户授权系统商开发模式下使用
            $barPayRequestBuilder->setAppAuthToken($this->app_auth_token);

            //判断是扫码 还是 刷脸 扫码
            $barPayRequestBuilder->setScene($this->scene);

            $alipayConfig = array(
                //支付宝公钥
                'alipay_public_key' => $this->alipay_public_key,
                //加签方式
                'sign_type' => $this->sign_type,
                //商户私钥
                'merchant_private_key' => $this->merchant_private_key,
                //编码格式
                'charset' => $this->charset,

                //支付宝网关
                'gatewayUrl' => $this->gatewayUrl,

                //应用ID
                'app_id' => $this->app_id,

                //异步通知地址,只有扫码支付预下单可用
                //'notify_url' => $this->notify_url,

                //最大查询重试次数
                'MaxQueryRetry' => $this->MaxQueryRetry,

                //查询间隔
                'QueryDuration' => $this->QueryDuration,

            );

            // 调用barPay方法获取当面付应答
            $barPay = new \AlipayTradeService($alipayConfig); //当面付2.0服务实现，包括条码支付（带轮询）、扫码支付、消费查询、消费退款
            $barPayResult = $barPay->barPay($barPayRequestBuilder);
            self::log(var_export($barPayResult, true));

            return $barPayResult;

        } catch (\Exception $e) {
            self::log($e->getMessage());
            throw new \Exception($e->getMessage());
        }

    }

    /**
     * 支付宝条码支付 普通商户
     * @return \AlipayF2FPayResult|mixed
     * @throws \Exception
     */
    public function barcodePay()
    {
        try {

            // 判断是RSA还是RSA2
            if ($this->sign_type == "RSA") {
                Vendor('alipayf2f.f2fpay.service.AlipayTradeService');
                Vendor('alipayf2f.f2fpay.model.builder.AlipayTradePayContentBuilder'); //条码支付请求bizContent结构体
            } else {
                Vendor('alipayf2f2.f2fpay.service.AlipayTradeService');
                Vendor('alipayf2f2.f2fpay.model.builder.AlipayTradePayContentBuilder'); //条码支付请求bizContent结构体
            }

            // 创建请求builder，设置请求参数
            $barPayRequestBuilder = new \AlipayTradePayContentBuilder();
            $barPayRequestBuilder->setOutTradeNo($this->out_trade_no);
            $barPayRequestBuilder->setTotalAmount($this->total_amount);
            $barPayRequestBuilder->setAuthCode($this->auth_code);
            $barPayRequestBuilder->setTimeExpress($this->time_express);
            $barPayRequestBuilder->setSubject($this->subject);
            $barPayRequestBuilder->setBody($this->body);
            $barPayRequestBuilder->setUndiscountableAmount($this->undiscountable_amount);
            $barPayRequestBuilder->setGoodsDetailList($this->goods_detail_list);
            $barPayRequestBuilder->setStoreId($this->store_id);
            $barPayRequestBuilder->setAlipayStoreId($this->alipay_store_id);
            //$barPayRequestBuilder->setOperatorId($this->operator_id);
            $barPayRequestBuilder->setScene($this->scene);

            $alipayConfig = array(
                //支付宝公钥
                'alipay_public_key' => $this->alipay_public_key,
                //加签方式
                'sign_type' => $this->sign_type,
                //商户私钥
                'merchant_private_key' => $this->merchant_private_key,
                //编码格式
                'charset' => $this->charset,

                //支付宝网关
                'gatewayUrl' => $this->gatewayUrl,

                //应用ID
                'app_id' => $this->app_id,

                //异步通知地址,只有扫码支付预下单可用
                //'notify_url' => $this->notify_url,

                //最大查询重试次数
                'MaxQueryRetry' => $this->MaxQueryRetry,

                //查询间隔
                'QueryDuration' => $this->QueryDuration,

            );

            // 调用barPay方法获取当面付应答
            $barPay = new \AlipayTradeService($alipayConfig); //当面付2.0服务实现，包括条码支付（带轮询）、扫码支付、消费查询、消费退款
            $barPayResult = $barPay->barPay($barPayRequestBuilder);
            self::log(var_export($barPayResult, true));

            return $barPayResult;

        } catch (\Exception $e) {
            self::log($e->getMessage());
            throw new \Exception($e->getMessage());
        }

    }

    /**
     * 记录日志
     * @param string $msg
     */
    protected static function log($msg)
    {
        if (is_array($msg)) {
            $msg = json_encode($msg, JSON_UNESCAPED_UNICODE);
        }
        $path = getcwd() . '/logs/api/alipay/';
        file_exists($path) || mkdir($path, 777, true);
        @file_put_contents($path . date('Y-m-d') . '.log', date('Y-m-d H:i:s') . ':' . $msg . "\n", FILE_APPEND);
    }

}
