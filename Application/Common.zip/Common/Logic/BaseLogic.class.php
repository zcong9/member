<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/9/15
 * Time: 10:04
 */

namespace Common\Logic;

class BaseLogic
{
    protected $businessId = 0;
    protected $restaurantId = 0;

    public function setBusinessId($businessId){
        $this->businessId = $businessId;
        return $this;
    }

    public function setRestaurantId($restaurantId){
        $this->restaurantId = $restaurantId;
        return $this;
    }
}