<?php

namespace Common\Logic;

use Think\log;

class RefundLogic extends \Common\Logic\BaseLogic
{
    private $orderSn;
    private $refundAmount;
    private $tradeNum;
    private $payType;
    private $payTime;

    private function setErrMsg($msg)
    {
        $this->errMsg = $msg;
    }

    public function getErrMsg()
    {
        return $this->errMsg;
    }

    /**
     * 退款
     * @param $post
     * @return bool
     * @throws \Exception
     */
    public function refuse($post)
    {
        $addTime = $this->payTime = $post['add_time'];
        $order_sn = $this->orderSn = $post['order_sn'];
        $time = date('Ym', strtotime($addTime));
        $Model = M();
        $order_info = $Model->table("order_$time")->where(['order_sn' => $order_sn])->find();
        if (!$order_info) {
            $this->setErrMsg('未找到该数据');
            return false;
        }

        # 订单支付时间如果不是本日，无法退款
        $now_time = time();
        $refuse_time = strtotime(date('Y-m-d', $order_info['pay_time']) . ' 23:59:59');

        /*if ($now_time > $refuse_time) {
            $this->setErrMsg('该订单已超出退款日期，无法退款');
            return false;
        }*/

        if ($order_info['refuse'] == 1) {
            $this->setErrMsg('该订单已经退款');
            return false;
        }

        //支付记录
        $payLogModel = new \Common\Model\PayLogModel();
        $paylogs = $payLogModel->where(['restaurant_id' => $this->restaurantId, 'order_sn' => !empty($order_info['saoma_out_trade_no']) ? $order_info['saoma_out_trade_no'] : $order_sn, 'is_del' => 0])->order('id desc')->limit(2)->select();

        if (empty($paylogs)) {
            $this->setErrMsg('没找到支付记录');
            return false;
        }

        $f = false;
        foreach ($paylogs as $item) {

            $this->tradeNum = $item['trade_num'];
            $this->refundAmount = $item['pay_amount'];
            $this->payType = $item['pay_type'];
            $res = false;
            try {
                if ($item['pay_type'] == $payLogModel::PAY_TYPE_CANDAO) $res = $this->memberPayRefund();
                if ($item['pay_mode'] == $payLogModel::PAY_MODE_SHANDE) $res = $this->shandePayRefund();
                if ($item['pay_mode'] == $payLogModel::PAY_MODE_QWXPAY) $res = $this->qwxPayRefund();
                if ($item['pay_mode'] == $payLogModel::PAY_MODE_KUANYIPAY && $this->payType == $payLogModel::PAY_TYPE_CANDAO) {
                    $item = json_decode($item['log'],true);
                    $res = $this->kuanyiMemPayRefund($item['customer_id']);
                }
                if ($item['pay_mode'] == $payLogModel::PAY_MODE_KUANYIPAY) $res = $this->kuanyiPayRefund();
                if (($item['pay_mode'] == $payLogModel::PAY_MODE_OFFICIAL_PRO) || ($item['pay_mode'] == $payLogModel::PAY_MODE_OFFICIAL_OY)) {
                    if ($item['pay_type'] == $payLogModel::PAY_TYPE_ALI) $res = $this->alipayRefund();
                    if ($item['pay_type'] == $payLogModel::PAY_TYPE_WX) $res = $this->wxPayRefund();
                }
            } catch (\Exception $e) {
                $this->setErrMsg($e->getMessage());
            }

            if (true !== $res) {
                $f = true;
                break;
            }

        }

        if ($f) {
            return false;
        }
        $Model->table("order_$time")->where(['order_sn' => $order_sn])->save(['refuse' => '1']);

        try {
            doRequest('/index.php/Api/Hualala/updateOrderStatus', 'POST', ['order_sn' => $order_sn, 'amount' => $order_info['total_amount'], 'restaurant_id' => $this->restaurantId], domain());
        } catch (\Exception $e) {
            Log::write('同步哗啦啦订单状态：' . $e->getMessage());
        }

        try {
            doRequest('/index.php/Api/PosService/updateOrderStatus', 'POST', ['order_sn' => $order_sn, 'amount' => $order_info['total_amount'], 'restaurant_id' => $this->restaurantId], domain());
        } catch (\Exception $e) {
            Log::write('同步订单状态：' . $e->getMessage());
        }

        $this->setErrMsg('退款成功');
        return true;
    }

    /**
     * 餐道会员支付退款
     * @return bool
     * @throws \Exception
     */
    private function memberPayRefund()
    {
        try {
            $postData = array('restaurant_id' => $this->restaurantId, 'transNum' => $this->tradeNum, 'orderId' => $this->orderSn);
            $reqJson = http_post(domain() . '/api/Candao/consumeCancel', $postData);
            $reqArr = json_decode($reqJson, true);
            Log::write('餐道会员退款：' . $reqJson);
            if (1 == $reqArr['code']) {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 支付宝官方支付退款
     * @return bool
     * @throws \Exception
     */
    private function alipayRefund()
    {
        try {
            $Refuse = new \Api\Controller\RefuseController();
            return $Refuse->aliRefuse($this->restaurantId, $this->orderSn, $this->refundAmount);
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 杉德聚合支付退款
     * @return bool
     * @throws \Exception
     */
    private function shandePayRefund()
    {
        try {
            $Refuse = new \Api\Controller\RefuseController();
            $res = $Refuse->shandeRefund($this->restaurantId, $this->orderSn, $this->refundAmount, $this->payTime);
            if (isset($res['return_code']) && $res['return_code'] == 'SUCCESS' && isset($res['result_code']) && $res['result_code'] == 'SUCCESS') {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 微信官方支付退款
     * @return bool
     * @throws \Exception
     */
    private function wxPayRefund()
    {
        try {
            $Refuse = new \Api\Controller\RefuseController();
            $res = $Refuse->wxRefuse($this->restaurantId, $this->orderSn, $this->refundAmount);
            if (isset($res['return_code']) && $res['return_code'] == 'SUCCESS' && isset($res['result_code']) && $res['result_code'] == 'SUCCESS') {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            throw new \Exception('系统异常：' . $e->getMessage());
        }
    }

    /**
     * 微收银支付退款
     * @return bool|mixed
     * @throws \Exception
     */
    private function qwxPayRefund()
    {
        //获取配置
        $payConfig = M('config')->where(['restaurant_id' => $this->restaurantId, 'config_type' => 'qwxpay'])->getField('config_name,config_value');
        $qwxpay = json_decode($payConfig['qwxpay'], true);
        if (empty($qwxpay)) {
            $this->setErrMsg('微收银聚合支付：参数获取失败，请确认后台配置');
            return false;
        }
        try {
            $qwxPay = new \Lib\qwxpay\Wx();
            $postParams = array(
                'out_refund_no' => $this->orderSn,
                //'transaction_id' => $this->tradeNum,
                'out_trade_no' => $this->orderSn,
                'total_fee' => $this->refundAmount,
                'refund_fee' => $this->refundAmount,
                'refund_desc' => '退款',
                'pass_type' => $this->payType == 1 ? $qwxPay::PASS_TYPE_ALI : $qwxPay::PASS_TYPE_WX,
            );

            if (false === $qwxPay->setPayParams($qwxpay['wx'])->setPostParams($postParams)->refund()) {
                $this->setErrMsg('退款失败：' . $qwxPay->getError());
                return false;
            }

            $n = 5;
            while ($n > 0) {
                $n--;
                if ($qwxPay->setPayParams($qwxpay['wx'])->setPostParams($postParams)->refundQuery()) {
                    $result = $qwxPay->getResult();
                    if (isset($result['refund_status_0']) && $result['refund_status_0'] == 'SUCCESS') {
                        return true;
                    }
                }
                sleep(1);
            }
            $this->setErrMsg('退款失败：' . $qwxPay->getError());
            return false;

        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 款易支付退款
     * @return bool|mixed
     * @throws \Exception
     */
    private function kuanyiPayRefund()
    {
        //获取配置
        $opcMod = new \Common\Model\OpenPlatformConfigModel();
        $oConfig = $opcMod->get(['restaurant_id' => $this->restaurantId, 'type' => $opcMod::TYPE_KUANYI, 'status' => $opcMod::STATUS_ENABLE]);
        if (empty($oConfig)) {
            $this->setErrMsg('款易支付服务配置异常');
            return false;
        }
        $configParam = unserialize($oConfig['config']);
        try {
            $pay = \Lib\kuanyipay\KuanYiPay::instance(is_array($configParam) ? $configParam : []);
            if ($pay->refund(['outOrderNo' => $this->orderSn, 'price' => $this->refundAmount])) {
                $isRefund = false;
                //获取退款状态
                $n = 20;
                while ($n > 0) {
                    -- $n;
                    if($pay->barquery(['outOrderNo'=>$this->orderSn])){
                        $res = $pay->getResult();
                        if (isset($res['data']['pay_status']) && ($res['data']['pay_status'] == 4 || $res['data']['pay_status'] == 5)) {
                            $isRefund = true;
                            break;
                        }

                        if ($n < 5 && isset($res['data']['pay_status']) && $res['data']['pay_status'] == 6) {
                            $n = 20;
                        }
                    }
                    sleep(1);
                }
                return $isRefund;
            }
            $this->setErrMsg('退款失败：' . $pay->getError());
            return false;
        } catch (\Exception $e) {
            Log::write('款易退款-异常：' .$e->getMessage());
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 款易会员支付退款
     * @return bool|mixed
     * @throws \Exception
     */
    private function kuanyiMemPayRefund($customerId)
    {
        //获取配置
        $opcMod = new \Common\Model\OpenPlatformConfigModel();
        $oConfig = $opcMod->get(['restaurant_id' => $this->restaurantId, 'type' => $opcMod::TYPE_KUANYI, 'status' => $opcMod::STATUS_ENABLE]);
        if (empty($oConfig)) {
            $this->setErrMsg('款易支付服务配置异常');
            return false;
        }
        $configParam = unserialize($oConfig['config']);
        try {
            $pay = \Lib\kuanyipay\MemberPay::instance(is_array($configParam) ? $configParam : []);
            if ($pay->refund(['outOrderNo' => $this->orderSn, 'price' => $this->refundAmount, 'customer_id' => $customerId])) {
                $payResult = $pay->getResult();
                $isRefund = false;
                if (isset($payResult['data']['result']) && (true == $payResult['data']['result'])) $isRefund = true;
                return $isRefund;
            }
            $this->setErrMsg('退款失败：' . $pay->getError());
            return false;
        } catch (\Exception $e) {
            Log::write('款易退款-异常：' .$e->getMessage());
            throw new \Exception($e->getMessage());
        }
    }
}