<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/10/26
 * Time: 10:04
 */

namespace Common\Logic;

class BaiduDishesImgLogic extends \Common\Logic\BaseLogic
{
    protected $client = false;
    protected $resp = false;

    protected  $app_id = '';
    protected  $secret_key = '';
    protected  $api_key =  '';

    var $errMsg = [
        '13' => '获取token失败',
        '14' => 'IAM鉴权失败',
        '15' => '应用不存在或者创建失败',
        '17' => '每天请求量超限额',
        '18' => 'QPS超限额',
        '216110' => 'ppid不存在',
        '216201' => '上传的图片格式错误，现阶段支持的图片格式为：PNG、JPG、JPEG、BMP',
        '216202' => '上传的图片大小错误，现阶段支持的图片大小为：base64编码后小于4M，分辨率不高于4096*4096，请重新上传图片',
        '216203' => '上传的图片中包含多个主体，请上传只包含一个主体的菜品图片入库',
        '282102' => '未检测到图片中识别目标',
        '282103' => '图片目标识别错误',
        '282810' => '图像识别错误',
    ];

    /**
     * 返回错误msg
     * @return mixed
     */
    public function getErrMsg(){
        return isset($this->resp['error_code']) && isset($this->errMsg[$this->resp['error_code']]) ?  $this->errMsg[$this->resp['error_code']] : $this->resp['error_msg'];
    }

    public function __construct($config = array()){
        isset($config['app_id']) && $this->app_id = $config['app_id'];
        isset($config['api_key']) && $this->api_key = $config['api_key'];
        isset($config['secret_key']) && $this->secret_key = $config['secret_key'];
        require_once getcwd().'/Application/Lib/baidu/AipImageClassify.php';
        if (class_exists('AipImageClassify')){
            $this->client = new \AipImageClassify($this->app_id, $this->api_key, $this->secret_key);
        }
    }

    /**
     * 菜品识别—入库
     * @param $image - 图像数据，base64编码，要求base64编码后大小不超过4M，最短边至少15px，最长边最大4096px,支持jpg/png/bmp格式
     * @param array $brief  - 可选参数对象，key: value都为string类型
     * @return array|bool
     * @throws \Exception
     */
    public function dishAddImage($image,array $brief){
        try {
            $this->resp = $this->client->customDishesAddImage($image,json_encode($brief));
            return $this->resp;
        } catch (\Exception $e) {
            throw new \Exception('服务异常');
        }
    }

    /**
     * 菜品识别—检索
     * @param $image - 图像数据，base64编码，要求base64编码后大小不超过4M，最短边至少15px，最长边最大4096px,支持jpg/png/bmp格式
     * @return array|bool
     * @throws \Exception
     */
    public function dishSearch($image){
        try {
            $this->resp = $this->client->customDishesSearch($image);
            return $this->resp;
        } catch (\Exception $e) {
            throw new \Exception('服务异常');
        }
    }

    /**
     * 菜品识别—删除
     * @param $image  - 图像数据，base64编码，要求base64编码后大小不超过4M，最短边至少15px，最长边最大4096px,支持jpg/png/bmp格式
     * @return array|bool
     * @throws \Exception
     */
    public function dishDeleteImage($image){
        try {
            $this->resp = $this->client->customDishesDeleteImage($image);
            return $this->resp;
        } catch (\Exception $e) {
            throw new \Exception('服务异常');
        }
    }

    /**
     * 菜品识别—删除
     * @param $contSign - 图像数据签名
     * @return array|bool
     * @throws \Exception
     */
    public function dishDeleteContSign($contSign){
        try {
            $this->resp = $this->client->customDishesDeleteContSign($contSign);
            return $this->resp;
        } catch (\Exception $e) {
            throw new \Exception('服务异常');
        }
    }

}