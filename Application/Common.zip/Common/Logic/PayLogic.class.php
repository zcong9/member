<?php

namespace Common\Logic;

use PayMethod\WxpayMicropay2\MicroPay_1;
use PayMethod\WxpayMicropay\MicroPay;
use data\service\SellOut as ServiceSellOut;
use Think\Log;
use Api\Controller\ShandeController;
use Api\Model\BusinessShandePayConfigModel;

class PayLogic extends \Common\Logic\BaseLogic
{
    const PAY_TYPE_ALI = 1;
    const PAY_TYPE_WX = 2;
    const PAY_TYPE_ALI_FACE = 3;
    const PAY_TYPE_WX_FACE = 4;
    const PAY_TYPE_MEMBER = 5;

    private $orderObj = null;
    private $errMsg = '';

    private $paySelectModel;
    private $orderSn;
    private $tbSuffix;

    public function __construct()
    {
        $this->paySelectModel = new \Common\Model\PaySelectModel();
    }

    public function setOrderObj(object $obj)
    {
        $this->orderObj = $obj;
        $this->tbSuffix = substr(strrchr($this->orderObj->getModelName(), "_"), 1);
        return $this;
    }

    public function getOrderObj()
    {
        return $this->orderObj;
    }

    private function setErrMsg($msg)
    {
        $this->errMsg = $msg;
    }

    public function getErrMsg()
    {
        return $this->errMsg;
    }

    /**
     * 支付统一入口
     * @param array $post
     * @return bool
     */
    public function pay(array $post)
    {
        $this->orderSn = $post['order_sn'];
        $restaurantId = $post['restaurant_id'];
        $payType = $post['pay_type'];//支付方式，如果是刷脸支付时必传4
        #查询订单状态
        $orderInfo = $this->orderObj
            ->alias('o')
            ->join('LEFT JOIN restaurant AS r ON r.restaurant_id = o.restaurant_id')
            ->field('o.order_id,o.order_status,o.total_amount,o.add_time,o.restaurant_id,r.business_id')
            ->where(['o.restaurant_id' => $restaurantId, 'o.order_sn' => $this->orderSn])
            ->find();

        Log::write('支付订单信息：' . json_encode($orderInfo, JSON_UNESCAPED_UNICODE));

        if (empty($orderInfo)) {
            $this->setErrMsg('获取订单异常');
            return false;
        }

        if ($orderInfo['order_status'] == '1') {
            $this->setErrMsg('订单已付款，请不要重复支付');
            return false;
        }

        #如果订单已支付或已关闭交易
        if ($orderInfo['order_status'] == '2') {
            $this->setErrMsg('订单已关闭交易');
            return false;
        }

        #根据条形码前缀决定使用支付宝交易还是微信交易
        $authCode = trim($post['qr_number']);
        $prefixNum = substr($authCode, 0, 2);

        if (!$authCode) {
            $this->setErrMsg('付款码错误');
            return false;
        }

        //判断是否有会员支付记录
        if (false === $this->memberPayUnlocking($this->orderSn, $restaurantId)) {
            $this->setErrMsg('支付失败：解锁余额或优惠券失败');
            return false;
        }

        $total_amount = $orderInfo['total_amount'];
        if (in_array($prefixNum, ['FK'])) {
            return $this->memberPay($this->orderSn, $authCode, $restaurantId, $total_amount);
        }

        $payModeModel = new \Common\Model\PayModeModel();
        $pay_mode = $payModeModel->where(['restaurant_id' => $orderInfo['restaurant_id']])->getField('mode');

        if ($pay_mode == $payModeModel::PAY_QWXPAY) {
            return $this->qwxPay($this->orderSn, $authCode, $restaurantId, $total_amount);
        }

        if ($pay_mode == $payModeModel::PAY_SHANDE) {
            return $this->shandePay($this->orderSn, $authCode, $restaurantId, $total_amount, $payType, $orderInfo['business_id']);
        }

        if (in_array($prefixNum, C('AL_PAY_PREFIX')) || (3 == $payType)) {
            $scene = (3 == $payType) ? 'security_code' : 'bar_code';
            return $this->aliPay($this->orderSn, $authCode, $restaurantId, $total_amount, $pay_mode, $scene);
        }

        if (in_array($prefixNum, C('WX_PAY_PREFIX'))) {
            return $this->wxPay($this->orderSn, $authCode, $restaurantId, $total_amount, $pay_mode);
        }

        $this->setErrMsg('付款码无效');
        return false;
    }

    /**
     * 判断是否开启支付方式
     * @param $restaurantId
     * @param $configName
     * @return mixed
     */
    private function checkPaySelectIsOpen($restaurantId, $configName)
    {
        $pCondition['restaurant_id'] = $restaurantId;
        $pCondition['config_name'] = $configName;
        $pCondition['value'] = "1";
        return $this->paySelectModel->where($pCondition)->find();
    }


    /**
     * 更新订单状态
     * @param array $condition
     * @param array $saveData
     * @return mixed
     */
    private function updateOrderStatus(array $condition, array $saveData)
    {
        !isset($saveData['order_status']) && $saveData['order_status'] = 1;
        $saveData['pay_time'] = $saveData['update_time'] = time();
        try {
            return $this->orderObj->where($condition)->save($saveData);
        } catch (\Exception $e) {
            Log::write('更新订单状态失败：' . $e->getMessage());
            return false;
        }
    }

    /**
     * 是否售罄处理
     * @param $orderSn
     */
    private function checkSellOut($orderSn)
    {
        try {
            $S_SellOut = new ServiceSellOut();
            $S_SellOut->sellOutDeal($orderSn);
            #删除第三方支付二维码
            delQrcode($orderSn, 2);
        } catch (\Exception $e) {
            Log::write('sellOutDeal：' . $e->getMessage());
        }
    }

    /**
     * 餐道会员支付
     * @param $orderSn
     * @param $authCode
     * @param $restaurantId
     * @param $total_amount
     * @return bool
     */
    private function memberPay($orderSn, $authCode, $restaurantId, $total_amount)
    {
        $postData = array("order_sn" => $orderSn, "qr_number" => $authCode, 'restaurant_id' => $restaurantId, 'tb_suffix' => $this->tbSuffix);
        $reqJson = http_post(domain() . '/api/Candao/autoConsumption', $postData);
        $reqArr = json_decode($reqJson, true);
        Log::write('餐道会员支付：' . $reqJson);
        if ($reqArr && 1 == $reqArr['code']) {

            //记录支付日志
            $payLog = new \Common\Model\PayLogModel();
            $logId = $payLog->doAdd(['restaurant_id' => $restaurantId, 'order_sn' => $orderSn, 'pay_status' => 1, 'pay_type' => $payLog::PAY_TYPE_CANDAO, 'trade_num' => $reqArr['data']['transNum'], 'log' => json_encode($reqArr['data'])]);
            if (false === $logId) {
                Log::write('餐道会员支付：写入支付日志失败');
                $this->setErrMsg('支付失败');
                return false;
            }

            //判断是否支付完成
            $paymentDetail = $reqArr['data']['paymentDetail'];
            $payAmount = array_sum(array_column($paymentDetail, 'payAmount'));//总支付金额
            Log::write('餐道会员支付-总支付金额：' . $payAmount);
            if ($payAmount < $total_amount) {
                //余额不足 解锁余额 优惠券
                $this->memberPayUnlocking($orderSn, $restaurantId);
                $this->setErrMsg('支付失败：余额不足，请使用其他支付方式付款');
                return false;
            }

            //订单结账
            if (false === $this->memberPaySettleAccounts($orderSn, $restaurantId)) {
                //结账失败 解锁余额 优惠券
                $this->memberPayUnlocking($orderSn, $restaurantId);
                $this->setErrMsg('支付失败：结账异常，请使用其他支付方式付款');
                return false;
            }

            //记录卡券使用
            $payAmounts = $this->writeCouponAndCard($orderSn, $restaurantId, $paymentDetail);

            //成功修改订单状态
            $saveData = ['pay_type' => self::PAY_TYPE_MEMBER];
            $saveData['total_amount'] = bcsub($total_amount, $payAmounts['couponAmount'], 2);//实际支付金额 = 原来支付金额 - 优惠金额
            $saveData['coupon_pay'] = $payAmounts['couponAmount'];

            if (false === $this->updateOrderStatus(['order_sn' => $orderSn], $saveData)) {
                Log::write('餐道会员支付：更新订单状态失败');

                //撤销订单
                $cancelStatus = $this->memberPayCancel($orderSn, $restaurantId);
                if (false === $cancelStatus) {
                    $n = 2;
                    while ($n > 0) {
                        $n--;
                        if ($cancelStatus = $this->memberPayCancel($orderSn, $restaurantId)) {
                            break;
                        }
                        sleep(1);
                    }
                }

                $this->setErrMsg('支付失败：撤销消费' . $cancelStatus ? '成功' : '失败');
                return false;
            }

            return true;
        }
        $this->setErrMsg($reqArr['msg']);
        return false;
    }

    /**
     * 会员支付-结账成功 后撤销订单
     * @param $orderSn
     * @param $restaurantId
     * @return bool
     */
    private function memberPayCancel($orderSn, $restaurantId)
    {
        try {
            $reqJson = http_post(domain() . '/api/Candao/consumeCancel', ["order_sn" => $orderSn, 'restaurant_id' => $restaurantId]);
            $reqArr = json_decode($reqJson, true);
            if (1 === $reqArr['code']) {
                return true;
            } else {
                $this->setErrMsg('支付失败');
                return false;
            }
            Log::write('餐道会员支付-撤销：' . $reqJson);
        } catch (\Exception $e) {
            $this->setErrMsg($e->getMessage());
            return false;
        }
    }

    /**
     * 会员支付解锁 余额、优惠券
     * 比如客户刷码了，使用了余额和优惠券，但是没支付完成，客户不想要了，不结账把钱和券给他退回去
     * @param $orderSn
     * @param $restaurantId
     * @return bool
     */
    private function memberPayUnlocking($orderSn, $restaurantId)
    {
        //判断是否有会员支付记录
        $payLog = new \Common\Model\PayLogModel();
        $payRows = $payLog->where(['restaurant_id' => $restaurantId, 'order_sn' => $orderSn, 'pay_type' => $payLog::PAY_TYPE_CANDAO, 'is_del' => $payLog::DEL_NO])->order('id desc')->find();
        if (empty($payRows)) return true;
        $log = json_decode($payRows['log'], true, 512, JSON_BIGINT_AS_STRING);
        $paymentDetail = $log['paymentDetail'];
        foreach ($paymentDetail as $k => $vo) {
            try {
                $act = (int)$vo['payType'] == 30 ? 'balanceUnlock' : 'couponsUnlock';
                $reqJson = http_post(domain() . '/api/Candao/' . $act, ["tradeNo" => $vo['tradeNo'], 'restaurant_id' => $restaurantId]);
                $reqArr = json_decode($reqJson, true);
                if (1 != $reqArr['code']) {
                    Log::write('餐道会员支付-解锁余额or优惠券失败-' . $act . '：' . $vo['tradeNo']);
                    return false;
                }
            } catch (\Exception $e) {
                Log::write('餐道会员支付-解锁余额or优惠券异常-' . $act . '：' . $e->getMessage());
                return false;
            }
        }
        try {
            M('order_coupon_' . $this->tbSuffix)->where(['restaurant_id' => $restaurantId, 'order_sn' => $orderSn])->save(['status' => 0, 'update_at' => time()]);
        } catch (\Exception $e) {
            Log::write('餐道会员支付-更新优惠券状态异常-' . $act . '：' . $e->getMessage());
        }
        $payLog->where(['id' => $payRows['id']])->setField('is_del', $payLog::DEL_YES);
        return true;
    }

    /**
     * 会员支付-结账
     * @param $orderSn
     * @param $restaurantId
     * @return bool
     */
    private function memberPaySettleAccounts($orderSn, $restaurantId)
    {
        try {
            $reqJson = http_post(domain() . '/api/Candao/consume', ["order_sn" => $orderSn, 'restaurant_id' => $restaurantId, 'tb_suffix' => $this->tbSuffix]);
            $reqArr = json_decode($reqJson, true);
            if (1 == $reqArr['code']) {
                return $reqArr['data'];
            } else {
                $this->setErrMsg($reqArr['msg']);
                return false;
            }
        } catch (\Exception $e) {
            $this->setErrMsg($e->getMessage());
            return false;
        }
    }

    /**
     * 记录卡券使用
     * @param $orderSn
     * @param $restaurantId
     * @param array $paymentDetail
     * @return array
     */
    private function writeCouponAndCard($orderSn, $restaurantId, array $paymentDetail)
    {

        $couponAmount = $cardAmount = 0;//总优惠金额
        $order_voucher = $order_coupon = [];
        //解冻余额、解冻优惠券
        foreach ($paymentDetail as $k => $vo) {

            if ((int)$vo['payType'] == 30) {

                $cardAmount = bcadd($cardAmount, $vo['payAmount'], 2);
                $order_voucher[] = array(
                    'restaurant_id' => $restaurantId,
                    'order_sn' => $orderSn,
                    'card_no' => $vo['cardNo'],
                    'voucher_no' => $vo['tradeNo'],
                    'revoke_no' => '',
                    'create_at' => time(),
                );

            }

            if ((int)$vo['payType'] == 33) {
                $couponAmount = bcadd($couponAmount, $vo['payAmount'], 2);
                foreach ($vo['coupons'] as $coupon) {
                    $order_coupon[] = array(
                        'restaurant_id' => $restaurantId,
                        'order_sn' => $orderSn,
                        'coupon_id' => (int)$coupon['id'],
                        'coupon_name' => $coupon['name'],
                        'type' => (int)$coupon['type'],
                        'amount' => (float)$coupon['discount'],
                        'total_amount' => (float)$coupon['cost'],
                        'max_amount' => 0,
                        'dish_no' => '',
                        'food_name' => '',
                        'status' => 1,
                        'create_at' => time(),
                    );
                }
            }
        }

        Log::write('餐道会员支付-卡付金额：' . $cardAmount);
        Log::write('餐道会员支付-优惠金额：' . $couponAmount);

        //保存会员卡支付使用 order_voucher
        try {
            $order_voucher && M('order_voucher_' . $this->tbSuffix)->addAll($order_voucher);
        } catch (\Exception $e) {
            Log::write('餐道会员支付-保存会员卡日志失败：' . $e->getMessage());
        }
        //保存优惠券使用数据 order_coupon
        try {
            $order_coupon && M('order_coupon_'.$this->tbSuffix)->addAll($order_coupon);
        } catch (\Exception $e) {
            Log::write('餐道会员支付-保优惠券日志失败：' . $e->getMessage());
        }

        return ['couponAmount' => $couponAmount, 'cardAmount' => $cardAmount];
    }

    /**
     * 微收银聚合支付
     * @param $orderSn
     * @param $authCode
     * @param $restaurantId
     * @param $total_amount
     * @return bool
     */
    private function qwxPay($orderSn, $authCode, $restaurantId, $total_amount)
    {
        //获取配置
        $payConfig = M('config')->where(['restaurant_id' => $restaurantId, 'config_type' => 'qwxpay'])->getField('config_name,config_value');
        $qwxpay = json_decode($payConfig['qwxpay'], true);
        if (empty($qwxpay)) {
            Log::write('微收银聚合支付：参数获取失败，请确认后台配置');
            $this->setErrMsg('支付配置异常');
            return false;
        }
        $prefixNum = substr($authCode, 0, 2);
        //判断是微信 还是支付 扫码支付
        if (in_array($prefixNum, C('AL_PAY_PREFIX'))) {
            //支付宝
            $payType = self::PAY_TYPE_ALI;

        } elseif (in_array($prefixNum, C('WX_PAY_PREFIX'))) {
            //微信
            $payType = self::PAY_TYPE_WX;
        } else {
            //支付宝刷脸
            $payType = self::PAY_TYPE_ALI_FACE;
            //Log::write('微收银聚合支付：目前紧支持微信、支付宝支付');
            //echo 0;exit;
        }

        try {
            $qwxPay = new \Lib\qwxpay\Wx();
            $postParams = array(
                'body' => D("restaurant")->where(['restaurant_id' => $restaurantId])->getField("restaurant_name") ?: 'qwxpay',
                'out_trade_no' => $orderSn,
                'total_fee' => $total_amount,
                'auth_code' => $authCode,
                'pass_type' => $payType == 1 || $payType == 3 ? $qwxPay::PASS_TYPE_ALI : $qwxPay::PASS_TYPE_WX,
            );
            $rep = $qwxPay->setPayParams($qwxpay['wx'])->setPostParams($postParams)->micropay();
            if (true === $rep) {
                //获取支付信息
                $result = $qwxPay->getResult();
                //记录支付日志
                (new \Common\Model\PayLogModel())->doAdd(['restaurant_id' => $restaurantId, 'order_sn' => $orderSn, 'pay_status' => 1, 'pay_type' => (3 == $payType) ? 1 : $payType, 'trade_num' => $result['transaction_id'], 'log' => json_encode($result)]);

                //成功修改订单状态
                if (false === $this->updateOrderStatus(['order_sn' => $orderSn], ['pay_type' => $payType])) {

                    $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                    return false;
                }

                return true;
            }
            Log::write('微收银聚合支付：' . $qwxPay->getError());
            $this->setErrMsg($qwxPay->getError());
        } catch (\Exception $e) {
            Log::write('微收银聚合支付：' . $e->getMessage());
            $this->setErrMsg($e->getMessage());
        }

        return false;
    }

    /**
     * 杉德支付聚合支付
     * @param $orderSn
     * @param $authCode
     * @param $restaurantId
     * @param $total_amount
     * @param $payType
     * @return bool
     */
    private function shandePay($orderSn, $authCode, $restaurantId, $total_amount, $payType, $business_id)
    {
        if (!$this->checkPaySelectIsOpen($restaurantId, ($this->paySelectModel)::PAY_SHANDE)) {
            $this->setErrMsg('杉德支付配置信息异常');
            return false;
        }

        #获取杉德支付配置
        $restaurant_info = M('config')->field('config_name,config_value')->where(['config_type' => 'shandepay', 'restaurant_id' => $restaurantId])->select();
        $restaurant_info = dealConfigKeyForValue($restaurant_info);
        Log::write('杉德支付配置信息：' . json_encode($restaurant_info, JSON_UNESCAPED_UNICODE));

        if (empty($restaurant_info)) {
            $this->setErrMsg('杉德支付配置信息异常');
            return false;
        }

        $prefixNum = substr($authCode, 0, 2);
        //判断支付码是微信还是支付宝
        if ($payType == 4) {//微信刷脸支付
            $payType = self::PAY_TYPE_WX_FACE;
        } elseif (in_array($prefixNum, C('AL_PAY_PREFIX'))) {
            $payChannelTypeNo = '0103';
            $payType = self::PAY_TYPE_ALI;
        } elseif (in_array($prefixNum, C('WX_PAY_PREFIX'))) {
            $payChannelTypeNo = '0203';
            $payType = self::PAY_TYPE_WX;
        } else {
            $payChannelTypeNo = '';
            $payType = 0;
        }

        //检测总代理是否设置了服务配置
        $BusinessShandePayConfigModel = new BusinessShandePayConfigModel();
        $agentShandePayConfig = $BusinessShandePayConfigModel->getShandePayConfig($business_id);

        $app_id = !empty($agentShandePayConfig['app_id']) ? $agentShandePayConfig['app_id'] : '552020042420160';//商户号
        //$app_id = !empty($agentShandePayConfig['app_id']) ? $agentShandePayConfig['app_id']: '663101000017582';//商户号
        $sub_app_id = !empty($agentShandePayConfig['sub_app_id']) ? $agentShandePayConfig['sub_app_id'] : $restaurant_info['shande_sub_mchno'];//子商户号
        $store_id = !empty($agentShandePayConfig['store_id']) ? $agentShandePayConfig['store_id'] : '100001';//门店号
        $privateKey = !empty($agentShandePayConfig['private_key']) ? $agentShandePayConfig['private_key'] : '';

        $method = "trade.pay";//接口方法
        $timestamp = date("Y-m-d h:i:s");
        $nonce = time();
        $createIp = $_SERVER['REMOTE_ADDR'];//IP地址
        $body = 'shandepay';

        $tradePrecreate = [//公共参数+方法需要传的参数
            'app_id' => $app_id,
            'sub_app_id' => $sub_app_id,
            'method' => $method,
            'timestamp' => $timestamp,
            'nonce' => $nonce,
            'auth_code' => $authCode,
            'create_ip' => $createIp,
            'total_amount' => $total_amount,
            'out_order_no' => $orderSn,
            'body' => $body,
            'store_id' => $store_id,
        ];

        $tradePrecreateRequest = json_encode($tradePrecreate, JSON_UNESCAPED_UNICODE);

        $tradeRequest = [//公共参数
            'app_id' => $app_id,
            'sub_app_id' => $sub_app_id,
            'method' => $method,
            'timestamp' => $timestamp,
            'nonce' => $nonce,
            'biz_content' => $tradePrecreateRequest,
        ];
        Log::write('调用杉德支付接口所传递的参数：' . json_encode($tradeRequest, JSON_UNESCAPED_UNICODE));
        $shande = new ShandeController();

        $result = $shande->execute($shande->request($tradeRequest, $privateKey));
        $data = json_decode($result['data'], true);

        if ($result['code'] == '200' && $data['sub_code'] == 'SUCCESS') {
            #成功修改订单状态
            $order_data['pay_type'] = $payType;
            $order_data['order_status'] = 3;
            if (false === $this->updateOrderStatus(['order_sn' => $orderSn], $order_data)) {
                $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                return false;
            }
            return true;

        } else if ($result['code'] == '200' && $data['sub_code'] == 'WAITING_PAYMENT') {
            $tag = 2;
            while ($tag == 2) {
                $queryOrderData = [//公共参数+方法需要传的参数
                    'app_id' => $app_id,
                    'sub_app_id' => $sub_app_id,
                    'method' => 'trade.query',
                    'timestamp' => $timestamp,
                    'nonce' => $nonce,
                    'order_create_time' => date('YmdHis', time()),
                    'out_order_no' => $orderSn,

                ];

                $queryOrderDataRequest = json_encode($queryOrderData, JSON_UNESCAPED_UNICODE);

                $queryOrderDataTradeRequest = [//公共参数
                    'app_id' => $app_id,
                    'sub_app_id' => $sub_app_id,
                    'method' => 'trade.query',
                    'timestamp' => $timestamp,
                    'nonce' => $nonce,
                    'biz_content' => $queryOrderDataRequest,
                ];

                $queryOrderResult = $shande->execute($shande->request($queryOrderDataTradeRequest));
                $queryOrderResultArr = json_decode($queryOrderResult['data'], true);
                if ($queryOrderResultArr['sub_code'] == 'SUCCESS') {
                    $tag = 1;
                } else if ($queryOrderResultArr['sub_code'] == 'FAILED') {
                    $tag = 0;
                }
            }

            if ($tag == 1) {
                #成功修改订单状态
                $order_data['pay_type'] = $payType;
                $order_data['order_status'] = 3;
                if (false === $this->updateOrderStatus(['order_sn' => $orderSn], $order_data)) {
                    $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                    return false;
                }
                return true;
            }

            $this->setErrMsg('支付失败');
            return false;

        } else {
            $this->setErrMsg('支付失败');
            return false;
        }
    }

    /**
     * 微信支付
     * @param $orderSn 订单号
     * @param $authCode 支付条码
     * @param $restaurantId 店铺ID
     * @param $total_amount 支付金额
     * @param $mode 支付通道
     * @return bool
     */
    private function wxPay($orderSn, $authCode, $restaurantId, $total_amount, $mode)
    {
        $store_id = M('chen_sen')->where(array('restaurant_id' => $restaurantId))->getField('alipay_store_id');
        $where['restaurant_id'] = $restaurantId;
        $restaurant_name = D("restaurant")->where($where)->getField("restaurant_name");

        #mode为2普通微信 mode为1服务商
        $configName = (2 == $mode) ? ($this->paySelectModel)::PAY_OY_WX : ($this->paySelectModel)::PAY_PRO_WX;
        if (!$this->checkPaySelectIsOpen($restaurantId, $configName)) {
            $this->setErrMsg('支付未开启');
            return false;
        }

        #将官方提供的订单号存在记录中
        $business_order = $orderSn;
        $this->orderObj->where(array('order_sn' => $orderSn))->save(array('saoma_out_trade_no' => $business_order));
        $price = $total_amount * 100;

        if (2 == $mode) {
            require getcwd() . "/Application/PayMethod/WxpayMicropay2/lib/WxPay.Data.php";
            try {
                $input = new \WxPayMicroPay();
                $input->SetAuth_code($authCode);
                $input->SetBody($restaurant_name);
                $input->SetTotal_fee($price);
                $input->setSceneInfo(json_encode(['store_info' => ['id' => $store_id]]));
                $input->SetOut_trade_no($business_order);
                $microPay = new MicroPay_1();
                //维修支付成功后查询支付对应的openid 开始 20200401
                try {
                    $openidInput = new \AuthCodetoOpenid();
                    $openidInput->SetAuthcode($authCode);
                    $WxPayApi = new \WxPayApi();
                    $queryOpenId = $WxPayApi->authcodetoopenid($openidInput);
                    $returnData = $openidInput->FromXml($queryOpenId);
                    \Think\Log::record(json_encode($returnData), 'ERR');
                    if ($returnData['return_code'] == 'SUCCESS' && $returnData["result_code"] == "SUCCESS") {
                        $data['openid'] = $returnData['openid'];
                    }
                } catch (Exception $e) {
                    Log::write('微信支付：' . $mode . $e->getMessage());
                }

                //维修支付成功后查询支付对应的openid 结束 20200401

                $result = $microPay->pay($input);

            } catch (\Exception $e) {
                $this->setErrMsg('支付失败：' . $e->getMessage());
                return false;
            }
        } else {
            require getcwd() . "/Application/PayMethod/WxpayMicropay/lib/WxPay.Data.php";
            try {
                $input = new \WxPayMicroPay();
                $input->SetAuth_code($authCode);
                $input->SetBody($restaurant_name);
                $input->SetTotal_fee($price);
                #将官方提供的订单号存在记录中
                $input->SetOut_trade_no($business_order);
                $input->SetSub_mch_id(\WxPayConfig::$SUB_MCHID);
                $microPay = new MicroPay();
                $result = $microPay->pay($input);

            } catch (\Exception $e) {
                $this->setErrMsg('支付失败：' . $e->getMessage());
                return false;
            }
        }

        if (empty($result)) {
            $this->setErrMsg('支付失败');
            return false;
        }

        if ($result["return_code"] == "SUCCESS" && $result["result_code"] == "SUCCESS") {

            #操作数据库处理订单信息；
            //$orderModel = order();
            $o_condition['order_sn'] = $orderSn;
            $data['order_status'] = 1;
            $data['pay_type'] = 2;
            $time = time();
            $data['pay_time'] = $time;

            //如果优惠金额大于0，即有使用优惠券，就把优惠信息存进表里
            if ($result['coupon_fee']) {
                $benefit_money = round($result["coupon_fee"] / 100, 2);
                $data["benefit_money"] = $benefit_money;
                $data["coupon_name"] = '微信' . $benefit_money . '元优惠券';
                $result['coupon_id_0'] && $data["coupon_id"] = $result['coupon_id_0'];
            }
            $rel = $this->updateOrderStatus($o_condition, $data);
            if ($rel !== false) {
                #是否售罄处理
                $this->checkSellOut($orderSn);
                return true;
            } else {
                $this->setErrMsg('支付成功：更新订单状态失败，请与管理员联系');
                return false;
            }

        } else {
            $this->setErrMsg($result["return_msg"]);
            return false;
        }
    }

    /**
     * 支付宝
     * @param $orderSn 订单号
     * @param $authCode 支付条码
     * @param $restaurantId 店铺id
     * @param $total_amount 支付金额
     * @param $mode 通道模式
     * @param $scene 条码类型 security_code,bar_code
     * @return bool
     */
    private function aliPay($orderSn, $authCode, $restaurantId, $total_amount, $mode, $scene)
    {
        $postData = array("order_sn" => $orderSn, "qr_number" => $authCode, 'restaurant_id' => $restaurantId, 'scene' => $scene);
        //判断 1=服务商,2=普通支付
        $configName = ($mode == 1) ? ($this->paySelectModel)::PAY_PRO_ALI : ($this->paySelectModel)::PAY_OY_ALI;
        $act = ($mode == 1) ? 'alipay_barcodePay' : 'alipay_barcodePay2';
        if (!$this->checkPaySelectIsOpen($restaurantId, $configName)) {
            $this->setErrMsg('支付未开启');
            return false;
        }
        $ali_out_put = http_post(C('HTTP_PROTOCOL') . $_SERVER["HTTP_HOST"] . U("Api/AlipayDirect/{$act}"), $postData);
        if ('1' === $ali_out_put) {
            return true;
        } else {
            $this->setErrMsg('支付失败');
            return false;
        }

    }

}