<?php

namespace Common\Logic;

class OrderLogic extends \Common\Logic\BaseLogic
{
    protected $tableModel;
    protected $suffix;

    public function getTableModel()
    {
        return $this->tableModel;
    }

    public function setTableModel($suffix = null)
    {
        $this->suffix = $suffix ?: date('Ym', time());
        $this->tableModel = M('order_' . $this->suffix);
        return $this;
    }

    public function getOrderInfByCondition($condition, $field = "*")
    {
        return $this->tableModel->field($field)->where($condition)->find();
    }

    public function saveOrderInfo($data, $condition)
    {
        return $this->tableModel->where($condition)->save($data);
    }

    /**
     * 餐道会员支付-订单解锁
     * @param $orderSn
     * @return bool
     */
    public function unlockOrder($orderSn)
    {
        $orderInfo = $this->getOrderInfByCondition(['order_sn' => $orderSn]);
        if (empty($orderInfo)) return true;
        if ($orderInfo['order_status']) return true;
        $payLogic = new \Common\Logic\V10\PayLogic();
        return $payLogic->setOrderObj($this->tableModel)->memberPayUnlocking($orderSn, $this->restaurantId);
    }

    /**
     * 餐道会员支付-结账
     * @param $orderSn
     * @return bool
     */
    public function consume($orderSn){
        $orderInfo = $this->getOrderInfByCondition(['order_sn' => $orderSn]);
        if (empty($orderInfo)) return false;
        $payLogic = new \Common\Logic\V10\PayLogic();
        return $payLogic->setOrderObj($this->tableModel)->memberPaySettleAccounts($orderSn, $this->restaurantId);
    }

}