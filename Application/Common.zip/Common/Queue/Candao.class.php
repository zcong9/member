<?php

namespace Common\Queue;

class Candao
{
    const UNLOCKING = 'candao-unlocking';//解锁优惠券 余额
    const SETTLE_ACCOUNTS = 'candao-settleAccounts';//订单结账


    /**
     * 餐道会员 解锁优惠券 余额队列
     * @param $score
     * @param array $param
     * @return mixed
     */
    public function addUnlockingTask($score, array $param)
    {
        return getRedis()->zAdd(self::UNLOCKING, $score, serialize($param));
    }

    public function getUnlockingTask($hour = 24)
    {
        $timestamp = time();
        //if (0 == (date('H',$timestamp) % 2)) $this->clearUnlockingTask();
        $data = getRedis()->zRangeByScore(self::UNLOCKING, $timestamp - $hour * 60 * 60, $timestamp - 300);
        return $data;
    }

    public function removeUnlockingTask($val)
    {
        return getRedis()->zRem(self::UNLOCKING, is_array($val) ? serialize($val) : $val);
    }

    public function clearUnlockingTask($hour = 24)
    {
        getRedis()->zRemRangeByScore(self::UNLOCKING, 0, time() - $hour * 60 * 60);
    }

    /**
     * 餐道会员 订单账队列结
     * @param array $param
     * @return mixed
     */
    public function addMemberPaySettleAccountsTask(array $param)
    {
        return getRedis()->rPush(self::SETTLE_ACCOUNTS, serialize($param));
    }

    public function getMemberPaySettleAccountsTask()
    {
        $data = getRedis()->lpop(self::SETTLE_ACCOUNTS);
        return unserialize($data);
    }

    public function removeMemberPaySettleAccountsTask($val)
    {
        return getRedis()->lrem(self::SETTLE_ACCOUNTS, is_array($val) ? serialize($val) : $val, 0);
    }

    public function getMemberPaySettleAccountsTaskLen()
    {
        return getRedis()->lLen(self::SETTLE_ACCOUNTS);
    }

    public function getMemberPaySettleAccountsList($index = 0, $limit = 100){
        return getRedis()->lrange(self::SETTLE_ACCOUNTS, $index ,$limit);
    }
}