<?php

namespace Common\Queue;

class Queue
{
    public static function add($key, array $param)
    {
        return getRedis()->rPush($key, serialize($param));
    }

    public static function get($key)
    {
        $data = getRedis()->lpop($key);
        return unserialize($data);
    }

    public static function del($key, $val)
    {
        return getRedis()->lrem($key, is_array($val) ? serialize($val) : $val, 0);
    }

    public static function len($key)
    {
        return getRedis()->lLen($key);
    }

    public static function lst($key, $index = 0, $limit = 100)
    {
        return getRedis()->lrange($key, $index, $limit);
    }

    public static function clear($key)
    {
        return getRedis()->del($key);
    }

}