<?php

namespace Common\Model;

class OrderSettlePictureModel extends \Common\Model\BaseModel
{
    const IS_DEL_YES = 1;
    const IS_DEL_NO = 0;
    const PLATFORM_ELEME = 1;
    const PLATFORM_BAIDU = 2;
    private $orderSn;

    public function setOrderSn($order_sn)
    {
        $this->orderSn = $order_sn;
        return $this;
    }

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('restaurant_id', 'number', '店铺ID错误', 0),
        array('order_sn', 'require', '订单号必须', 1, 'regex', 1),
        array('platform', array(self::PLATFORM_ELEME, self::PLATFORM_BAIDU), '平台错误', 0, 'in'),
        array('is_del', array(self::IS_DEL_YES, self::IS_DEL_NO), '状态错误', 0, 'in'),
    );

    /**
     * 自动完成
     * @var array
     */
    protected $_auto = array(
        array('create_at', 'time', 1, 'function'),
    );

    /**
     * 新增数据
     * @param $post
     * @return array
     */
    public function doAdd($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => (object)[]];
        try {
            $data = $this->create($post, 1);
            if (false === $data) {
                $result['msg'] = $this->getError();
                return $result;
            }
            $data['img_url'] = $this->saveBase64Img($post['img']);
            if (!$data['img_url']) {
                $result['msg'] = '图片保存失败';
                return $result;
            }
            if ($id = $this->add($data)) {
                $result['code'] = 0;
                $result['msg'] = '保存成功';
                $data['img_url'] = "http://" . $_SERVER["HTTP_HOST"] . $data['img_url'];
                $data['img_id'] = $id;
                $result['data'] = $data;
            }
        } catch (\Exception $e) {
            $result['msg'] = '系统异常';
        }
        return $result;
    }

    /**
     * 根据图片ID批量删除
     * @param array $ids
     * @return bool
     */
    public function batchDel(array $ids)
    {
        if (empty($ids)) return false;
        return $this->where(['id' => ['in', $ids]])->setField('is_del', self::IS_DEL_YES);
    }

    /**
     * 列表数据
     * @param $post
     * @return array
     *
     */
    public function tableData($post)
    {
        if (!isset($post['limit']) || empty($post['limit'])) {
            $post['limit'] = self::LIMIT;
        }

        $tableWhere = $this->tableWhere($post);
        $total = $this->where($tableWhere['where'])->count();

        $Page = new \Think\PageAjax($total, $post['limit']);
        $data = $this->where($tableWhere['where'])
            ->field($tableWhere['field'])
            ->order($tableWhere['order'])
            ->limit($Page->firstRow . ',' . $Page->listRows)->select();

        $data && $data = $this->formatTableData($data);

        return ['list' => $data ?: [], 'page' => $Page->show(null), 'total' => $total];
    }


    /*{'url':'www.abc.com/def.jpeg', 'recognize_result': [
    {'rectangle':{'left':100,'top':100,'right':300,'bottom':300},'similarity':0.75,'name':'番茄鸡蛋','dish_id':XXXX]}
             ....
             ]
    }*/
    protected function formatTableData(&$data){

        $dishIds = [];
        //获取dish_id 对应的菜品名称
        $content = array_column($data,'content','id');
        foreach ($content as &$v) {
            $v = json_decode($v,true);
            $dishIds = array_merge($dishIds,array_column($v,'dish_id'));
        }

        //获取对应的food_id
        $rows = null;
        $dishIds && $rows = (new \Common\Model\FoodElmImgModel())->where(['dish_id'=>['in',array_unique($dishIds)]])->getField('dish_id,food_id');
        $foodIds = array_unique(array_values($rows));

        //获取对应菜品数据
        $foodModel = new \Common\Model\FoodModel();
        $foodData = [];
        $foodIds && $foodData = $foodModel->where(['food_id'=>['in',$foodIds]])->getField('food_id,food_name');
        $restaurantData = M('restaurant')->where(['restaurant_id'=>['in',array_column($data,'restaurant_id')]])->getField('restaurant_id,restaurant_name');

        foreach ($content as $id => &$list) {
            foreach ($list as &$item) {
                $item['name'] = $foodData[$rows[$item['dish_id']]];
            }
        }

        foreach ($data as &$vo) {
            $vo['restaurant_name'] = $restaurantData[$vo['restaurant_id']];
            $vo['result_data'] = json_encode(array('url'=>$vo['img_url'],'recognize_result'=>$content[$vo['id']]),JSON_UNESCAPED_UNICODE);
            $vo['result_data'] = str_replace('rect','rectangle',$vo['result_data']);//rect 替换 rectangle
            $vo['result_data'] = str_replace("null",'""',$vo['result_data']);
        }

        return $data;
    }

    /**
     * 筛选条件
     * @param $post
     * @return mixed
     */
    protected function tableWhere($post)
    {
        $where = [];

        if (isset($post['last_id']) && $post['last_id'] !== '') {
            $where['id'] = ['lt', intval($post['last_id'])];
        }

        if (isset($post['business_id']) && $post['business_id'] !== '') {
            $where['restaurant_id'] = ['in', M('restaurant')->where(['business_id'=>$post['business_id']])->getField('restaurant_id',true)];
        }

        if (isset($post['restaurant_id']) && $post['restaurant_id'] !== '') {
            $where['restaurant_id'] = ['eq', intval($post['restaurant_id'])];
        }

        if (isset($post['platform']) && $post['platform'] !== '' && in_array(intval($post['platform']), [self::PLATFORM_ELEME, self::PLATFORM_BAIDU])) {
            $where['platform'] = ['eq', intval($post['platform'])];
        }

        if (isset($post['order_sn']) && $post['order_sn'] !== '') {
            $where['order_sn'] = ['like', "%{$post['order_sn']}%"];
        }

        $sTimestamp = $eTimestamp = '';
        if (isset($post['sTime']) && $post['sTime'] !== '') {
            $sTimestamp = strtotime($post['sTime']);
        }

        if (isset($post['eTime']) && $post['eTime'] !== '') {
            $eTimestamp = strtotime($post['eTime']);
        }

        if ($sTimestamp && !$eTimestamp) {
            $where['create_at'] = ['egt', $sTimestamp];
        }

        if (!$sTimestamp && $eTimestamp) {
            $where['create_at'] = ['elt', $eTimestamp];
        }

        if ($sTimestamp && $eTimestamp) {
            $where['create_at'] = ['between', "{$sTimestamp},{$eTimestamp}"];
        }

        $where['is_del'] = ['eq', self::IS_DEL_NO];

        $result['where'] = $where;
        $host = domain();
        $result['field'] = "id,restaurant_id,order_sn,from_unixtime(create_at) as create_at,CONCAT('{$host}',img_url) as img_url,content,device_mac";
        $result['order'] = 'id desc';

        return $result;
    }

    /**
     * 导出json数据
     * @param array $post
     */
    public function outputJson($post = []){
        $path = getcwd().'/Public/outputJson/';
        $fileName = md5(time().rand(11111,99999)).".json";
        $tableWhere = $this->tableWhere($post);
        $limit = 1000;
        while (true) {
            $data = $this->where($tableWhere['where'])->field($tableWhere['field'])->order($tableWhere['order'])->limit($limit)->select();
            $tableWhere['where']['id'] = ['lt', intval(min(array_column($data,'id')))];
            $data && $data = $this->formatTableData($data);
            foreach ($data as &$vo) {
                wFile($path,$fileName,$vo['result_data']);
                unset($vo);
            }
            if (empty($data) || (count($data) < $limit)) break;
        }
        //(new \Org\Net\Http())->download($path.$fileName, $fileName);
        download($path.$fileName, $fileName);
    }

    /**
     * 导出数据
     * @param array $post
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function export($post = [])
    {
        //vendor("PHPExcel.PHPExcel");
        import("Org.Util.PHPExcel");

        $objPHPExcel = new \PHPExcel();

        //$objPHPExcel->createSheet();
        //$objPHPExcel->setActiveSheetIndex(0);//把当前创建的sheet设置为活动sheet
        //$objSheet = $objPHPExcel->getActiveSheet();//获得当前活动Sheet

        //设置表头
        $title[] = array(
            'ID',
            '店铺ID',
            '订单号',
            '记录时间',
            '图片url',
            '内容',
        );

        $tableWhere = $this->tableWhere($post);
        $data = $this->where($tableWhere['where'])->order('id asc')->limit(10000)->getField($tableWhere['field'],true);

        $objPHPExcel->createSheet();
        $objPHPExcel->setActiveSheetIndex(0);
        $objPHPExcel->getActiveSheet(0)->fromArray(array_merge($title, $data ?: []));
        $objPHPExcel->getActiveSheet(0)->setTitle('数据报表');
        unset($data);

        //设置换行
        //$objSheet->getStyle('E3:E'.$j)->getAlignment()->setWrapText(TRUE);

        $filename = "订单结算菜品图片-" . date("YmdHis", time()) . '.xlsx';
        ob_end_clean();
        header('pragma:public');
        header('Content-type:application/vnd.ms-excel;');
        header("Content-Disposition:attachment;filename=$filename");//attachment新窗口打印inline本窗口打印
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }

    /**
     * 保存图片
     * @param string $imgBase64
     * @return string
     */
    protected function saveBase64Img($imgBase64)
    {
        if (empty($imgBase64)) return false;
        try {
            if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $imgBase64, $result)) {
                $type = $result[2];
            }
            $imageName = $this->orderSn . "." . $type;
            //判断是否有逗号，有就截取后半部分
            if (strstr($imgBase64, ",")) {
                $image = explode(',', $imgBase64);
                $image = $image[1];
            }
            //设置图片保存路径
            $mt = date('Ym');
            $path = getcwd() . "/Public/Uploads/OrderPic/{$this->restaurantId}/{$mt}/";
            !is_dir($path) && mkdir($path, 0777, true);
            //拼接路径和图片名称
            $imageSrc = $path . "/" . $imageName;
            //生成图片 返回字节数
            $res = file_put_contents($imageSrc, base64_decode($image)); //data:image/jpeg;base64, 拼接Base64
            if ($res) {
                return "/Public/Uploads/OrderPic/{$this->restaurantId}/{$mt}/" . $imageName;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            return false;
        }
    }

}

