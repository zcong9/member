<?php


namespace Common\Model;


class PaySelectModel extends BaseModel
{
    const OPEN = 1;//支付开关=》开启
    const STOP = 0;//支付开关=》关闭

    //支付方式
    const PAY_OY_WX = 'oy_wxpay';
    const PAY_OY_ALI = 'oy_alipay';
    const PAY_PRO_WX = 'wechat-code';
    const PAY_PRO_ALI = 'ali-code';
    const PAY_ALI_FACE = 'ali_face';
    const PAY_CASH = 'cash';
    const PAY_SHANDE = 'shande-code';
    const PAY_QWXPAY = 'qwxpay';

    const PAY_OY_WX_TITLE = '微信普通支付';
    const PAY_OY_ALI_TITLE = '支付宝普通支付';
    const PAY_PRO_WX_TITLE = '微信服务商支付';
    const PAY_PRO_ALI_TITLE = '支付宝服务商支付';
    const PAY_ALI_FACE_TITLE = '支付宝刷脸支付';
    const PAY_CASH_TITLE = '银联或现金支付';
    const PAY_SHANDE_TITLE = '聚合支付';
    const PAY_QWXPAY_TITLE = '微收银支付';

    const PAY_OY_WX_ICON = '/Public/images/pay_01.png';
    const PAY_OY_ALI_ICON = '/Public/images/pay_03.png';
    const PAY_PRO_WX_ICON = '/Public/images/pay_01.png';
    const PAY_PRO_ALI_ICON = '/Public/images/pay_03.png';
    const PAY_ALI_FACE_ICON = '/Public/images/pay_03.png';
    const PAY_CASH_ICON = '/Public/images/pay_02.png';
    const PAY_SHANDE_ICON = '/Public/images/pay_01.png';
    const PAY_QWXPAY_ICON = '/Public/images/pay_01.png';

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('name', 'require', '支付方式必填', 1),
        array('name', '0,100', '支付方式不能超过100个字符', 2, 'length'),
        array('value', [self::OPEN, self::STOP], '支付开关错误', 0, 'in'),
        array('img', '0,255', '支付图标不能超过255个字符', 2, 'length'),
        array('config_name', 'require', '支付名称对应code必须', 0),
        array('config_name', [self::PAY_OY_WX, self::PAY_OY_ALI, self::PAY_SHANDE, self::PAY_CASH, self::PAY_PRO_ALI, self::PAY_PRO_WX, self::PAY_CASH, self::PAY_QWXPAY], '支付名称对应code错误', 0, 'in'),
        array('s_num', 'number', '支付方式对应num错误', 0),
        array('business_id', 'number', '代理商ID错误', 0),
        array('restaurant_id', 'number', '店铺ID错误', 0),
    );

    /**
     * 添加
     * @param $post
     * @return array
     */
    public function addData($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => []];
        $data = $this->create($post, 1);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }

        try {
            $id = $this->add($data);
            if (!$id) {
                return $result;
            }
            $result['code'] = 0;
            $result['msg'] = '保存成功';
            return $result;
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 编辑
     * @param $post
     * @return array
     */
    public function editData($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => []];
        $data = $this->create($post, 2);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }

        try {
            if (false === $this->save($data)) {
                return $result;
            }
            $result['code'] = 0;
            $result['msg'] = '保存成功';
            return $result;
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 批量修改状态
     * @param $condition 条件
     * @param int $status 状态
     * @return bool|int|string
     */
    public function batchUpdateStatus($condition, $status)
    {
        if (empty($condition)) return false;
        in_array($status,[self::OPEN,self::STOP]) ?: $status = self::OPEN ;
        return $this->where($condition)->setField('value', $status);
    }

    /**
     * 根据config_name 获取 num
     * @param null $configName
     * @return int|int[]
     */
    public function getNumByConfigName($configName = null)
    {
        $arr = array_column($this->getDefaultList(), 's_num', 'config_name');
        if (null === $configName) return $arr;
        return $arr[$configName];
    }

    /**
     * 根据config_name 获取 name
     * @param null $configName
     * @return string|string[]
     */
    public function getNameByConfigName($configName = null)
    {
        $arr = array_column($this->getDefaultList(), 'name', 'config_name');
        if (null === $configName) return $arr;
        return $arr[$configName];
    }

    /**
     * 根据config_name 获取 img
     * @param null $configName
     * @return string|string[]
     */
    public function getImgByConfigName($configName = null)
    {
        $arr = array_column($this->getDefaultList(), 'img', 'config_name');
        if (null === $configName) return $arr;
        return $arr[$configName];
    }

    /**
     * 获取默认配置
     * @return array
     */
    public function getDefaultList()
    {
        $arr = [
            ['name' => self::PAY_PRO_WX_TITLE, 'config_name' => self::PAY_PRO_WX, 'img' => self::PAY_PRO_WX_ICON, 's_num' => 1],
            ['name' => self::PAY_PRO_ALI_TITLE, 'config_name' => self::PAY_PRO_ALI, 'img' => self::PAY_PRO_ALI_ICON, 's_num' => 2],
            ['name' => self::PAY_OY_WX_TITLE, 'config_name' => self::PAY_OY_WX, 'img' => self::PAY_OY_ALI_TITLE, 's_num' => 3],
            ['name' => self::PAY_OY_ALI_TITLE, 'config_name' => self::PAY_OY_ALI, 'img' => self::PAY_OY_ALI_ICON, 's_num' => 4],
            ['name' => self::PAY_CASH_TITLE, 'config_name' => self::PAY_CASH, 'img' => self::PAY_CASH_ICON, 's_num' => 5],
            ['name' => self::PAY_ALI_FACE_TITLE, 'config_name' => self::PAY_ALI_FACE, 'img' => self::PAY_ALI_FACE_ICON, 's_num' => 6],
            ['name' => self::PAY_SHANDE_TITLE, 'config_name' => self::PAY_SHANDE, 'img' => self::PAY_SHANDE_ICON, 's_num' => 7],
            ['name' => self::PAY_QWXPAY_TITLE, 'config_name' => self::PAY_QWXPAY, 'img' => self::PAY_QWXPAY_ICON, 's_num' => 15],
        ];
        return $arr;
    }
}