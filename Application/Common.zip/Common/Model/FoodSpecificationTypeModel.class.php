<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/9/14
 * Time: 15:43
 */

namespace Common\Model;


class FoodSpecificationTypeModel extends BaseModel
{
    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('food_type_name', 'require', '菜品规格名称', 1),
        array('food_type_name', '1,255', '菜品规格名称不能超过255个字符', 2,'length'),
        array('plus_price', 'currency', '加价格', 0),
        array('type_english_name', '0,255', '菜品规格英文名称不能超过255个字符', 2,'length'),
        array('type_packing_num', 'number', '规格打包盒数量不合法', 0),
        array('type_packing_price', 'currency', '规格打包盒价格不合法', 0),
        array('type_packing_code', '0,50', '规格打包盒编码不能超过50个字符', 2,'length'),
        array('type_img', '0,255', '规格类别图片地址超出限制', 2,'length'),
        array('type_vcode', '0,255', '快乐峰对应的菜品规格码不能超过255个字符', 2, 'length'),
        array('print_id', 'number', '关联打印机ID不合法', 0),
    );

    /**
     * 批量删除
     * @param array $ids
     * @return bool
     */
    public function batchDel(array $ids)
    {
        if (empty($ids)) return false;
        try {
            $where['food_type_id'] = ['in', $ids];
            // 清除关联关系
            M('food_specification_middle')->where($where)->delete();
            // 清除规格数据
            $this->where($where)->delete();
        } catch (\Exception $e) {
            return false;
        }
        return true;
    }

}