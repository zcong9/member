<?php

namespace Common\Model;

class OrderActivityLogModel extends \Common\Model\BaseModel
{
    const DEL_YES = 1;
    const DEL_NO = 0;
}

