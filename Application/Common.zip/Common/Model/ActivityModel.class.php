<?php

namespace Common\Model;

class ActivityModel extends \Common\Model\BaseModel
{
    /**
     * 数据表主键
     * @var string
     */
    protected $pk = 'act_id';

    /**
     * 模型名称
     * @var string
     */
    protected $name = 'activity';

    /**
     * 删除状态 1是 0否
     */
    const DEL_YES = 1;
    const DEL_NO = 0;

    /**
     * 活动类型 1满减 2折扣 3立减
     */
    const ACT_TYPE_FULL_REDUCTION = 1;
    const ACT_TYPE_DISCOUNT = 2;
    const ACT_TYPE_REDUCTION = 3;

    /**
     * 状态 1启用 0禁用
     */
    const STATUS_ENABLE = 1;
    const STATUS_DISABLE = 0;

    /**
     * 状态 1是 0否
     */
    const TIMING_ENABLE = 1;
    const TIMING_DISABLE = 0;

    /**
     * 自动完成
     * @var array
     */
    protected $_auto = array(

    );

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('business_id', 'number', '商家ID错误', 0),
        array('restaurant_id', 'number', '店铺ID错误', 0),
        array('act_title', 'require', '活动标题必须'),
        array('act_title', '1,120', '活动标题不能超过120个字符', 0, 'length'),
        array('act_describe', '0,255', '活动描述不能超过255个字符', 0, 'length'),
        array('act_type', array(self::ACT_TYPE_FULL_REDUCTION, self::ACT_TYPE_DISCOUNT,self::ACT_TYPE_REDUCTION), '活动类型错误', 0, 'in'),
        array('use_start_at', 'integer', '活动起始时间', 0),
        array('use_end_at', 'integer', '活动终止时间', 0),
        array('amount', 'integer', '优惠金额或折扣错误', 0),
        array('use_min_amount', 'integer', '最低消费金额错误', 0),
        array('status', array(self::STATUS_ENABLE, self::STATUS_DISABLE), '状态错误', 0, 'in'),
    );

    /**
     * act_type 文本
     * @param null $type
     * @return array|string
     */
    public function getActTypeText($type = null){
        $arr = array_column($this->getActTypeList(), 'text', 'act_type');
        if (null === $type) return $arr;
        return isset($arr[$type]) ? $arr[$type] : '';
    }

    /**
     * 活动类型
     * @return array
     */
    public function getActTypeList()
    {
        $arr = [
            ['text' => '满减', 'act_type' => self::ACT_TYPE_FULL_REDUCTION],
            ['text' => '折扣', 'act_type' => self::ACT_TYPE_DISCOUNT],
            ['text' => '立减', 'act_type' => self::ACT_TYPE_REDUCTION],
        ];
        return $arr;
    }

    /**
     * 获取活动扩展数据
     * @param $where
     * @return array|bool|mixed|string|null
     */
    public function getActExt($where){
        $data = M('activity_ext')->where($where)->select();
        if (empty($data)) return [];
        foreach ($data as &$vo) {
            $vo['start_time'] = $vo['start_time'] > 0 ? sprintf('%02d',bcdiv($vo['start_time'],3600)).':'.sprintf('%02d',bcdiv(bcmod($vo['start_time'],3600),60)): '00:00';
            $vo['end_time'] = $vo['end_time'] > 0 ? sprintf('%02d',bcdiv($vo['end_time'],3600)).':'.sprintf('%02d',bcdiv(bcmod($vo['end_time'],3600),60)): '00:00';
        }
        return $data;
    }

    /**
     * 活动扩展设置
     * @param $actId
     * @param $post
     * @return bool|int|mixed|string
     */
    public function setActExt($actId,$post){
        if (!$actId) return false;
        if (!is_array($post) || empty($post)) {
            return $this->delActExtByActId($actId);
        }
        $list = $this->getActExt(['act_id'=>$actId]);
        $extIds = array_column($list,'id');
        $insData = $upData = $delData = [];
        foreach ($post as $k => &$vo) {
            $item['act_id'] = $actId;
            //处理week
            for ($i=0;$i<7;$i++) {
                isset($vo['week'][$i]) ? $item['week'] .= 1 : $item['week'] .= 0;
            }
            //处理start_time
            $item['start_time'] = !empty($vo['start_time']) ? substr($vo['start_time'],0,2) * 3600 + substr($vo['start_time'],3,2) * 60 : 0;
            //处理end_time
            $item['end_time'] = !empty($vo['end_time']) ? substr($vo['end_time'],0,2) * 3600 + substr($vo['end_time'],3,2) * 60 : 0;
            if (isset($extIds[$k])) {
                $item['id'] = $extIds[$k];
                $upData[] = $item;
            } else {
                $insData[] = $item;
            }
            $item = [];
            unset($vo);
        }

        $actExtMod = M('activity_ext');
        if (!empty($insData)) {
            $actExtMod->addAll($insData);
        }

        if (!empty($upData)) {
            foreach ($upData as &$vo) {
                $actExtMod->save($vo);
            }
        }

        $delData = array_diff($extIds,array_column($upData,'id') ?: []);
        if (!empty($delData)) {
            $this-$this->delActExtByActId(['id'=>['in',$delData]]);
        }

        return true;
    }

    /**
     * 删除活动扩展数据
     * @param $actId
     * @return bool|int|mixed|string
     */
    public function delActExtByActId($actId){
        $where = is_array($actId) ? $actId : ['act_id'=>$actId];
        return M('activity_ext')->where($where)->delete();
    }
}

