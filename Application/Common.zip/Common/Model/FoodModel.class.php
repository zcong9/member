<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/9/15
 * Time: 19:48
 */

namespace Common\Model;


class FoodModel extends BaseModel
{
    const IS_SALES_YES = 1;//上架
    const IS_SALES_NO = 0;//下架

    //油炸/非油炸  1油炸0非油炸
    const IS_FRIED_YES = 1;
    const IS_FRIED_NO = 0;

    //是否允许打折:0-不允许，1-允许
    const IS_RATIO_YES = 1;
    const IS_RATIO_NO = 0;

    //未售罄:0-已售罄，1-未售罄
    const IS_SOLD_OUT_YES = 1;
    const IS_SOLD_OUT_NO = 0;

    //是否可堂食:0-不可堂食，1-可堂食
    const IS_RESERVE_YES = 1;
    const IS_RESERVE_NO = 0;

    //是否可外带:0-不可外带,1-可外带
    const IS_TAKEOUT_YES = 1;
    const IS_TAKEOUT_NO = 0;

    //是否是套餐 0不是 1是
    const IS_PACKAGE_YES = 1;
    const IS_PACKAGE_NO = 0;

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('food_name', 'require', '菜品名称必填', 1),
        array('food_name', '1,255', '菜品名称不能超过255个字符', 0, 'length'),
        array('food_english_name', '1,255', '英文名称不能超过255个字符', 2, 'length'),
        array('business_id', 'number', '代理商ID错误', 0),
        array('restaurant_id', 'number', '店铺ID错误', 0),
        array('food_model_id', 'number', '菜单ID错误', 0),
        array('food_price', 'currency', '价格不合法', 0),
        array('member_price', 'currency', '会员价格不合法', 0),
        array('img', '0,255', '图片地址不能超过255个字符', 0, 'length'),
        array('bewrite', '0,100', '菜品描述不能超过100个字符', 0, 'length'),
        array('recommendation', 'number', '推荐指数不合法', 0),
        array('hot', 'number', '口味指数不合法', 0),
        array('code', '0,30', '条码不能超过30个字符', 0, 'length'),
        array('is_fried', array(self::IS_FRIED_NO, self::IS_FRIED_YES), '油炸类型错误', 0, 'in'),
        array('is_ratio', array(self::IS_RATIO_NO, self::IS_RATIO_YES), '打折类型错误', 0, 'in'),
        array('is_sales', array(self::IS_SALES_NO, self::IS_SALES_YES), '上下架状态错误', 0, 'in'),
        array('is_sold_out', array(self::IS_SOLD_OUT_NO, self::IS_SOLD_OUT_YES), '售罄状态错误', 0, 'in'),
        array('is_reserve', array(self::IS_RESERVE_NO, self::IS_RESERVE_YES), '堂食状态错误', 0, 'in'),
        array('is_takeout', array(self::IS_TAKEOUT_NO, self::IS_TAKEOUT_YES), '外带状态错误', 0, 'in'),
        array('start_num', 'number', '起点份数不合法', 0),
        array('sale_num', 'number', '每日限量不合法', 0),
        array('sort_code', 'number', '菜品顺序码不合法', 0),
        array('last_ver', '0,30', '版本号不能超过30个字符', 2, 'length'),
        array('is_package', array(self::IS_PACKAGE_NO, self::IS_PACKAGE_YES), '套餐状态错误', 0, 'in'),
        array('packing_price', 'currency', '打包盒单价不合法', 0),
        array('packing_num', 'number', '打包盒数量不合法', 0),
        array('packing_vcode', '0,30', '打包盒编码不能超过30个字符', 2, 'length'),
        array('district_id', 'number', '分区ID不合法', 0),
        array('print_id', 'number', '打印机ID不合法', 0),
        array('tag_print_id', 'number', '标签打印机ID不合法', 0),
        array('have_sales', 'number', '已销售数量不合法', 0),
        array('correlation_specification_id', '0,255', '菜品关联的规格ID超过最大限制', 0, 'length'),
    );

    //自动完成
    protected $_auto = array(
        array('save_time', 'setSaveTime', 3, 'callback'),
    );

    protected function setSaveTime()
    {
        return date('Y-m-d H:i:s');
    }

    public function tableData($post)
    {

        if (!isset($post['limit']) || empty($post['limit'])) {
            $post['limit'] = 8;
        }

        $tableWhere = $this->tableWhere($post);
        $total = $this->alias('f')->join($tableWhere['join'])->where($tableWhere['where'])->count();

        $Page = new \Think\PageAjax($total, $post['limit']);
        $data = $this->alias('f')->where($tableWhere['where'])
            ->field($tableWhere['field'])
            ->join($tableWhere['join'])
            ->order($tableWhere['order'])
            ->limit($Page->firstRow . ',' . $Page->listRows)->select();

        if ($data) {

            //获取菜品分类名称
            if (isset($post['food_category_id']) && $post['food_category_id'] !== '') {
                $catName = (new \Common\Model\FoodCategoryModel())->where(['category_id' => (int)$post['food_category_id']])->getField('category_name') ?: '无';
                foreach ($data as &$val) {
                    $val['category_id'] = (int)$post['food_category_id'];
                    $val['category_name'] = $catName;
                }
            } else {

                $catItems = M('food_restaurant_category')->alias('frc')
                    ->field('frc.food_restaurant_id,fc.category_id,fc.category_name')
                    ->join('food_category fc on frc.category_id = fc.category_id')
                    ->where(['frc.food_restaurant_id' => ['in', array_column($data, 'food_restaurant_id')]])
                    ->select();
                $catItems = array_column($catItems, null, 'food_restaurant_id');

                foreach ($data as &$val) {
                    $val['category_id'] = isset($catItems[$val['food_restaurant_id']]['category_id']) ? $catItems[$val['food_restaurant_id']]['category_id'] : 0;
                    $val['category_name'] = isset($catItems[$val['food_restaurant_id']]['category_name']) ? $catItems[$val['food_restaurant_id']]['category_name'] : '无';
                }

            }
        }

        $page_en = str_replace('上一页', 'Previous', $Page->show());
        $page_en = str_replace('下一页', 'next', $page_en);
        $page_en = str_replace('首页', 'first', $page_en);

        $page_zhTw = str_replace('上一页', '上壹頁', $Page->show());
        $page_zhTw = str_replace('下一页', '下壹頁', $page_zhTw);
        $page_zhTw = str_replace('首页', '首頁', $page_zhTw);

        return ['data' => $data, 'page' => $Page->show(), 'page_zhTw' => $page_zhTw, 'page_en' => $page_en, 'total' => $total];
    }

    protected function tableWhere($post)
    {

        $where = [];

        if (isset($post['business_id']) && $post['business_id'] !== '') {
            $where['fr.business_id'] = ['eq', intval($post['business_id'])];
        }

        if (isset($post['restaurant_id']) && $post['restaurant_id'] !== '') {
            $where['fr.restaurant_id'] = ['eq', intval($post['restaurant_id'])];
        }

        if (isset($post['food_model_id']) && $post['food_model_id'] !== '') {
            $where['fr.food_model_id'] = ['eq', intval($post['food_model_id'])];
        }

        if (isset($post['is_sales']) && $post['is_sales'] !== '') {
            $where['fr.is_sales'] = ['eq', intval($post['is_sales'])];
        }

        if (isset($post['is_sold_out']) && $post['is_sold_out'] !== '') {
            $where['f.is_sold_out'] = ['eq', intval($post['is_sold_out'])];
        }

        if (isset($post['is_ratio']) && $post['is_ratio'] !== '') {
            $where['f.is_ratio'] = ['eq', intval($post['is_ratio'])];
        }

        if (isset($post['is_fried']) && $post['is_fried'] !== '') {
            $where['f.is_fried'] = ['eq', intval($post['is_fried'])];
        }

        if (isset($post['is_reserve']) && $post['is_reserve'] !== '') {
            $where['f.is_reserve'] = ['eq', intval($post['is_reserve'])];
        }

        if (isset($post['is_takeout']) && $post['is_takeout'] !== '') {
            $where['f.is_takeout'] = ['eq', intval($post['is_takeout'])];
        }

        //菜品分类ID
        if ($post['food_category_id'] && $post['food_category_id'] !== '') {
            $foodResIds = M('food_restaurant_category')->distinct(true)->where(['category_id' => (int)$post['food_category_id']])->getField('food_restaurant_id', true);
            if ($foodResIds) {
                $where['fr.food_restaurant_id'] = ['in', $foodResIds];
            } else {
                $where['fr.food_restaurant_id'] = ['eq', 0];
            }
        }

        //菜品名称
        if (isset($post['food_name']) && $post['food_name'] !== '') {
            $search_keywords = trim($post['food_name']);
            $foodIds = $this->where(['business_id' => $post['business_id'], 'food_name' => ['like', "%{$search_keywords}%"]])->getField('food_id', true);
            $foodIds = array_unique($foodIds);
            if ($foodIds) {
                $where['fr.food_id'] = ['in', $foodIds];
            } else {
                $where['fr.food_id'] = ['eq', 0];
            }
        }

        $timestamp = time();
        $result['where'] = $where;
        $result['field'] = "f.food_id,fr.food_restaurant_id,fr.sort,f.is_sales,f.sale_num,fr.food_model_id,f.food_name,f.food_english_name,CONCAT(f.img,'{$timestamp}') as img,f.food_price,f.hot,f.recommendation,f.code";
        $result['join'] = "food_restaurant as fr on fr.food_id=f.food_id";
        $result['order'] = 'fr.sort';

        return $result;
    }

    /**
     * 添加菜品
     * @param $post
     * @return array
     */
    public function addFood($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => ''];
        // 验证
        $data = $this->create($post, 1);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }
        try {
            $id = $this->add($data);
            $result['data'] = ['food_id'=>$id];
            if ($id) {
                $result['code'] = 0;
                $result['msg'] = '保存成功';
            }
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 编辑菜品
     * @param $post
     * @return array
     */
    public function editFood($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => ''];
        // 验证
        $data = $this->create($post);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }
        try {
            if (false === $this->save($data)) return $result;
            $result['code'] = 0;
            $result['msg'] = '保存成功';
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 菜品当天售罄验证
     * @param $food_id
     * @param $post
     * @return mixed
     */
    public function checkSoldOut($food_id,&$post)
    {
        $item = $this->where(['food_id' => $food_id])->field('is_sold_out,save_time,sale_num,have_sales')->find();
        if (empty($item)) return $post;
        // 修改了每日供应量，与售罄进行对比，比售罄量多则推送消息给安卓
        $sale_num = $post['sale_num'];
        $Date = date('Y-m-d', time());
        $startTime = '00:00:00';
        $endTime = '23:59:59';
        $startTimeStr = strtotime($Date . " " . $startTime);
        $endTimeStr = strtotime($Date . " " . $endTime);
        $update_time = strtotime($item['save_time']);
        // 情况一：
        // 更新时间不在今天内的，改为未售罄（is_sold_out = 1），已卖份数(have_sales)重新置为0，update_time更新为当前
        // 然后判断当前每日供应量(sale_num)为0的话就更新为已售罄
        // 情况二：
        // 更新时间在今天范围内的，is_sold_out为0，然后判断当前sale_num大于have_sales的话就上架，is_sold_out为1
        // 更新时间在今天范围内的，is_sold_out为1，然后判断当前sale_num小于等于have_sales的话就售罄，is_sold_out为0
        if (($startTimeStr < $update_time && $update_time < $endTimeStr) && $update_time !== null) {
            // is_sold_out为1
            if ($item['is_sold_out'] == self::IS_SOLD_OUT_NO) {
                if ($sale_num > $item['have_sales']) {
                    $post['is_sold_out'] = self::IS_SOLD_OUT_YES;
                }
            } else {
                if ($sale_num <= $item['have_sales']) {
                    $post['is_sold_out'] = self::IS_SOLD_OUT_NO;
                }
            }
        } else {
            // 不是在今天范围内
            // is_sold_out置为1，已卖份数置为0，更新时间为当前
            $post['is_sold_out'] = self::IS_SOLD_OUT_YES;
            $post['have_sales'] = 0;
            // 如果客户设置的每天供应量为0的话，则也为shutdown售罄，推给安卓
            if ($sale_num == 0) {
                $post['is_sold_out'] = self::IS_SOLD_OUT_NO;
            }
        }
        return $post;
    }

    /**
     * 设置菜品分类关联表
     * @param int $food_restaurant_id
     * @param $post
     * @return bool
     * @throws \Exception
     */
    public function setFoodRes(&$food_restaurant_id = 0,$post)
    {
        try {
            $foodResModel = D('food_restaurant');
            $data =$foodResModel ->create($post);
            if (false === $data) return false;
            $food_restaurant_id ? $rep = $foodResModel->save($data) : $rep = $foodResModel->add($data);
            if (false === $rep) {
                return false;
            }
            $food_restaurant_id = $food_restaurant_id ?: $rep;
            $foodResCateModel = D('food_restaurant_category');
            $foodResCateItems = $foodResCateModel->where(['food_restaurant_id'=>$food_restaurant_id])->select();
            $cateIds = array_column($foodResCateItems,'category_id');
            $insData = [];
            foreach ($post['category_ids'] as $val) {
                if (!in_array($val,$cateIds)) {
                    $insData[] = array(
                        'food_restaurant_id' => $food_restaurant_id,
                        'category_id' => $val,
                    );
                }
            }
            $delCatIds = array_diff($cateIds,$post['category_ids']);
            $delCatIds && $foodResCateModel->where(['food_restaurant_id'=>$food_restaurant_id,'category_id'=>['in',$delCatIds]])->delete();
            $insData && $foodResCateModel->addAll($insData);
            return true;
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 设置哗啦啦开放平台菜品关联
     * @param int $food_id
     * @param $open_food_id
     * @return bool
     */
    public function setUnionOpenFoodData($food_id,$open_food_id){
        if (!$food_id || !$open_food_id) return false;
        $uofModel = M('union_open_food');
        $row = $uofModel->where(['food_id'=>$food_id])->find();
        if ($row){
            $uofModel->where(['food_id'=>$food_id])->setField('open_food_id',$open_food_id);
        } else {
            $uofModel->add(['food_id'=>$food_id,'open_food_id'=>$open_food_id]);
        }
        return true;
    }

    /**
     * 根据菜品ID删除
     * @param $food_id
     * @return array
     */
    public function delById($food_id)
    {
        $result = ['code' => -1, 'msg' => '删除失败', 'data' => []];
        $model = M();
        $model->startTrans();
        if(false === $this->batchDelFoodByIds([$food_id])){
            $model->rollback();
            return $result;
        }
        $model->commit();
        $result['code'] = 0;
        $result['msg'] = '删除成功';
        return $result;
    }

    /**
     * 根据菜品ID批量删除
     * @param array $ids
     * @return bool
     */
    public function batchDelFoodByIds(array $ids)
    {
        if (empty($ids)) return false;

        try {

            //查出菜品中间表 food_restaurant_id
            $foodResIds = M('food_restaurant')->where(['food_id' => ['in', $ids]])->getField('food_restaurant_id', true);
            //通过 food_restaurant_id 查出关联的规格 food_specification_id
            if (!empty($foodResIds)) {

                // 查出规格id
                $foodSpecModel = new \Common\Model\FoodSpecificationModel();
                $foodSpecIds = $foodSpecModel->where(['food_restaurant_id' => ['in', $foodResIds]])->getField('food_specification_id', true);
                $foodSpecIds && $res = $foodSpecModel->batchDelSpec($foodSpecIds);
                if (isset($res) && (true !== $res)) return false;

                //查出菜品中间表
                M('food_restaurant')->where(['food_restaurant_id' => ['in', $foodResIds]])->delete();
            }

            //删除饿了么视觉图片库
            (new \Common\Model\FoodElmImgModel())->batchDelByFoodIds($ids);

            //删除food表数据
            $this->where(['food_id' => ['in', $ids]])->delete();

            return true;

        } catch (\Exception $e) {

            return false;
        }
    }

    /**
     * 批量上下架
     * @param $ids
     * @param string $type
     * @return array
     */
    public function batchMarketable($ids, $type = 'up')
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];

        if ($type == 'up') {
            $is_sales = self::IS_SALES_YES;
        } elseif ($type == 'down') {
            $is_sales = self::IS_SALES_NO;
        } else {
            return $result;
        }

        if (false !== $this->where(['food_id' => ['in', $ids]])->save(['is_sales' => $is_sales])) {
            $this->pushStatus($ids,$is_sales);
            $result['code'] = 0;
            $result['msg'] = '操作成功';
        }

        return $result;
    }

    /**
     * 上下架状态推送iot
     * @param $ids
     * @param $SalesType
     * @return bool
     */
    public function pushStatus($ids,$SalesType){
        if (empty($ids)) return false;
        // 更改上下架成功后推送iot通知本店下关联该菜单模型的设备
        /*{
            "DeviceName":"FOUND_KLE_001",
            "MenuType":1,     //菜单类型   1:菜品分类    2：菜品   3：菜品售罄状态
            "Data": "12345678"    //分类id   或者  菜品id
            "SalesType": 0     // 0：下架    1：上架
        }*/
        $whereDevice = ['restaurant_id'=>$this->restaurantId,'status'=>1];
        $deviceList = M('iot_device')->where($whereDevice)->getField('device_name',true);
        try {
            if ($deviceList) {
                $Iot = new \data\service\IotService();
                $iotData['MenuType'] = 2;
                $iotData['SalesType'] = $SalesType;
                foreach ($deviceList as $device_name) {
                    $iotData['DeviceName'] = $device_name;
                    foreach ($ids as $id) {
                        $iotData['Data'] = (string)$id;
                        $Iot->sendInstruction($device_name, $iotData, 'MenuInformation');
                    }
                }
                return true;
            }
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }


    public function addFoodAttr($data)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];

        $foodModel = $this->where(['restaurant_id' => $this->restaurantId, 'code' => $data['type_vcode']])->find();
        if (empty($foodModel)) {
            $result['msg'] = '操作失败，菜单中没有存在该菜品条码！';
            return $result;
        }

        //设置打包盒信息
        $data['type_packing_num'] = $foodModel['packing_num'];
        $data['type_packing_price'] = $foodModel['packing_price'];
        $data['type_packing_code'] = $foodModel['packing_vcode'];

        $model = M();
        $model->startTrans();
        try {

            $foodTypeId = M('food_specification_type')->add($data);
            $foodTypeId && $fsmId = M('food_specification_middle')->add(['food_specification_id' => $data['food_specification_id'], 'food_type_id' => $foodTypeId]);

            if ($foodTypeId && $fsmId) {
                $model->commit();
                $result['code'] = 0;
                $result['msg'] = '操作成功';
                $result['data'] = ['food_type_id' => $foodTypeId];
            } else {
                $model->rollback();
            }

        } catch (\Exception $e) {
            $model->rollback();
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    public function editFoodAttr($data)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];

        $foodModel = $this->where(['restaurant_id' => $this->restaurantId, 'code' => $data['type_vcode']])->find();
        if (empty($foodModel)) {
            $result['msg'] = '操作失败，菜单中没有存在该菜品条码！';
            return $result;
        }

        //设置打包盒信息
        $data['type_packing_num'] = $foodModel['packing_num'];
        $data['type_packing_price'] = $foodModel['packing_price'];
        $data['type_packing_code'] = $foodModel['packing_vcode'];

        try {

            $rel = M('food_specification_type')->save($data);

            if (false !== $rel) {
                $result['code'] = 0;
                $result['msg'] = '操作成功';
                $result['data'] = ['food_type_id' => $data['food_type_id']];
            }

        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    public function delFoodAttr($attr_id)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];
        if (empty($attr_id)) return $result;

        $model = M();
        $model->startTrans();

        try {

            $condition['food_type_id'] = $attr_id;
            // 删除关联关系
            M('food_specification_middle')->where($condition)->delete();
            // 删除规格属性
            M('food_specification_type')->where($condition)->delete();

            $model->commit();
            $msg['code'] = 0;
            $msg['msg'] = '操作成功';

        } catch (\Exception $e) {
            $model->rollback();
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    /**
     * 取消关联规格模型(多个菜品取消关联)
     * @param array $foodIds 需要取消关联的菜品id数组
     * @return array
     **/
    public function cancelCorrelationSpecModel(array $foodIds)
    {
        $result = ['code' => -1, 'msg' => '取消关联失败', 'data' => []];
        if (empty($foodIds)) {
            $result['msg'] = '请选择要取消关联规格模型的菜品';
            return $result;
        }
        $model = M();
        $model->startTrans();
        try {

            $this->where(['food_id' => ['in', $foodIds]])->setField('correlation_specification_id', 0);
            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '成功取消关联';

        } catch (\Exception $e) {

            $model->rollback();
        }
        return $result;
    }

    /**
     * 取消关联规格模型(整个菜单)
     * @param int $foodModelId 菜单id
     * @return array
     **/
    public function cancelCorrelationAllSpecModel($foodModelId)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];

        if (!$foodModelId) {
            $result['msg'] = '请选择要取消关联规格模型的菜单';
            return $result;
        }

        $model = M();
        $model->startTrans();
        try {

            $this->where(['food_model_id' => $foodModelId, 'business_id' => $this->businessId, 'restaurant_id' => 0])
                ->setField('correlation_specification_id', 0);

            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '操作成功';

        } catch (\Exception $e) {
            $model->rollback();
        }

        return $result;
    }

    /**
     * 菜单关联规格模型(整个菜单)
     * @param int $foodModelId 菜单id
     * @param array specId 规格id数组
     * @return array
     **/
    public function menuCorrelationAllSpecModel($foodModelId, array $specId)
    {
        $result = ['code' => -1, 'msg' => '关联失败', 'data' => []];

        if (!$foodModelId) {
            $result['msg'] = '请选择要关联规格模型的菜单';
            return $result;
        }

        if (empty($specId)) {
            $result['msg'] = '请选择要关联的规格模型';
            return $result;
        }

        // 组装规格id
        $data['correlation_specification_id'] = implode(',', $specId);

        $foodSpecModel = new \Common\Model\FoodSpecificationModel();
        // 检测加价得(附加规格属性)是否唯一,一个菜品中只能有一个加价得
        $isAddSpecCount = $foodSpecModel->where(['food_specification_id' => ['in', $data['correlation_specification_id']], 'is_additional_specification' => ['eq', $foodSpecModel::IS_ADDITIONAL_SPECIFICATION_YES]])->count();
        if ($isAddSpecCount > 1) {
            $result['msg'] = '一个菜品只能关联一个加价得,请重新选择';
            return $result;
        }

        $model = M();
        $model->startTrans();
        try {

            // 找出有设置加价得的通用规格
            if ($isAddSpecCount) {

                // 找出菜品中有设置加价得的规格
                $allFoodsId = M('food_restaurant')
                    ->where(['food_model_id' => $foodModelId, 'business_id' => $this->businessId, 'restaurant_id' => 0])
                    ->getField('food_restaurant_id', true);

                $allFoodsId && $isSetAddIds = $foodSpecModel
                    ->where(['food_restaurant_id' => ['in', $allFoodsId], 'is_additional_specification' => $foodSpecModel::IS_ADDITIONAL_SPECIFICATION_YES])
                    ->getField('food_specification_id', true);

                if (isset($isSetAddIds) && !empty($isSetAddIds)) {
                    $foodSpecModel->where(['food_specification_id' => ['in', $isSetAddIds]])
                        ->save(['is_additional_specification' => $foodSpecModel::IS_ADDITIONAL_SPECIFICATION_NO]);
                }

            }

            //更新 food 表 correlation_specification_id
            $this->where(['food_model_id' => $foodModelId, 'business_id' => $this->businessId, 'restaurant_id' => 0])->save($data);
            $model->commit();

            $result['code'] = 0;
            $result['msg'] = '关联成功';

        } catch (\Exception $e) {

            $model->rollback();
        }

        return $result;
    }

    /**
     * 菜单关联规格模型(多个菜品关联)
     * @param int $foodModelId 菜单id
     * @param array $foodIds 菜品id数组
     * @param array $specIds 规格id数组
     * @return array
     **/
    public function menuCorrelationSpecModel($foodModelId, array $specIds, array $foodIds)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];

        if (empty($foodModelId)) {
            $result['msg'] = '请选择要关联规格模型的菜单';
            return $result;
        }

        // 规格模型id
        if (empty($specIds)) {
            $result['msg'] = '请选择要关联的规格模型';
            return $result;
        }

        if (empty($foodIds)) {
            $result['msg'] = '请选择要关联规格模型的菜品';
            return $result;
        }

        // 组装规格id
        $data['correlation_specification_id'] = implode(',', $specIds);
        $model = M();

        $foodSpecTypeModel = M('food_specification_type');
        $foodSpecModel = new \Common\Model\FoodSpecificationModel();

        //判读关联的规格中的菜品条码是否存在于该菜单里面，若无则关联失败  start 2020401
        $code_arr = array_unique(array_filter($this->where(['food_model_id' => $foodModelId])->getField('code', true)));
        if (empty($code_arr)) {
            $result['msg'] = '本菜单中不存在条码';
            return $result;
        }

        foreach ($specIds as $specId) {

            $spec_type_vcode = $foodSpecTypeModel->alias('a')
                ->join('left join food_specification_middle b on a.food_type_id = b.food_type_id')
                ->join('left join food_specification c on b.food_specification_id=c.food_specification_id')
                ->where(['c.food_specification_id' => $specId])
                ->field('a.food_type_name,a.type_vcode,c.name')
                ->select();

            if (!empty($spec_type_vcode)) {

                foreach ($spec_type_vcode as $vvalue) {

                    if (!in_array($vvalue['type_vcode'], $code_arr)) {
                        $result['msg'] = '本菜单中不存在 ' . $vvalue['name'] . ':' . $vvalue['food_type_name'] . '的条码';
                        return $result;
                    }

                }

            }
        }
        //判读关联的规格中的菜品条码是否存在于该菜单里面，若无则关联失败  end 2020401

        $model->startTrans();

        try {

            // 检测加价得(附加规格属性)是否唯一,一个菜品中只能有一个加价得
            $isAddSpecCount = $foodSpecModel->where(['food_specification_id' => ['in', $data['correlation_specification_id']]])->count();
            if ($isAddSpecCount > 1) {
                $result['msg'] = '一个菜品只能关联一个加价得,请重新选择';
                return $result;
            }

            // 找出有设置加价得的通用规格
            $foodResModel = M('food_restaurant');

            if ($isAddSpecCount) {

                $frids = $foodResModel->where(['food_id' => ['in', $foodIds]])->getField('food_restaurant_id', true);
                // 找出菜品中有设置加价得的规格
                $frids && $isSetAddIds = $foodSpecModel
                    ->where(['food_restaurant_id' => ['in', $frids], 'is_additional_specification' => $foodSpecModel::IS_ADDITIONAL_SPECIFICATION_YES])
                    ->getField('food_specification_id', true);
                isset($isSetAddIds) && $isSetAddIds && $foodSpecModel->where(['food_specification_id' => ['in', $isSetAddIds]])->save(['is_additional_specification' => $foodSpecModel::IS_ADDITIONAL_SPECIFICATION_NO]);
            }

            $this->where(['food_id' => ['in', $foodIds]])->save($data);

            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '关联成功';

        } catch (\Exception $e) {
            $model->rollback();
        }

        return $result;
    }

    /**
     * 菜品上移
     * @param $data
     * @return array
     */
    public function moveUp($data)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];

        //当前点击id的数据
        $foodResModel = M('food_restaurant');
        $currentItem = $foodResModel->where(['food_id' => $data['food_id']])->find();
        if (empty($currentItem) || $currentItem['sort'] == 0) return $result;

        //比当前点击id排序前一条数据
        if (!isset($data['tran_id'])) {
            $where = ['restaurant_id' => $this->restaurantId, 'sort' => array('lt', $currentItem['sort'])];
            $this->businessId && $where['business_id'] = $this->businessId;
            isset($data['food_model_id']) && $where['food_model_id'] = $data['food_model_id'];
        } else {
            $where = ['food_id' => $data['tran_id']];
        }
        $preItem = $foodResModel->where($where)->order('sort desc')->find();
        if (empty($preItem) || $preItem['sort'] == 0) return $result;

        $foodResModel->where(['food_id' => $currentItem['food_id']])->save(['sort' => $preItem['sort']]);
        $foodResModel->where(['food_id' => $preItem['food_id']])->save(['sort' => $currentItem['sort']]);

        $this->where(['food_id' => $currentItem['food_id']])->save(['sort' => $preItem['sort']]);
        $this->where(['food_id' => $preItem['food_id']])->save(['sort' => $currentItem['sort']]);

        $result['code'] = 0;
        $result['msg'] = '操作成功';

        return $result;

    }

    /**
     * 菜品下移
     * @param $data
     * @return array
     */
    public function moveDown($data)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];

        //当前点击id的数据
        $foodResModel = M('food_restaurant');
        $currentItem = $foodResModel->where(['food_id' => $data['food_id']])->find();
        if (empty($currentItem)) return $result;

        //比当前点击id排序后一条数据
        if (!isset($data['tran_id'])) {
            $where = ['restaurant_id' => $this->restaurantId, 'sort' => array('gt', $currentItem['sort'])];
            $this->businessId && $where['business_id'] = $this->businessId;
            isset($data['food_model_id']) && $where['food_model_id'] = $data['food_model_id'];
        } else {
            $where = ['food_id' => $data['tran_id']];
        }
        $nextItem = $foodResModel->where($where)->order('sort asc')->find();
        if (empty($nextItem) || $nextItem['sort'] == 0) return $result;

        $foodResModel->where(['food_id' => $currentItem['food_id']])->save(['sort' => $nextItem['sort']]);
        $foodResModel->where(['food_id' => $nextItem['food_id']])->save(['sort' => $currentItem['sort']]);

        $this->where(['food_id' => $currentItem['food_id']])->save(['sort' => $nextItem['sort']]);
        $this->where(['food_id' => $nextItem['food_id']])->save(['sort' => $currentItem['sort']]);

        $result['code'] = 0;
        $result['msg'] = '操作成功';

        return $result;
    }
}