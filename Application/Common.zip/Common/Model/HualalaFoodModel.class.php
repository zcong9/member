<?php

namespace Common\Model;

class HualalaFoodModel extends \Common\Model\BaseModel
{
    const DEL = 1;
    const NOT_DEL = 0;
    const DB_HUALALA_DATA = 'DB_HUALALA_FOOD_';

    /**
     * 同步哗啦啦数据
     * @return array
     */
    public function doPullOpenHualalaFood(){
        $result = array('code'=>0,'msg'=>'同步数据失败','data'=>array());
        //获取当前店铺哗啦啦配置
        $hualalaConfig = M('hualala_config')->where(array('restaurant_id' => $this->restaurantId,'status' => 1))->find();
        if (empty($hualalaConfig)) {
            $result['msg'] = '哗啦啦配置获取失败，请开启后台配置';
            return $result;
        }
        //组装开发者数据
        $openParams = array(
            'appKey' => $hualalaConfig['app_key'],
            'appSecret' => $hualalaConfig['app_secret'],
            'groupID' => $hualalaConfig['group_id'],
            'shopID' => $hualalaConfig['shop_id'],
        );
        try {
            $hDoc = \Lib\hualala\Doc::instance($openParams);
            $res = $hDoc->getOpenFood(array('groupID'=>$hualalaConfig['group_id'],'shopID'=>$hualalaConfig['shop_id']));
            if (true === $res) {
                $rep = $hDoc->getResult();
                $this->doSaveData($rep['data']['foodList']);
                $result['code'] = 1;
                $result['msg'] = '同步数据成功';
            } else {
                $result['msg'] = '同步数据失败,'.$hDoc->getError();
            }
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 数据入库
     * @param array $items
     * @return bool
     * @throws \Exception
     */
    public function doSaveData(array $items){

        if (empty($items)) return false;
        $this->startTrans();
        try {
            $fooIds = [];
            foreach ($items as &$val) {
                $fooIds[] = $val['foodID'];
                $data['restaurant_id'] = $this->restaurantId;
                $data['foodID'] = $val['foodID'];
                $data['foodName'] = $val['foodName'];
                $data['foodCode'] = $val['foodCode'];
                $data['shopID'] = $val['shopID'];
                $data['groupID'] = $val['groupID'];
                $data['units'] = json_encode($val['units'],JSON_UNESCAPED_UNICODE);
                $row = $this->where(array('restaurant_id'=>$this->restaurantId,'foodID'=>$val['foodID'],'is_del'=>self::NOT_DEL))->find();
                //判断菜品是否已存在 存在更新 不存在插入
                if ($row) {
                    $data['update_at'] = time();
                    $this->where(array('restaurant_id'=>$this->restaurantId,'foodID'=>$val['foodID'],'is_del'=>self::NOT_DEL))->save($data);
                } else {
                    $data['create_at'] = time();
                    $this->add($data);
                }
                unset($val);
            }
            $fooIds && $this->where(array('restaurant_id'=>$this->restaurantId,'foodID'=>['not in',$fooIds]))->setField('is_del',self::DEL);
            $this->commit();
            $this->clsCacheByRestaurantId($this->restaurantId);
            return true;
        } catch (\Exception $e) {
            $this->rollback();
            throw new \Exception($e->getMessage());
        }

    }

    /**
     * 获取
     * @param $restaurant_id
     * @return mixed
     */
    public function getFoodListByRestaurantId($restaurant_id)
    {
        $cache = \Think\Cache::getInstance('file', ['temp' => C('DATA_CACHE_PATH')]);
        $data = $cache->get(self::DB_HUALALA_DATA . $restaurant_id);
        if (empty($data)) {
            $data = $this->where(['restaurant_id' => $restaurant_id,'is_del'=>self::NOT_DEL])->select();
            $data && $cache->set(self::DB_HUALALA_DATA . $restaurant_id, $data, (24 * 60 * 60) + rand(10, 99));
        }
        return $data;
    }

    /**
     * 清理缓存
     * @param $restaurant_id
     */
    public function clsCacheByRestaurantId($restaurant_id)
    {
        $cache = \Think\Cache::getInstance('file', ['temp' => C('DATA_CACHE_PATH')]);
        $cache->rm(self::DB_HUALALA_DATA . $restaurant_id);
    }

    /**
     * 供下拉选择用
     * @param $restaurant_id
     * @return array
     */
    public function selectOpt($restaurant_id)
    {
        $data = $this->getFoodListByRestaurantId($restaurant_id);
        return array_column($data,'foodName','foodID');
    }
}

