<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/10/21
 * Time: 15:43
 */

namespace Common\Model;

class OpenPlatformOrderExtModel extends \Common\Model\BaseModel
{
    protected $tableName = "open_platform_order_ext";

    /**
     * 删除状态 1是 0否
     */
    const DEL_YES = 1;
    const DEL_NO = 0;

    /**
     * 退款状态 1是 0否
     */
    const REFUND_STATUS_NO = 0;
    const REFUND_STATUS_YES = 1;

    /**
     * 平台 0款易
     */
    const PLATFORM_KUANYI = 0;
}