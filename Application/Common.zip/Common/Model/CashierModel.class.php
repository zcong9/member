<?php

namespace Common\Model;

class CashierModel extends \Common\Model\BaseModel
{
    const CASHIER_SEX_MAN = 1;
    const CASHIER_SEX_WOMAN = 0;

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('restaurant_id', 'number', '店铺ID错误', 0),
        array('cashier_name', 'require', '姓名必填', 1, 'regex', 1),
        array('cashier_name', '1,50', '姓名不能超过50个字符',  0, 'length'),
        array('cashier_phone', 'require', '账号必填', 1, 'regex', 1),
        array('cashier_phone','','帐号名称已经存在！',0,'unique',1),
        array('cashier_phone', '1,11', '账号不能超过11个字符',  0, 'length'),
        array('cashier_pwd', 'require', '密码必填', 0, '',1),
        array('cashier_pwd', '6,18', '密码为6-18位纯数字', 2, 'length'),
        array('cashier_pwd', 'checkPwd', '密码为6-18位纯数字', 2,'callback'),
        array('cashier_address', '1,100', '地址不能超过100个字符', 0, 'length'),
        array('is_del', array(self::CASHIER_SEX_MAN, self::CASHIER_SEX_WOMAN), '性别错误', 0, 'in'),
    );

    /**
     * 自动完成
     * @var array
     */
    protected $_auto = array(
        array('cashier_pwd','',2,'ignore'),
        array('cashier_pwd', 'md5', 3, 'function'),
        array('cashier_pwd',null,2,'ignore'),
    );

    /**
     * 验证密码
     * @param $password
     * @return bool
     */
    protected function checkPwd($password){
        if (!preg_match('/^\d*$/',$password)) {
            return false;
        }
        return true;
    }

    /**
     * 新增
     * @param $post
     * @return array
     */
    public function doAdd($post){
        $result = ['code' => 0, 'msg' => '保存失败', 'data' => ''];
        // 验证
        $data = $this -> create($post, 1);
        if (false === $data) {
            $result['msg'] = $this -> getError();
            return $result;
        }
        try {
            if ($this -> add($data)) {
                $result['code'] = 1;
                $result['msg'] = '保存成功';
            }
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    /**
     * 新增
     * @param $post
     * @return array
     */
    public function doEdit($post){
        $result = ['code' => 0, 'msg' => '保存失败', 'data' => ''];
        // 验证
        $data = $this -> create($post, 2);
        if (false === $data) {
            $result['msg'] = $this -> getError();
            return $result;
        }
        try {
            if (false !== $this -> save($data)) {
                $result['code'] = 1;
                $result['msg'] = '保存成功';
            }
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    /**
     * 批量删除
     * @param array $ids
     * @return bool|mixed
     */
    public function batchDelByIds(array $ids){
        if (!is_array($ids)) return false;
        return $this->where(['cashier_id'=>['in',$ids]])->delete();
    }

}

