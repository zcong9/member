<?php

namespace Common\Model;

class BaiduDishesImgModel extends \Common\Model\BaseModel
{
    const IS_DEL_YES = 1;
    const IS_DEL_NO = 0;

    protected $foodId = 0;
    protected $baiduConfig = [];

    public function setFoodId($food_id)
    {
        $this->foodId = $food_id;
        return $this;
    }

    /**
     * 百度配置
     * @param $restaurant_id
     * @return $this
     */
    public function setBaiduConfig($restaurant_id){
        $this->baiduConfig = (new \Common\Model\BaiduConfigModel())->getConfigByRestaurantId($restaurant_id);
        return $this;
    }

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('food_id', 'number', '菜品ID错误', 0),
        array('business_id', 'number', '代理ID错误', 0),
        array('restaurant_id', 'number', '店铺ID错误', 0),
        array('dish_id', 'require', 'dishID必须', 1, 'regex', 1),
        array('dish_id', '1,32', 'dishID不能超过32个字符', 0, 'length'),
        //array('cont_sign', 'require', '图片签名必须', 1, 'regex', 1),
        //array('cont_sign', '1,128', '图片签名不能超过32个字符', 0, 'length'),
        array('is_del', array(self::IS_DEL_YES, self::IS_DEL_NO), '状态错误', 0, 'in'),
    );

    /**
     * 自动完成
     * @var array
     */
    protected $_auto = array(
        array('create_at', 'time', 1, 'function'),
    );

    /**
     * 新增数据
     * @param $post
     * @return array
     */
    public function doAdd($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => (object)[]];

        try {

            $data = $this->create($post, 1);
            if (false === $data) {
                $result['msg'] = $this->getError();
                return $result;
            }

            $data['img_url'] = $this->saveBase64Img($post['img']);
            if (!$data['img_url']) {
                $result['msg'] = '图片保存失败';
                return $result;
            }

            //上传百度菜品库
            try {
                $logic = new \Common\Logic\BaiduDishesImgLogic($this->baiduConfig);
                $resp = $logic->dishAddImage(file_get_contents($post['img']), ['food_id' => $post['food_id'], 'dish_id' => $post['dish_id'], 'food_type_id' => $post['food_type_id']]);
                if (isset($resp['cont_sign']) && !empty($resp['cont_sign'])) {
                    $data['cont_sign'] = $resp['cont_sign'];
                    $data['app_id'] = $this->baiduConfig['app_id'];
                } else {
                    $result['msg'] = $logic->getErrMsg();
                    return $result;
                }
            } catch (\Exception $e) {
                $result['msg'] = $e->getMessage();
                return $result;
            }

            if ($id = $this->add($data)) {
                $result['code'] = 0;
                $result['msg'] = '保存成功';
                $data['img_url'] = "http://" . $_SERVER["HTTP_HOST"] . $data['img_url'];
                $data['img_id'] = $id;
                $data['elm_group'] = $data['group_tag'];
                unset($data['group_tag']);
                unset($data['cont_sign']);
                unset($data['app_id']);
                $result['data'] = $data;
            }

        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    /**
     * 菜品检索
     * @param $img
     * @return array
     */
    public function dishSearch($img)
    {
        $result = ['code' => -1, 'msg' => '识别失败', 'data' => (object)[]];
        if (empty($img)) return $result;
        try {
            $logic = new \Common\Logic\BaiduDishesImgLogic($this->baiduConfig);
            $resp = $logic->dishSearch($img);
            if (isset($resp['result'])) {
                $result['code'] = 0;
                $result['msg'] = '识别成功';
                $result['data'] = $resp;
            } else {
                $result['msg'] = $logic->getErrMsg();
            }
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 根据图片ID批量删除
     * @param array $ids
     * @return bool
     */
    public function batchDel(array $ids)
    {
        if (empty($ids)) return false;
        $contSign = $this->where(['id' => ['in', $ids]])->getField('cont_sign',true);
        $res = $this->where(['id' => ['in', $ids]])->setField('is_del', self::IS_DEL_YES);
        if (false === $res) return false;
        //删除百度菜品库图片
        try{
            $logic = new \Common\Logic\BaiduDishesImgLogic($this->baiduConfig);
            foreach ($contSign as $v) {
                $resp = $logic->dishDeleteContSign($v);
            }
        } catch (\Exception $e) {
            //throw new \Exception($e->getMessage());
        }
        return true;
    }

    /**
     * 根据food_id批量获取
     * @param array $foodIds
     * @return array
     */
    public function batchGetItemsByFoodId(array $foodIds)
    {
        $result = ['code' => -1, 'msg' => '获取失败', 'data' => (object)[]];

        if (empty($foodIds)) {
            $result['msg'] = '参数缺失';
            return $result;
        }

        $host = "http://" . $_SERVER["HTTP_HOST"];
        $items = $this->field("id as img_id,food_id,dish_id,group_tag as elm_group,CONCAT('{$host}',img_url) as img_url,food_type_id")
            ->where(['restaurant_id' => ['eq', $this->restaurantId], 'food_id' => ['in', $foodIds], 'is_del' => ['eq', self::IS_DEL_NO]])
            ->order('food_id asc')
            ->select();

        $data = [];
        foreach ($items as $k => &$val) {
            $data[$val['food_id']][] = $val;
            unset($val);
        }

        $result['code'] = 0;
        $result['msg'] = 'success';
        $result['data'] = ['list' => $data ?: (object)[]];

        return $result;
    }

    /**
     * 获取指定店铺全部图片信息
     * @param int $restaurant_id
     * @return array
     */
    public function getItemsByRestaurantId($restaurant_id)
    {
        $result = ['code' => -1, 'msg' => '获取失败', 'data' => (object)[]];
        $restaurant_id && ($this->restaurantId = $restaurant_id);
        $host = "http://" . $_SERVER["HTTP_HOST"];
        $items = $this->field("id as img_id,food_id,dish_id,group_tag as elm_group,CONCAT('{$host}',img_url) as img_url,food_type_id")
            ->where(['restaurant_id' => ['eq', $this->restaurantId], 'is_del' => ['eq', self::IS_DEL_NO]])
            ->order('food_id asc')
            ->select();

        $data = [];
        foreach ($items as $k => &$val) {
            $data[$val['food_id']][] = $val;
            unset($val);
        }

        $result['code'] = 0;
        $result['msg'] = 'success';
        $result['data'] = ['list' => $data ?: (object)[]];

        return $result;
    }

    /**
     * 保存图片
     * @param string $imgBase64
     * @return string
     */
    protected function saveBase64Img($imgBase64)
    {
        if (empty($imgBase64)) return false;

        try {

            if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $imgBase64, $result)) {
                $type = $result[2];
            }

            $imageName = time() . rand("100", "999") . ".$type";

            //判断是否有逗号，有就截取后半部分
            if (strstr($imgBase64, ",")) {
                $image = explode(',', $imgBase64);
                $image = $image[1];
            }

            //设置图片保存路径
            $path = getcwd() . "/Public/Uploads/BaiduDishesImg/{$this->restaurantId}/{$this->foodId}/";
            !is_dir($path) && mkdir($path, 0777, true);

            //拼接路径和图片名称
            $imageSrc = $path . "/" . $imageName;

            //生成图片 返回字节数
            $res = file_put_contents($imageSrc, base64_decode($image)); //data:image/jpeg;base64, 拼接Base64

            if ($res) {
                return "/Public/Uploads/BaiduDishesImg/{$this->restaurantId}/{$this->foodId}/" . $imageName;
            } else {
                return false;
            }

        } catch (\Exception $e) {
            return false;
        }

    }

}

