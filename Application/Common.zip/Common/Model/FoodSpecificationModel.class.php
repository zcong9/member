<?php

namespace Common\Model;

class FoodSpecificationModel extends BaseModel
{
    //是否为附加属性(加价得):0-否,1-是
    const IS_ADDITIONAL_SPECIFICATION_NO = 0;
    const IS_ADDITIONAL_SPECIFICATION_YES = 1;

    //是否是自定义规格:0-否，1-是
    const IS_CUSTOM_NO = 0;
    const IS_CUSTOM_YES = 1;

    //0单选   1多选   2单选可不选
    const SELECT_ONE = 0;
    const SELECT_MORE = 1;
    const SELECT_ORDER = 2;

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('name', 'require', '规格名称必填'),
        array('name', '0,255', '规格名称不能超过255个字符', 2,'length'),
        array('specification_desc', '0,255', '规格备注不能超过255个字符', 2,'length'),
        array('select', array(self::SELECT_ONE,self::SELECT_MORE,self::SELECT_ORDER), '是否多选错误', 0,'in'),
        array('english_name', '0,255', '英文名称不能超过255个字符', 'length'),
        array('specification_img', '0,255', '规格图片名称不能超过255个字符', 2,'length'),
        array('is_additional_specification', array(self::IS_ADDITIONAL_SPECIFICATION_NO,self::IS_ADDITIONAL_SPECIFICATION_YES), '是否为附加属性(加价得)错误', 0,'in'),
        array('is_custom', array(self::IS_CUSTOM_NO,self::IS_CUSTOM_YES), '自定义规格错误', 0,'in'),
        array('business_id', 'number', '代理ID不合法', 0),
        array('restaurant_id', 'number', '店铺ID不合法', 0),
        array('print_id', 'number', '打印机ID不合法', 0),
        array('tag_print_id', 'number', '标签打印机ID不合法', 0),
    );

    /**
     * 添加规格
     * @param $data
     * @return array
     */
    public function addSpec($data)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];
        $data['food_restaurant_id'] = M('food_restaurant')->where(['food_id' => $data['food_id']])->getField('food_restaurant_id');
        $data['restaurant_id'] = $this->restaurantId;

        $model = M();
        $model->startTrans();
        try {
            // 每个菜品只能有一个加价得
            if (intval($data['is_additional_specification']) === self::IS_ADDITIONAL_SPECIFICATION_YES) {
                $this->where(['food_restaurant_id' => $data['food_restaurant_id']])->save(['is_additional_specification' => self::IS_ADDITIONAL_SPECIFICATION_NO]);
            }

            $id = $this->data($data)->add();
            if (!$id) {
                $model->rollback();
                return $result;
            }

            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '操作成功';
            $result['data']['food_specification_id'] = $id;
        } catch (\Exception $e) {
            $model->rollback();
        }

        return $result;
    }

    /**
     * 编辑规格
     * @param $data
     * @return array
     */
    public function editSpec($data)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];
        $model = M();
        $model->startTrans();
        try {
            // 每个菜品只能有一个加价得
            if (intval($data['is_additional_specification']) === self::IS_ADDITIONAL_SPECIFICATION_YES) {
                $this->where(['food_restaurant_id' => $data['food_restaurant_id']])->save(['is_additional_specification' => self::IS_ADDITIONAL_SPECIFICATION_NO]);
            }

            if (false !== ($this->save($data))) {
                $model->rollback();
                return $result;
            }

            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '操作成功';
        } catch (\Exception $e) {
            $model->rollback();
        }

        return $result;
    }

    /**
     * 根据代理ID 获取 规格ID
     * @param $business_id
     * @return mixed
     */
    public function getSpecIdsByBusinessId($business_id)
    {
        return $this->where(['is_custom' => self::IS_CUSTOM_NO, 'business_id' => $business_id ?: $this->businessId])
            ->getField('food_specification_id', true);
    }

    /**
     * 根据规格id 删除单条数据
     * @param $id
     * @return array
     */
    public function delSpecById($id)
    {
        $result = ['code' => -1, 'msg' => '删除失败', 'data' => []];
        if (empty($id)) return $result;
        if (!$this->where(['food_specification_id' => $id])->find()) {
            $result['msg'] = '没查到可删除的记录';
            return $result;
        }
        $model = M();
        $model->startTrans();
        if ($this->batchDelSpec($id)) {
            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '删除成功';
        } else {
            $model->rollback();
        }
        return $result;
    }

    /**
     * 根据代理商ID删除非自定义规格
     * @param $business_id
     * @return array
     *
     */
    public function delSpecByBusinessId($business_id)
    {
        $result = ['code' => -1, 'msg' => '删除失败', 'data' => []];
        // 当前代理下的通用规格
        $where['business_id'] = $business_id ?: $this->businessId;
        $where['food_restaurant_id'] = 0;
        $where['is_custom'] = self::IS_CUSTOM_NO;
        $specIds = $this->where($where)->getField('food_specification_id', true);
        if (empty($specIds)) return $result;
        $model = M();
        $model->startTrans();
        if ($this->batchDelSpec($specIds)) {
            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '删除成功';
        } else {
            $model->rollback();
        }
        return $result;
    }

    /**
     * 根据店铺ID删除非自定义规格
     * @param $restaurant_id
     * @return array
     *
     */
    public function delSpecByRestaurantId($restaurant_id)
    {
        // 当前代理下的通用规格
        $where['restaurant_id'] = $restaurant_id ?: $this->restaurantId;
        $where['food_restaurant_id'] = 0;
        $where['is_custom'] = self::IS_CUSTOM_NO;
        $specIds = $this->where($where)->getField('food_specification_id', true);
        $specIds && $res = $this->batchDelSpec($specIds);
        if (isset($res) && (true !== $res)) return false;
        return true;
    }

    /**
     * 批量删除规格
     * @param array $ids 规格id
     * @return bool
     */
    public function batchDelSpec(array $ids)
    {
        if (empty($ids)) return false;
        try {
            $where = ['food_specification_id' => ['in', $ids]];
            //删除food_specification
            $this->where($where)->delete();
            $specTypeIds = M('food_specification_middle')->where($where)->getField('food_type_id', true);
            if ($specTypeIds) {
                $whereSpecType['food_type_id'] = ['in', $specTypeIds];
                // 清除关联关系
                M('food_specification_middle')->where($whereSpecType)->delete();
                // 清除规格数据
                M('food_specification_type')->where($whereSpecType)->delete();
            }
        } catch (\Exception $e) {
            return false;
        }
        return true;
    }

    /**
     * 菜品规格数据导出(Excel)
     * food_model_id 菜单id
     *
     * */
    public function excelOutSpec()
    {
        // 所有规格数据
        $specData = M('food_specification_type')->alias('fst')
            ->field('
                        fst.food_type_id,
                        fst.food_type_name,
                        fst.type_english_name,
                        fst.plus_price,
                        fst.type_img,
                        fst.type_vcode,
                        fs.name as food_spec_name,
                        fs.english_name as food_spec_english_name,
                        fs.specification_img as food_spec_img,
                        fs.select as food_spec_select,
                        fs.food_specification_id,
                        fs.is_additional_specification
                    ')
            ->join('RIGHT JOIN food_specification_middle fsm on fst.food_type_id = fsm.food_type_id')
            ->join('RIGHT JOIN food_specification fs on fsm.food_specification_id = fs.food_specification_id')
            ->where(['fs.food_restaurant_id' => '0', 'fs.is_custom' => '0', 'fs.business_id' => $this->businessId, 'fs.restaurant_id' => $this->restaurantId])
            ->select();

        $title = [
            'food_type_id',
            'food_type_name',
            'type_english_name',
            'plus_price',
            'type_img',
            'type_vcode',
            'food_spec_name',
            'food_spec_english_name',
            'food_spec_img',
            'food_spec_select',
            'food_specification_id',
            'is_additional_specification',
        ];

        $csv = new \Think\Csv();
        $file_name = $this->businessId . '-' . date('Y-m-d') . '.csv';
        $csv->put_csv($file_name, $specData, $title);

    }

    /**
     * 导入规格
     * @param $filePath
     * @return array
     */
    public function importSpec($filePath)
    {
        $result = ['code' => -1, 'msg' => '导入失败', 'data' => []];
        $handle = fopen($filePath, 'r');
        if (!$handle) {
            fclose($handle);
            $result['msg'] = '文件格式有误';
            return $result;
        }
        $csv = new \Think\Csv();
        $items = $csv->input_csv($handle, 10000, 1); // 解析csv
        fclose($handle);
        if (empty($items)) {
            $result['msg'] = '没有数据';
            return $result;
        }

        $model = M();
        $model->startTrans();
        try {
            //先查询出规格分类表的ID，作为规格中间表的删除条件
            $foodSpecificationIds = $this->getSpecIdsByBusinessId($this->businessId);

            //批量删除关联规格表的数据
            if ($foodSpecificationIds && !($this->batchDelSpec($foodSpecificationIds))) {
                $model->rollback();
                return $result;
            }

            $already_add_food_specification_id = [];
            $foodSpecTypeModel = M('food_specification_type');
            $foodSpecMiddleModel = M('food_specification_middle');

            foreach ($items as $key => $value) {
                /******************************可以取得每行的数组*****************************/
                $Data = [];
                $Data['food_type_name'] = $value['1'];
                $Data['type_english_name'] = $value['2'];
                $Data['plus_price'] = floatval($value['3']);
                $Data['type_img'] = $value['4'];
                $Data['type_vcode'] = $value['5'];
                $Data['food_spec_name'] = $value['6'];
                $Data['food_spec_english_name'] = $value['7'];
                $Data['food_spec_img'] = $value['8'];
                $Data['food_spec_select'] = $value['9'];
                $Data['food_specification_id'] = $value['10'];
                $Data['is_additional_specification'] = intval($value['11']);

                // 该规格属性存在则进行修改
                // 无规格属性ID说明是新增
                $food_type_id = null;
                if (!empty($Data['food_type_name'])) {
                    $specTypeData['food_type_name'] = $Data['food_type_name'];
                    $specTypeData['type_english_name'] = $Data['type_english_name'];
                    $specTypeData['plus_price'] = $Data['plus_price'];
                    $specTypeData['type_img'] = $Data['type_img'];
                    $specTypeData['type_vcode'] = $Data['type_vcode'];

                    // 新增规格属性
                    $food_type_id = $foodSpecTypeModel->data($specTypeData)->add();
                }

                if (!in_array($Data['food_specification_id'], $already_add_food_specification_id)) { //该规格存在
                    $spec_data['name'] = $Data['food_spec_name'];
                    $spec_data['english_name'] = $Data['food_spec_english_name'];
                    $spec_data['specification_img'] = $Data['food_spec_img'];
                    $spec_data['select'] = $Data['food_spec_select'];
                    $spec_data['food_restaurant_id'] = '0';
                    $spec_data['business_id'] = $this->businessId;
                    $spec_data['is_custom'] = self::IS_CUSTOM_NO;
                    $spec_data['is_additional_specification'] = $Data['is_additional_specification'];
                    $food_specification['food_specification_id'] = $this->data($spec_data)->add();
                    $food_specification['food_specification_id'] && array_push($already_add_food_specification_id, $Data['food_specification_id']);
                }

                if (!empty($food_type_id) && !empty($food_specification['food_specification_id'])) {
                    // 重新生成关联关系
                    $insert['food_type_id'] = $food_type_id;
                    $insert['food_specification_id'] = $food_specification['food_specification_id'];

                    $foodSpecMiddleModel->data($insert)->add(); //把数据插入到中间表
                }
            }

            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '导入成功';

        } catch (\Exception $e) {
            $model->rollback();
        }
        return $result;
    }
}