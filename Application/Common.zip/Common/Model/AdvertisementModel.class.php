<?php

namespace Common\Model;

class AdvertisementModel extends \Common\Model\BaseModel
{
    const STATUS_ON = 1;//开启
    const STATUS_OFF = 0;//关闭

    const ADVERTISEMENT_TYPE_HC = 0;//横屏
    const ADVERTISEMENT_TYPE_VC = 1;//竖屏
    const ADVERTISEMENT_TYPE_CC = 2;//叫号屏
    const ADVERTISEMENT_TYPE_DC = 3;//双屏客显

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('restaurant_id', 'number', '店铺ID错误', 0),
        array('template_id', 'number', '广告位ID错误', 0),
        array('advertisement_desc', '0,255', '描述不能超过255个字符', 0, 'length'),
        array('advertisement_image_url', '0,255', '广告图片地址不能超过255个字符', 0, 'length'),
        array('advertisement_index_small_image_url', '0,255', '点餐页顶部小广告地址不能超过255个字符', 0, 'length'),
        array('advertisement_food_small_image_url', '0,255', '菜品页顶部小广告地址不能超过255个字符', 0, 'length'),
        array('advertisement_type', array(self::ADVERTISEMENT_TYPE_HC, self::ADVERTISEMENT_TYPE_VC, self::ADVERTISEMENT_TYPE_CC, self::ADVERTISEMENT_TYPE_DC), '广告的类型错误', 0, 'in'),
        array('status', array(self::STATUS_ON, self::STATUS_OFF), '启用状态错误', 0, 'in'),
    );


    /**
     * 新增
     * @param $post
     * @return array
     */
    public function doAdd($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => ''];
        // 验证
        $data = $this->create($post, 1);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }
        try {
            if ($this->add($data)) {
                $result['code'] = 0;
                $result['msg'] = '保存成功';
            }
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    /**
     * 编辑
     * @param $post
     * @return array
     */
    public function doEdit($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => ''];
        // 验证
        $data = $this->create($post, 2);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }
        try {
            if (false !== $this->save($data)) {
                $result['code'] = 0;
                $result['msg'] = '保存成功';
            }
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    /**
     * 批量删除
     * @param array $ids
     * @return bool|mixed
     */
    public function batchDelByIds(array $ids)
    {
        if (!is_array($ids)) return false;
        return $this->where(['advertisement_id' => ['in', $ids]])->delete();
    }

    /**
     * 获取列表
     * @param $condition
     * @param string $field
     * @param string $order
     * @return mixed
     */
    public function getList($condition,$field="*",$order=''){
        $list = $this->getListByCondition($condition,$field,$order);
        foreach ($list as &$vo) {
            isset($vo['advertisement_image_url']) && $vo['advertisement_image_url'] = ltrim($vo['advertisement_image_url'],'.');
            isset($vo['advertisement_index_small_image_url']) && $vo['advertisement_index_small_image_url'] = ltrim($vo['advertisement_index_small_image_url'],'.');
            isset($vo['advertisement_food_small_image_url']) && $vo['advertisement_food_small_image_url'] = ltrim($vo['advertisement_food_small_image_url'],'.');
        }
        return $list;
    }
}

