<?php

namespace Common\Model;

class IcoManagerModel extends \Common\Model\BaseModel
{

    /**
     * 菜品分类图标
     * @return array
     */
    public function getCateIcoList(){
        $item = $this->where(array('relation_category_id'=>1))->find();
        $photoItems = explode(",",$item['photo']);
        $items = array();
        foreach($photoItems as $k => $val){
            $items[] = array(
                'photo' => $item['_rootpath'].'/'.$val,
                'relation_category_id' => $item['relation_category_id'],
                'img_id' => $item['img_id'],
                'ico_type' => $item['ico_type'],
            );
        }
        return $items;
    }

}

