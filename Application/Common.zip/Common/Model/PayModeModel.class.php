<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/10/21
 * Time: 15:43
 */

namespace Common\Model;


class PayModeModel extends BaseModel
{
    const PAY_PRO = 1;//服务商支付
    const PAY_OY = 2;//普通支付
    const PAY_SHANDE = 4;//聚合支付
    const PAY_WXPRO_ALIOY = 10;//微信服务商 + 普通支付宝 支付
    const PAY_QWXPAY = 15;//微收银支付
    const PAY_KUANYIPAY = 16;//款易支付
    const PAY_ALIPRO_WXOY = 20;//支付宝服务商 + 普通微信 支付

    const PAY_PRO_TITLE = '服务商支付';
    const PAY_OY_TITLE = '普通支付';
    const PAY_SHANDE_TITLE = '聚合支付';
    const PAY_WXPRO_ALIOY_TITLE = '微信服务商 + 普通支付宝 支付';
    const PAY_QWXPAY_TITLE = '微收银支付';
    const PAY_KUANYIPAY_TITLE = '款易支付';
    const PAY_ALIPRO_WXOY_TITLE = '支付宝服务商 + 普通微信 支付';

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('mode', [self::PAY_PRO, self::PAY_OY, self::PAY_SHANDE, self::PAY_WXPRO_ALIOY, self::PAY_QWXPAY,self::PAY_KUANYIPAY, self::PAY_ALIPRO_WXOY], '支付模式错误', 2, 'in', 1),
        array('business_id', 'number', '代理ID错误', 0),
        array('restaurant_id', 'number', '店铺ID错误', 0),
    );

    /**
     * 保存
     * @param $post
     * @return array
     */
    public function saveData($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => ''];

        // 验证
        $data = $this->create($post);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }
        $item = $this->where(['business_id' => $data['business_id'], 'restaurant_id' => $data['restaurant_id']])->find();
        try {

            if ($item) {
                $id = $this->where(['business_id' => $data['business_id'], 'restaurant_id' => $data['restaurant_id']])->save($data);
            } else {
                $id = $this->add($data);
            }

            if (false !== $id) {
                $result['code'] = 0;
                $result['msg'] = '保存成功';
            }

        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }

        return $result;
    }

    /**
     *  根据支付通道 自动 开启关闭 对应的支付方式
     * @param $data
     * @return bool
     */
    public function setPaySelectByMode($data)
    {
        $paySelectModel = new \Common\Model\PaySelectModel();

        $condition = [];
        isset($data['restaurant_id']) && $condition['restaurant_id'] = $data['restaurant_id'];
        isset($data['business_id']) && $condition['business_id'] = $data['business_id'];

        if (empty($condition)) return false;

        if (!in_array($data['mode'], array_column($this->getModeList(), 'mode'))) return false;

        //全部设置为不可用
        $paySelectModel->batchUpdateStatus($condition, $paySelectModel::STOP);
        if ($data['mode'] == self::PAY_PRO) {
            //服务商支付通道
            $condition['_string'] = "(config_name = '" . $paySelectModel::PAY_PRO_WX . "' or config_name = '" . $paySelectModel::PAY_PRO_ALI . "')";

        } elseif ($data['mode'] == self::PAY_OY) {
            //普通支付通道
            $condition['_string'] = "(config_name = '" . $paySelectModel::PAY_OY_WX . "' or config_name = '" . $paySelectModel::PAY_OY_ALI . "' or config_name = '" . $paySelectModel::PAY_ALI_FACE . "')";

        } elseif ($data['mode'] == self::PAY_SHANDE) {
            //聚合支付通道
            $condition['_string'] = "(config_name = '" . $paySelectModel::PAY_SHANDE . "' or config_name = 'shandepay')";

        } elseif ($data['mode'] == self::PAY_QWXPAY) {
            //微收银支付通道
            $condition['_string'] = "config_name = '" . $paySelectModel::PAY_QWXPAY . "'";
        } elseif ($data['mode'] == self::PAY_KUANYIPAY){
            //款易支付通道

        }
        $paySelectModel->batchUpdateStatus($condition, $paySelectModel::OPEN);

        return true;
    }

    /**
     * 根据Mode 获取 名称
     * @param null $mode
     * @return string|string[]
     */
    public function getModeTitleByMode($mode = null)
    {
        $arr = array_column($this->getModeList(), 'title', 'mode');
        if (null === $mode) return $arr;
        return $arr[$mode];
    }

    /**
     * 支付通道
     * @return array
     */
    public function getModeList()
    {
        $arr = [
            ['title' => self::PAY_PRO_TITLE, 'mode' => self::PAY_PRO, 'remarks' => '微信、支付宝服务商模式支付', 'icon' => ''],
            ['title' => self::PAY_OY_TITLE, 'mode' => self::PAY_OY, 'remarks' => '微信、支付宝普通支付', 'icon' => ''],
            ['title' => self::PAY_SHANDE_TITLE, 'mode' => self::PAY_SHANDE, 'remarks' => '杉德聚合收款', 'icon' => ''],
            ['title' => self::PAY_WXPRO_ALIOY_TITLE, 'mode' => self::PAY_WXPRO_ALIOY, 'remarks' => '微信服务商 + 普通支付宝 支付', 'icon' => ''],
            ['title' => self::PAY_QWXPAY_TITLE, 'mode' => self::PAY_QWXPAY, 'remarks' => '微收银聚合收款', 'icon' => ''],
            ['title' => self::PAY_KUANYIPAY_TITLE, 'mode' => self::PAY_KUANYIPAY, 'remarks' => '款易聚合收款', 'icon' => ''],
            ['title' => self::PAY_ALIPRO_WXOY_TITLE, 'mode' => self::PAY_ALIPRO_WXOY, 'remarks' => '支付宝服务商 + 普通微信 支付', 'icon' => ''],
        ];
        return $arr;
    }

}