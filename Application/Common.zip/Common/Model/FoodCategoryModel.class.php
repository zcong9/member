<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/9/14
 * Time: 18:03
 */

namespace Common\Model;


class FoodCategoryModel extends BaseModel
{

    //是否是套餐 0不是套餐 1套餐
    const IS_PACKAGE_YES = 1;
    const IS_PACKAGE_NO = 0;

    //是否开启定时 0关闭 1开启
    const IS_TIME_YES = 1;
    const IS_TIME_NO = 0;

    //是否显示 0 不显示 1显示
    const IS_DISPLAY_YES = 1;
    const IS_DISPLAY_NO = 0;

    //是否特殊分类：0否，1是，2暂停
    const IS_SPECIAL_NO = 0;
    const IS_SPECIAL_YES = 1;
    const IS_SPECIAL_STOP = 2;

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('category_name', 'require', '分类名称必填', 1),
        array('category_name', '1,255', '分类名称不能超过255个字符', 2, 'length'),
        array('category_english_name', '0,255', '分类英文名称不能超过255个字符', 2, 'length'),
        array('restaurant_id', 'number', '店铺ID错误', 0),
        array('business_id', 'number', '代理商ID错误', 0),
        array('sort', 'number', '排序错误', 0),
        array('img', '0,100', '分类图片地址超长', 0, 'length'),
        array('food_model_id', 'require', '菜单模型必填', 1, '', 1),
        array('food_model_id', 'number', '菜单模型错误', 0),
        array('is_package', array(self::IS_PACKAGE_NO, self::IS_PACKAGE_YES), '菜单模型必填', 0, 'in'),
        array('time_day', 'number', '定时的星期错误', 0),
        array('start_time', '0,100', '定时开始时间错误', 0, 'length'),
        array('end_time', '0,100', '定时结束时间错误', 0, 'length'),
        array('day_start_time', 'number', '日期定时开始时间', 0),
        array('day_end_time', 'number', '日期定时结束时间', 0),
        array('is_time', array(self::IS_TIME_NO, self::IS_TIME_YES), '是否开启定时错误', 0, 'in'),
        array('is_display', array(self::IS_DISPLAY_NO, self::IS_DISPLAY_YES), '是否显示错误', 0, 'in'),
        array('category_vcode', '0,30', '分类编码不能超过30个字符', 2, 'length'),
        array('is_special', array(self::IS_SPECIAL_NO, self::IS_SPECIAL_YES, self::IS_SPECIAL_STOP), '是否特殊分类错误', 0, 'in'),
    );

    /**
     * 新增菜品分类
     * @param $post
     * @return array
     */
    public function addData($post)
    {
        $result = ['code' => -1, 'msg' => '添加失败', 'data' => []];
        $data = $this->create($post, 1);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }
        $model = M();
        $model->startTrans();
        try {
            $id = $this->add($data);
            if (!$id) {
                $model->rollback();
                return $result;
            }
            //获取整理过菜时数据
            if ($data['is_time'] == self::IS_TIME_YES && $data['is_special'] == self::IS_SPECIAL_NO) {
                $this->setCatTiming($id,$post);
                //验证是否超时
                //$status = $this->categoryTimingStatus($id);
                //if ($status != $data['is_display']) $this->where(['category_id' => $id])->save(['is_display' => $status]);
            }
            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '添加成功';
            return $result;
        } catch (\Exception $e) {
            $model->rollback();
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 编辑菜品分类
     * @param $data
     * @return array
     */
    public function editData($post)
    {
        $result = ['code' => -1, 'msg' => '修改失败', 'data' => []];
        $data = $this->create($post, 2);
        if (false === $data) {
            $result['msg'] = $this->getError();
            return $result;
        }
        $model = M();
        $model->startTrans();
        try {
            if (false === $this->save($data)) {
                $model->rollback();
                return $result;
            }
            //获取整理过菜时数据
            if ($data['is_time'] == self::IS_TIME_YES && $data['is_special'] == self::IS_SPECIAL_NO) {
                $this->setCatTiming($data['category_id'],$post);
                //验证是否超时
                //$status = $this->categoryTimingStatus($data['category_id']);
                //if ($status != $data['is_display']) $this->where(['category_id' => $data['category_id']])->save(['is_display' => $status]);
            }
            $model->commit();
            $result['code'] = 0;
            $result['msg'] = '修改成功';
            return $result;
        } catch (\Exception $e) {
            $model->rollback();
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 设置菜时
     * @param $cat_id
     * @param $data
     * @return bool|string
     */
    private function setTimingData($cat_id, $data)
    {
        if (empty($cat_id) || empty($data)) return true;
        $model = M('food_category_timing');
        $where['food_category_id'] = $cat_id;
        // 清除旧的定时，重新添加
        if ($model->where($where)->find()) {
            $model->where($where)->delete();
        }
        //批量添加
        return $model->addAll($data);
    }

    /**
     * 判断分类是否超时
     * @param $category_id
     * @return int status
     */
    public function categoryTimingStatus($category_id)
    {
        $categoryTimingList = M('food_category_timing')->where(['food_category_id' => $category_id])->select();
        if (!$categoryTimingList) return 1;
        $nowTime = time();   // 当前时间
        $status = 0;
        foreach ($categoryTimingList as $cTiming) {

            // 星期定时
            if ($cTiming['timing_day'] !== 'today') {
                $timingWeek = explode("-", $cTiming['timing_day']);
                // 当日星期几
                $whichWeek = date('w', time());
                $timingStartTime = strtotime($cTiming['start_time']);    // 开始时间
                $timingEndTime = strtotime($cTiming['end_time']);      // 结束时间
                // 当日处于星期定时范畴内且当前时间大于开始时间小于结束时间则上架分类，反之表示不在该分类有效时间内，下架分类
                // 有一个时间条件匹配则上架分类，并跳出本次循环，不再继续执行
                if (in_array($whichWeek, $timingWeek) && ($timingStartTime < $nowTime && $nowTime < $timingEndTime)) {
                    $status = 1;
                    break;
                }

            } else {
                // 日期定时,方法同上
                if ($cTiming['day_start_time'] < $nowTime && $nowTime < $cTiming['day_end_time']) {
                    $status = 1;
                    break;
                }
            }
        }
        return $status;
    }

    private function setCatTiming($cat_id, $data){
        $items = [];
        //星期定时
        if (isset($data['category_timing']['week']) && !empty($data['category_timing']['week'])) {
            $weekData = $data['category_timing']['week'];
            $tmpArr = [];
            foreach ($weekData as $k => $val) {
                $items[$k]['start_time'] = $val['start_time'] ?: '00:00';
                $items[$k]['end_time'] = $val['end_time'] ?: '23:59';
                $items[$k]['timing_day'] = implode('-',$val['days']) ?: '1-2-3-4-5-6-0';
                $items[$k]['day_end_time'] = 0;
                $items[$k]['day_start_time'] = 0;
                $items[$k]['food_category_id'] = $cat_id;
                //去重处理
                $str = $items[$k]['start_time']. $items[$k]['end_time'].$items[$k]['timing_day'];
                if (in_array($str,$tmpArr)) {
                    unset($items[$k]);
                } else {
                    $tmpArr[] = $str;
                }
            }
            unset($tmpArr);
        }

        //日期定时
        $items2 = [];
        if (isset($data['category_timing']['date']) && !empty($data['category_timing']['date'])) {
            $dateData = $data['category_timing']['date'];
            $tmpArr = [];
            foreach ($dateData as $k => $val) {
                $items2[$k]['start_time'] = 0;
                $items2[$k]['end_time'] = 0;
                $items2[$k]['timing_day'] = 'today';
                $items2[$k]['day_end_time'] = strtotime(($val['endTime'] ?: date('Y/m/d')) ." ".($val['endHour'] ?: '23:59:00'));
                $items2[$k]['day_start_time'] = strtotime(($val['startTime'] ?: date('Y/m/d')) ." ".($val['startHour'] ?: '00:00:00'));
                $items2[$k]['food_category_id'] = $cat_id;
                //去重处理
                $str = $items2[$k]['day_start_time']. $items2[$k]['day_end_time'];
                if (in_array($str,$tmpArr)) {
                    unset($items2[$k]);
                } else {
                    $tmpArr[] = $str;
                }
            }
            unset($tmpArr);
        }
        $items = array_merge($items,$items2);
        $model = M('food_category_timing');
        $where['food_category_id'] = $cat_id;
        $model->where($where)->delete();
        return $items && $model->addAll($items);

    }

    /**
     * 获取表单提交的菜时数据
     * @return array
     */
    private function getSubTimingFormat($cat_id)
    {
        $timingItems = [];
        $timingArr = array_filter(json_decode($_POST['time'], true));
        if (count($timingArr) !== 0) {
            //判断时间是否合法
            $t_condition['timing_day'] = 'today';
            $t_condition['start_time'] = '0';
            $t_condition['end_time'] = '0';
            foreach ($timingArr as $t_key => $t_val) {
                if ($t_val[0] && $t_val[1]) {
                    $t_condition['day_start_time'] = strtotime($t_val[0]);
                    $t_condition['day_end_time'] = strtotime($t_val[1]);
                    $t_condition['food_category_id'] = $cat_id;
                    if (!$t_condition['day_start_time'] || !$t_condition['day_end_time']) continue;
                    if ($t_condition['day_start_time'] >= $t_condition['day_end_time']) continue;
                    $timingItems[] = $t_condition;
                }
            }
        }

        $timingArr = array_filter(json_decode($_POST['day'], true));
        if (count($timingArr) !== 0) {
            // 星期定时分类
            foreach ($timingArr as $d_key => $d_val) {
                $length = count($d_val);
                if ($length > 2) {
                    $d_data['timing_day'] = '';
                    for ($i = 0; $i < $length - 2; $i++) {
                        if ($i == ($length - 3)) {
                            $d_data['timing_day'] .= $d_val[$i];
                        } else {
                            $d_data['timing_day'] .= $d_val[$i] . "-";
                        }
                    }
                    $d_data['start_time'] = $d_val[$length - 2] ?: '00:00';
                    $d_data['end_time'] = $d_val[$length - 1] ?: '00:00';
                    $d_data['day_start_time'] = 0;
                    $d_data['day_end_time'] = 0;
                    $d_data['food_category_id'] = $cat_id;

                    //开始时间与比结束时间大去掉
                    if (strtotime($d_data['start_time']) >= strtotime($d_data['end_time'])) continue;
                    $timingItems[] = $d_data;
                }
            }
        }
        return $timingItems;
    }

    /**
     * 获取菜时
     * @param $data
     * @return mixed
     */
    public function getCatTiming(&$data){
        $categoryTimeList = D('food_category_timing')->where(['food_category_id' => $data['category_id']])->select();
        if ($categoryTimeList) {
            foreach ($categoryTimeList as $k => $v) {
                if ($v['day_start_time'] !== '0') {
                    $data['category_time'][$k]['day_start_time'] = date("Y-m-d H:i:s", $v['day_start_time']);
                    $data['category_time'][$k]['day_end_time'] = date("Y-m-d H:i:s", $v['day_end_time']);
                    $data['category_time'][$k]['day_start'] = date("Y/m/d", $v['day_start_time']);
                    $data['category_time'][$k]['day_end'] = date("Y/m/d", $v['day_end_time']);
                    $data['category_time'][$k]['start_hour'] = date("H:i", $v['day_start_time']);
                    $data['category_time'][$k]['end_hour'] = date("H:i", $v['day_end_time']);
                } else {
                    $data['category_timing'][$k]['timing_day'] = explode("-", $v['timing_day']);
                    $data['category_timing'][$k]['start_time'] = $v['start_time'];
                    $data['category_timing'][$k]['end_time'] = $v['end_time'];
                }
            }
        }
        return $data;
    }

    /**
     * 代理商删除菜品分类
     * @param $cat_id
     * @return array
     */
    public function del($cat_id)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];
        $where = ['category_id' => $cat_id, 'business_id' => $this->businessId, 'restaurant_id' => $this->restaurantId];
        if (!$this->where($where)->find()) return $result;
        $model = M();
        $model->startTrans();
        try {
            if (true === $this->batchDelByIds(array($cat_id))) {
                $model->commit();
            }
            $result['code'] = 0;
            $result['msg'] = '操作成功';
        } catch (\Exception $e) {
            $model->rollback();
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 店铺删除菜品分类
     * @param $cat_id
     * @return array
     */
    public function doDelById($cat_id)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];
        $where = ['category_id' => $cat_id, 'restaurant_id' => $this->restaurantId];
        if (!$this->where($where)->find()) return $result;
        $model = M();
        $model->startTrans();
        try {
            if (true === $this->batchDelByIds(array($cat_id),false)) {
                $model->commit();
            }
            $result['code'] = 0;
            $result['msg'] = '操作成功';
        } catch (\Exception $e) {
            $model->rollback();
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }


    /**
     * 根据分类ID批量删除
     * @param array $ids
     * @return bool
     */
    public function batchDelByIds(array $ids,$isDelFood = true)
    {
        if (empty($ids)) return false;
        try {
            if ($isDelFood) {
                // 查出分类关联的菜品ID
                $foodResId = M('food_restaurant_category')->where(['category_id' => ['in', $ids]])->getField('food_restaurant_id', true);
                $foodResId && $foodIds = M('food_restaurant')->where(['food_restaurant_id' => ['in', $foodResId]])->getField('food_id', true);
                if (isset($foodIds) && !empty($foodIds)) {
                    //删除菜品数据
                    if (false === (new \Common\Model\FoodModel())->batchDelFoodByIds($foodIds)) return false;
                }
            }
            // 删除分类中间表关系
            M('food_restaurant_category')->where(['category_id' => ['in', $ids]])->delete();
            // 删除分类
            $this->where(['category_id' => ['in', $ids]])->delete();
            // 删除定时分类
            M('food_category_timing')->where(['food_category_id' => ['in', $ids]])->delete();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * 菜品分类上移
     * @param $data
     * @return array
     */
    public function moveUp($data)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];
        //当前点击id的数据
        $currentItem = $this->where(['category_id' => $data['category_id']])->find();
        if (empty($currentItem) || $currentItem['sort'] == 0) return $result;
        //比当前点击id排序前一条数据
        isset($data['food_model_id']) && $where['food_model_id'] = $data['food_model_id'];
        $this->businessId && $where['business_id'] = $this->businessId;
        $this->restaurant_id && $where['restaurant_id'] = $this->restaurant_id;
        $where['sort'] = array('lt', $currentItem['sort']);
        $preItem = $this->where($where)->order('sort desc')->find();
        if (empty($preItem) || $preItem['sort'] == 0) return $result;
        $this->where(['category_id' => $currentItem['category_id']])->save(['sort' => $preItem['sort']]);
        $this->where(['category_id' => $preItem['category_id']])->save(['sort' => $currentItem['sort']]);
        $result['code'] = 0;
        $result['msg'] = '操作成功';
        return $result;
    }

    /**
     * 菜品分类下移
     * @param $data
     * @return array
     */
    public function moveDown($data)
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];
        //当前点击id的数据
        $currentItem = $this->where(['category_id' => $data['category_id']])->find();
        if (empty($currentItem)) return $result;
        //比当前点击id排序后一条数据
        isset($data['food_model_id']) && $where['food_model_id'] = $data['food_model_id'];
        $this->businessId && $where['business_id'] = $this->businessId;
        $this->restaurant_id && $where['restaurant_id'] = $this->restaurant_id;
        $where['sort'] = array('gt', $currentItem['sort']);
        $nextItem = $this->where($where)->order('sort asc')->find();
        if (empty($nextItem) || $nextItem['sort'] == 0) return $result;
        $this->where(['category_id' => $currentItem['category_id']])->save(['sort' => $nextItem['sort']]);
        $this->where(['category_id' => $nextItem['category_id']])->save(['sort' => $currentItem['sort']]);
        $result['code'] = 0;
        $result['msg'] = '操作成功';
        return $result;
    }

    /**
     * 菜品分类上下架
     * 注：is_special > 0 为特殊分类不显示
     * @param $category_id
     * @param string $type
     * @return array
     */
    public function changeDisplay($category_id, $type = 'up')
    {
        $result = ['code' => -1, 'msg' => '操作失败', 'data' => []];
        $where['category_id'] = $category_id;
        if ('up' == $type) {
            $data = ['is_display' => self::IS_DISPLAY_YES];
            $where['is_special'] = self::IS_SPECIAL_NO;
        } else if ('down' == $type) {
            $data = ['is_display' => self::IS_DISPLAY_NO];
        } else {
            return $result;
        }
        if (false !== $this->where($where)->save($data)) {
            $result['code'] = 0;
            $result['msg'] = '操作成功';
        }
        return $result;
    }

    /**
     * 店铺菜品分类上下架推送消息
     * @param $category_id
     * @param string $type
     */
    public function pushMsg($category_id, $type = 'up')
    {
        //获取店铺设备 device_name
        $deviceNames = M('iot_device')->where(['restaurant_id' => $this->restaurantId])->getField('device_name', true);
        if ($deviceNames) {

            $Iot = new \data\service\IotService();
            $iotData['MenuType'] = 1;
            $iotData['SalesType'] = ($type == 'up') ? self::IS_DISPLAY_YES : self::IS_DISPLAY_NO;
            $iotData['Data'] = $category_id;

            foreach ($deviceNames as $deviceName) {
                $iotData['DeviceName'] = $deviceName;
                try {
                    $Iot->sendInstruction($deviceName, $iotData, 'MenuInformation');
                } catch (\Exception $e) {
                    //服务异常
                    (new \Think\Log\Driver\File())->write(var_export($e->getMessage(), true), './log/' . date('Y-m-d') . '.log');
                }
            }

        }
        return;
    }

}