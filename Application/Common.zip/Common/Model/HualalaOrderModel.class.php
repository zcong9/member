<?php

namespace Common\Model;

class HualalaOrderModel extends \Common\Model\BaseModel
{
    const DEL = 1;
    const NOT_DEL = 0;

    const REFUND_STATUS_NO = 0;
    const REFUND_STATUS_YES = 1;

    public function doSave($post){
        try {
            if ($post['id']) {
                return $this->where(['id'=>$post['id']])->save($post);
            } else {
                return $this->add($post);
            }
        } catch (\Exception $e) {
            return false;
        }
    }

}

