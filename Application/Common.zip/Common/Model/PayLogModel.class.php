<?php

namespace Common\Model;

class PayLogModel extends \Common\Model\BaseModel
{
    const DEL_YES = 1;
    const DEL_NO = 0;

    const PAY_TYPE_ALI = 1;//支付宝
    const PAY_TYPE_WX = 2;//微信
    const PAY_TYPE_CANDAO = 5;//会员-餐道|款易

    const PAY_MODE_OFFICIAL_PRO = 1;//官方服务商支付
    const PAY_MODE_OFFICIAL_OY = 2;//官方普通支付
    const PAY_MODE_SHANDE = 4;//杉德聚合
    const PAY_MODE_CANDAO = 5;//餐道会员
    const PAY_MODE_QWXPAY = 15;//微收银聚合
    const PAY_MODE_KUANYIPAY = 16;//款易支付

    //自动完成
    protected $_auto = array(
        array('create_at', 'time', 1, 'function'),
    );

    /**
     * 新增
     * @param $data
     * @return string
     */
    public function doAdd($data){
        try {
            $data = $this->create($data);
            $data && $this->add($data);
            return $this->getLastInsID();
        } catch (\Exception $e) {
            return false;
        }
    }
}

