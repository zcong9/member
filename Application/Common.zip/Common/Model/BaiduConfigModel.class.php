<?php

namespace Common\Model;

class BaiduConfigModel extends \Common\Model\BaseModel
{
    const DB_BAIDU_CONFIG = 'DB_BAIDU_CONFIG_';

    /**
     * 自动验证码
     * @var array
     */
    protected $_validate = array(
        array('app_id', 'require', 'AppID必须', 1, 'regex', 3),
        array('app_id', '1,32', 'dishID不能超过32个字符', 2, 'length'),
        array('api_key', 'require', 'API Key必须', 1, 'regex', 3),
        array('api_key', '1,64', 'dishID不能超过64个字符', 2, 'length'),
        array('secret_key', 'require', 'Secret Key必须', 1, 'regex', 3),
        array('secret_key', '1,64', 'Secret Key不能超过64个字符', 2, 'length'),
        array('restaurant_id', 'number', '店铺ID错误', 0),
        array('business_id', 'number', '商家ID错误', 0),
    );

    /**
     * 保存
     * @param $post
     * @return array
     */
    public function doSave($post)
    {
        $result = ['code' => -1, 'msg' => '保存失败', 'data' => (object)[]];
        try {
            $data = $this->create($post);
            if (false === $data) {
                $result['msg'] = $this->getError();
                return $result;
            }

            if ($this->where(['restaurant_id' => $data['restaurant_id']])->find()) {
                $id = $this->where(['restaurant_id' => $data['restaurant_id']])->save($data);
            } else {
                $id = $this->add($data);
            }

            if (false !== $id) {
                $result['code'] = 0;
                $result['msg'] = '保存成功';
            }

            $this->clsCacheByRestaurantId($data['restaurant_id']);

        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
        }
        return $result;
    }

    /**
     * 获取百度参数
     * @param $restaurant_id
     * @return mixed
     */
    public function getConfigByRestaurantId($restaurant_id)
    {
        $cache = \Think\Cache::getInstance('file', ['temp' => C('DATA_CACHE_PATH')]);
        $data = $cache->get(self::DB_BAIDU_CONFIG . $restaurant_id);
        if (empty($data)) {
            $data = $this->where(['restaurant_id' => $restaurant_id])->find();
            $data && $cache->set(self::DB_BAIDU_CONFIG . $restaurant_id, $data, (12 * 60 * 60) + rand(10, 99));
        }
        return $data;
    }

    /**
     * 清理缓存
     * @param $restaurant_id
     */
    public function clsCacheByRestaurantId($restaurant_id)
    {
        $cache = \Think\Cache::getInstance('file', ['temp' => C('DATA_CACHE_PATH')]);
        $cache->rm(self::DB_BAIDU_CONFIG . $restaurant_id);
    }

}

