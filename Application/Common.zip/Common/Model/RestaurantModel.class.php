<?php

namespace Common\Model;

class RestaurantModel extends \Common\Model\BaseModel
{
    /**
     * 数据表主键
     * @var string
     */
    protected $pk = 'restaurant_id';

    /**
     * 模型名称
     * @var string
     */
    protected $name = 'restaurant';

}

